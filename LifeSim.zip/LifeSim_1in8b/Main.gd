extends Control

const ThemeBuilder = preload("res://ui/ThemeBuilder.gd")
const HandDrawnPortrait = preload("res://ui/HandDrawnPortrait.gd")
const ModalManager = preload("res://ui/ModalManager.gd")

const GameStateScript = preload("res://core/GameState.gd")
const CausalityEngineScript = preload("res://core/CausalityEngine.gd")
const EconomyAndCareerScript = preload("res://core/EconomyAndCareer.gd")
const NPCEngineScript = preload("res://core/NPCEngine.gd")

const DBCountriesScript = preload("res://data/DB_Countries.gd")
const DBEventsChildhoodScript = preload("res://data/DB_Events_Childhood.gd")
const DBEventsYouthScript = preload("res://data/DB_Events_Youth.gd")
const DBEventsAdultScript = preload("res://data/DB_Events_Adult.gd")
const DBEventsSeniorScript = preload("res://data/DB_Events_Senior.gd")
const DBStoryArcsScript = preload("res://data/DB_StoryArcs.gd")
const DBCareersAndEndingsScript = preload("res://data/DB_CareersAndEndings.gd")

var gs: RefCounted
var causality: RefCounted
var economy: RefCounted
var npc_engine: RefCounted
var countries_db: Dictionary = {}
var careers_data: Dictionary = {}

# Arayüz Bileşenleri
var portrait_view: Control
var name_label: Label
var sub_identity_label: Label
var class_badge_label: Label
var job_and_money_label: Label
var stage_seal_rect: TextureRect

var timeline_scroll: ScrollContainer
var timeline_vbox: VBoxContainer

var stat_bars: Dictionary = {}
var stat_val_labels: Dictionary = {}

var age_plus_btn: Button
var drawer_overlay: Control
var drawer_title_lbl: Label
var drawer_content_vbox: VBoxContainer
var modal_manager: Control

func _ready() -> void:
	theme = ThemeBuilder.build_global_theme()

	# Veri tabanlarını ve motorları başlat
	gs = GameStateScript.new()
	causality = CausalityEngineScript.new()
	economy = EconomyAndCareerScript.new()
	npc_engine = NPCEngineScript.new()

	countries_db = DBCountriesScript.get_countries()
	var ev_child: Array = DBEventsChildhoodScript.get_events()
	var ev_youth: Array = DBEventsYouthScript.get_events()
	var ev_adult: Array = DBEventsAdultScript.get_events()
	var ev_senior: Array = DBEventsSeniorScript.get_events()
	var arcs_list: Array = DBStoryArcsScript.get_story_arcs()
	careers_data = DBCareersAndEndingsScript.get_data()

	causality.register_databases(countries_db, ev_child, ev_youth, ev_adult, ev_senior, arcs_list)
	economy.setup(countries_db, careers_data)

	_build_ui_hierarchy()
	_start_new_life("", "")

func _build_ui_hierarchy() -> void:
	# 1. Arka Plan Sıcak Fildişi Parşömen
	var bg_rect: ColorRect = ColorRect.new()
	bg_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg_rect.color = ThemeBuilder.COLOR_PAPER_BG
	add_child(bg_rect)

	# 2. Ana Dikey İskelet (4 Kusursuz Bölge: Üst Kimlik, Merkez Günlük, 6 İstatistik, Alt Dock)
	var root_margin: MarginContainer = MarginContainer.new()
	root_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root_margin.add_theme_constant_override("margin_left", 22)
	root_margin.add_theme_constant_override("margin_right", 22)
	root_margin.add_theme_constant_override("margin_top", 22)
	root_margin.add_theme_constant_override("margin_bottom", 22)
	add_child(root_margin)

	var main_vbox: VBoxContainer = VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", 14)
	root_margin.add_child(main_vbox)

	# BÖLGE 1: Üst Kimlik ve Portre Kartı (~260px)
	var header_panel: PanelContainer = PanelContainer.new()
	header_panel.custom_minimum_size = Vector2(0.0, 250.0)
	header_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 3, 12, 16))
	main_vbox.add_child(header_panel)

	var header_hbox: HBoxContainer = HBoxContainer.new()
	header_hbox.add_theme_constant_override("separation", 18)
	header_panel.add_child(header_hbox)

	portrait_view = HandDrawnPortrait.new()
	portrait_view.custom_minimum_size = Vector2(184.0, 184.0)
	portrait_view.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header_hbox.add_child(portrait_view)

	var id_vbox: VBoxContainer = VBoxContainer.new()
	id_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	id_vbox.add_theme_constant_override("separation", 6)
	header_hbox.add_child(id_vbox)

	var top_row: HBoxContainer = HBoxContainer.new()
	id_vbox.add_child(top_row)

	name_label = Label.new()
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.add_theme_font_size_override("font_size", 27)
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	top_row.add_child(name_label)

	stage_seal_rect = TextureRect.new()
	stage_seal_rect.custom_minimum_size = Vector2(54.0, 54.0)
	stage_seal_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	stage_seal_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	top_row.add_child(stage_seal_rect)

	var new_life_btn: Button = Button.new()
	new_life_btn.text = "⚙️ Yeni Hayat"
	ThemeBuilder.apply_button_theme(new_life_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 17)
	new_life_btn.pressed.connect(func() -> void:
		modal_manager.show_new_life_modal(countries_db)
	)
	top_row.add_child(new_life_btn)

	sub_identity_label = Label.new()
	sub_identity_label.add_theme_color_override("font_color", ThemeBuilder.COLOR_PRUSSIAN)
	sub_identity_label.add_theme_font_size_override("font_size", 20)
	id_vbox.add_child(sub_identity_label)

	class_badge_label = Label.new()
	class_badge_label.add_theme_color_override("font_color", ThemeBuilder.COLOR_TERRACOTTA)
	class_badge_label.add_theme_font_size_override("font_size", 18)
	id_vbox.add_child(class_badge_label)

	job_and_money_label = Label.new()
	job_and_money_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	job_and_money_label.add_theme_color_override("font_color", ThemeBuilder.COLOR_SAGE)
	job_and_money_label.add_theme_font_size_override("font_size", 20)
	id_vbox.add_child(job_and_money_label)

	# BÖLGE 2: Merkez Yaşam Günlüğü Akışı (Timeline ScrollContainer)
	var timeline_panel: PanelContainer = PanelContainer.new()
	timeline_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	timeline_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_BG, ThemeBuilder.COLOR_INK_DARK, 2, 10, 14))
	main_vbox.add_child(timeline_panel)

	timeline_scroll = ScrollContainer.new()
	timeline_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	timeline_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	timeline_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	timeline_panel.add_child(timeline_scroll)

	timeline_vbox = VBoxContainer.new()
	timeline_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	timeline_vbox.add_theme_constant_override("separation", 12)
	timeline_scroll.add_child(timeline_vbox)

	# BÖLGE 3: Gösterge Paneli (6 İstatistik Barı - ~220px)
	var stats_panel: PanelContainer = PanelContainer.new()
	stats_panel.custom_minimum_size = Vector2(0.0, 215.0)
	stats_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 2, 10, 14))
	main_vbox.add_child(stats_panel)

	var stats_grid: GridContainer = GridContainer.new()
	stats_grid.columns = 2
	stats_grid.add_theme_constant_override("h_separation", 24)
	stats_grid.add_theme_constant_override("v_separation", 12)
	stats_panel.add_child(stats_grid)

	var stat_defs: Array = [
		["health", "❤️ Sağlık", ThemeBuilder.COLOR_TERRACOTTA],
		["happiness", "☀️ Mutluluk", ThemeBuilder.COLOR_OCHRE],
		["smart", "🧠 Zeka & Beceri", ThemeBuilder.COLOR_PRUSSIAN],
		["reputation", "👑 Sosyal İtibar", ThemeBuilder.COLOR_PLUM],
		["sanity", "🌀 Akıl Sağlığı", ThemeBuilder.COLOR_PRUSSIAN],
		["karma", "⚖️ Vicdan / Karma", ThemeBuilder.COLOR_SAGE]
	]

	for s_def in stat_defs:
		var s_key: String = str(s_def[0])
		var s_title: String = str(s_def[1])
		var s_col: Color = s_def[2]

		var cell_vbox: VBoxContainer = VBoxContainer.new()
		cell_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cell_vbox.add_theme_constant_override("separation", 4)
		stats_grid.add_child(cell_vbox)

		var lbl_hbox: HBoxContainer = HBoxContainer.new()
		cell_vbox.add_child(lbl_hbox)

		var st_lbl: Label = Label.new()
		st_lbl.text = s_title
		st_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		st_lbl.add_theme_font_size_override("font_size", 18)
		lbl_hbox.add_child(st_lbl)

		var val_lbl: Label = Label.new()
		val_lbl.text = "%80"
		val_lbl.add_theme_font_size_override("font_size", 18)
		lbl_hbox.add_child(val_lbl)
		stat_val_labels[s_key] = val_lbl

		var pb: ProgressBar = ProgressBar.new()
		pb.min_value = 0.0
		pb.max_value = 100.0
		pb.value = 80.0
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0.0, 20.0)
		pb.add_theme_stylebox_override("background", ThemeBuilder.make_progress_bg())
		pb.add_theme_stylebox_override("fill", ThemeBuilder.make_progress_fill(s_col))
		cell_vbox.add_child(pb)
		stat_bars[s_key] = pb

	# BÖLGE 4: Alt Etkileşim Dock'u ve "+1 YAŞ İLERLE" Mühür Butonu (~220px)
	var dock_panel: PanelContainer = PanelContainer.new()
	dock_panel.custom_minimum_size = Vector2(0.0, 210.0)
	dock_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 3, 12, 14))
	main_vbox.add_child(dock_panel)

	var dock_vbox: VBoxContainer = VBoxContainer.new()
	dock_vbox.add_theme_constant_override("separation", 12)
	dock_panel.add_child(dock_vbox)

	age_plus_btn = Button.new()
	age_plus_btn.text = "✒️  +1 YAŞ İLERLE  (YILI DEVİR)"
	age_plus_btn.custom_minimum_size = Vector2(0.0, 78.0)
	ThemeBuilder.apply_seal_age_button_theme(age_plus_btn)
	age_plus_btn.pressed.connect(_on_age_plus_pressed)
	dock_vbox.add_child(age_plus_btn)

	var drawers_hbox: HBoxContainer = HBoxContainer.new()
	drawers_hbox.add_theme_constant_override("separation", 10)
	dock_vbox.add_child(drawers_hbox)

	var drawer_specs: Array = [
		["career", "💼 Kariyer & Finans"],
		["relations", "🤝 İlişkiler & Aile"],
		["lifestyle", "🌍 Yaşam & Göç"],
		["identity", "📜 Kimlik & İzler"]
	]
	for d_spec in drawer_specs:
		var d_key: String = str(d_spec[0])
		var d_title: String = str(d_spec[1])
		var d_btn: Button = Button.new()
		d_btn.text = d_title
		d_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		d_btn.custom_minimum_size = Vector2(0.0, 74.0)
		ThemeBuilder.apply_button_theme(d_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 19)
		d_btn.pressed.connect(func() -> void:
			_open_drawer(d_key)
		)
		drawers_hbox.add_child(d_btn)

	# 3. Çekmece (Drawer) Katmanı
	_build_drawer_overlay()

	# 4. Modal Yöneticisi (Olay Kartları, Doğum Raporu, Ölüm Raporu)
	modal_manager = ModalManager.new()
	modal_manager.event_choice_selected.connect(_on_event_choice_selected)
	modal_manager.new_life_requested.connect(_start_new_life)
	modal_manager.continue_as_child_requested.connect(_on_continue_as_child)
	add_child(modal_manager)

	# 5. Tam Ekran Kağıt Dokusu ve Vinyet Shader Katmanı
	var shader_rect: ColorRect = ColorRect.new()
	shader_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shader_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh: Shader = load("res://ui/paper_grain.gdshader")
	if sh != null:
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = sh
		shader_rect.material = sm
	add_child(shader_rect)

func _build_drawer_overlay() -> void:
	drawer_overlay = Control.new()
	drawer_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	drawer_overlay.visible = false
	add_child(drawer_overlay)

	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.11, 0.098, 0.09, 0.62)
	drawer_overlay.add_child(dim)

	var margin: MarginContainer = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 56)
	margin.add_theme_constant_override("margin_bottom", 56)
	drawer_overlay.add_child(margin)

	var panel: PanelContainer = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_BG, ThemeBuilder.COLOR_INK_DARK, 3, 14, 20))
	margin.add_child(panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	panel.add_child(vbox)

	var top_bar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(top_bar)

	drawer_title_lbl = Label.new()
	drawer_title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	drawer_title_lbl.add_theme_font_size_override("font_size", 26)
	top_bar.add_child(drawer_title_lbl)

	var close_btn: Button = Button.new()
	close_btn.text = "✖ Kapat"
	ThemeBuilder.apply_button_theme(close_btn, ThemeBuilder.COLOR_TERRACOTTA, ThemeBuilder.COLOR_PAPER_BG, 19)
	close_btn.pressed.connect(func() -> void:
		drawer_overlay.visible = false
		_refresh_ui()
	)
	top_bar.add_child(close_btn)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	drawer_content_vbox = VBoxContainer.new()
	drawer_content_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	drawer_content_vbox.add_theme_constant_override("separation", 12)
	scroll.add_child(drawer_content_vbox)

# Yeni Hayat Başlatma (1in8b Nüfus Olasılığı veya Özel Seçim)
func _start_new_life(custom_country: String = "", custom_gender: String = "") -> void:
	var chosen_code: String = custom_country
	if chosen_code == "" or not countries_db.has(chosen_code):
		chosen_code = _roll_country_by_population()

	var c_info: Dictionary = countries_db.get(chosen_code, {})
	gs.reset_for_new_life(chosen_code, c_info, custom_gender, 0, 1, "")
	npc_engine.generate_initial_family(gs, c_info)

	for child in timeline_vbox.get_children():
		child.queue_free()

	_append_year_divider(0, gs.birth_year)
	_append_timeline_entry(
		"🌍 [b]%s, %s[/b] şehrinde dünyaya gözlerini açtın. Ailen [b]%s[/b] statüsünde. (%s)" % [
			str(c_info.get("name", chosen_code)),
			gs.city,
			gs.get_social_class_label(),
			gs.get_parents_summary_text()
		],
		ThemeBuilder.COLOR_OCHRE
	)

	_refresh_ui()
	modal_manager.show_birth_report(gs, c_info)

func _on_continue_as_child(child_npc: Dictionary) -> void:
	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	var parent_name: String = gs.full_name
	npc_engine.transfer_legacy_to_child(gs, child_npc, c_info)

	for child in timeline_vbox.get_children():
		child.queue_free()

	_append_year_divider(gs.age, gs.birth_year + gs.age)
	_append_timeline_entry(
		"👑 [b]%d. KUŞAK MİRAS DEVRİ:[/b] Ebeveynin %s vefat ettikten sonra aile mirasını devraldın. Şimdi kendi kaderini yazma sırası sende!" % [
			gs.generation, parent_name
		],
		ThemeBuilder.COLOR_PLUM
	)
	_refresh_ui()

func _roll_country_by_population() -> String:
	var total_w: float = 0.0
	for k in countries_db.keys():
		var c: Dictionary = countries_db[k]
		total_w += float(c.get("spawn_weight", 5.0))
	var r: float = randf() * total_w
	var acc: float = 0.0
	for k in countries_db.keys():
		var c: Dictionary = countries_db[k]
		acc += float(c.get("spawn_weight", 5.0))
		if r <= acc:
			return str(k)
	return "TR"

# +1 YAŞ İLERLE Butonu Akışı
func _on_age_plus_pressed() -> void:
	if not gs.is_alive:
		var ending_info: Dictionary = economy.evaluate_ending_archetype(gs)
		var comp_info: Dictionary = economy.compute_1in8b_global_comparison(gs)
		modal_manager.show_death_modal(gs, ending_info, comp_info)
		return

	# Dokunsal Tween animasyonu
	age_plus_btn.pivot_offset = age_plus_btn.size * 0.5
	var tw: Tween = create_tween()
	tw.tween_property(age_plus_btn, "scale", Vector2(0.95, 0.92), 0.07)
	tw.tween_property(age_plus_btn, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK)

	gs.age += 1
	var cur_year: int = gs.birth_year + gs.age
	_append_year_divider(gs.age, cur_year)

	var c_info: Dictionary = countries_db.get(gs.country_code, {})

	# 1. Yıllık Ekonomi, Enflasyon ve Okul Geçişleri
	var econ_logs: Array = economy.process_yearly_economy_and_school(gs)
	for l in econ_logs:
		_append_timeline_entry(str(l), ThemeBuilder.COLOR_SAGE)

	# 2. Yıllık NPC Yaşlanma ve Aile Olayları
	var npc_logs: Array = npc_engine.process_yearly_npcs(gs, c_info)
	for nl in npc_logs:
		_append_timeline_entry(str(nl), ThemeBuilder.COLOR_PRUSSIAN)

	# 3. Yaşlılık ve Sağlık Kaynaklı Doğal Vefat Kontrolü
	var life_exp: int = int(c_info.get("life_expectancy", 78))
	if gs.age >= 55:
		gs.health = clampi(gs.health - randi_range(1, 3), 0, 100)

	if gs.health <= 0 or (gs.age >= life_exp and randf() < clampf(float(gs.age - life_exp + 4) * 0.045, 0.03, 0.65)):
		gs.is_alive = false
		gs.death_reason = "Ağır sağlık kaybı ve organ yetmezliği" if gs.health <= 0 else "İleri yaşa bağlı doğal nedenler"
		_append_timeline_entry("🕯️ [b]%d yaşında hayata veda ettin.[/b] (%s)" % [gs.age, gs.death_reason], ThemeBuilder.COLOR_PLUM)
		_refresh_ui()
		var ending_info: Dictionary = economy.evaluate_ending_archetype(gs)
		var comp_info: Dictionary = economy.compute_1in8b_global_comparison(gs)
		modal_manager.show_death_modal(gs, ending_info, comp_info)
		return

	# 4. Bu Yaşa Uygun Olay veya Kelebek Etkisi Sonucu Seçimi
	var ev: Dictionary = causality.pick_event_for_age(gs)
	if not ev.is_empty():
		modal_manager.show_event_modal(ev, gs, causality)
	else:
		_append_timeline_entry("Yaprakların sakin hışırdadığı, rutinin devam ettiği dingin bir yıl geçti.", ThemeBuilder.COLOR_INK_MUTED)

	_refresh_ui()

func _on_event_choice_selected(event_data: Dictionary, choice_data: Dictionary) -> void:
	var res: Dictionary = causality.apply_choice_consequences(event_data, choice_data, gs)
	var out_txt: String = str(res.get("outcome_text", ""))
	var badges: Array = res.get("badges", [])
	var cat: String = str(event_data.get("category", "yasam"))
	var col: Color = ThemeBuilder.get_category_color(cat)

	var origin_prefix: String = ""
	var origin_note: String = str(event_data.get("_origin_note", ""))
	if origin_note != "":
		origin_prefix = "[color=#C84B31][b]📌 GEÇMİŞİN İZİ (%s):[/b][/color]\n" % origin_note

	var badge_line: String = ""
	if not badges.is_empty():
		badge_line = "\n[color=#355070][b]" + "  •  ".join(badges) + "[/b][/color]"

	var full_entry: String = "%s[b]%s:[/b] %s%s" % [
		origin_prefix,
		str(event_data.get("title", "Olay")),
		out_txt,
		badge_line
	]
	_append_timeline_entry(full_entry, col)

	if gs.health <= 0:
		gs.is_alive = false
		gs.death_reason = str(event_data.get("title", "Talihsiz Kaza / Hastalık"))
		_append_timeline_entry("🕯️ [b]%d yaşında hayatını kaybettin.[/b]" % gs.age, ThemeBuilder.COLOR_PLUM)
		var ending_info: Dictionary = economy.evaluate_ending_archetype(gs)
		var comp_info: Dictionary = economy.compute_1in8b_global_comparison(gs)
		modal_manager.show_death_modal(gs, ending_info, comp_info)

	_refresh_ui()

func _append_year_divider(age_num: int, year_num: int) -> void:
	var stage_name: String = "BEBEKLİK"
	if age_num >= 60:
		stage_name = "YAŞLILIK & BİLGELİK"
	elif age_num >= 23:
		stage_name = "YETİŞKİNLİK"
	elif age_num >= 13:
		stage_name = "GENÇLİK"
	elif age_num >= 4:
		stage_name = "ÇOCUKLUK"

	var div_lbl: Label = Label.new()
	div_lbl.text = "───  %d YAŞ (%d)  •  %s  ───" % [age_num, year_num, stage_name]
	div_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	div_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_INK_SOFT)
	div_lbl.add_theme_font_size_override("font_size", 19)
	timeline_vbox.add_child(div_lbl)
	_scroll_timeline_to_bottom()

func _append_timeline_entry(bbcode_text: String, stripe_col: Color) -> void:
	var card: PanelContainer = PanelContainer.new()
	card.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, stripe_col, 14))

	var rtl: RichTextLabel = RichTextLabel.new()
	rtl.bbcode_enabled = true
	rtl.fit_content = true
	rtl.scroll_active = false
	rtl.text = bbcode_text
	card.add_child(rtl)

	timeline_vbox.add_child(card)
	_scroll_timeline_to_bottom()

func _scroll_timeline_to_bottom() -> void:
	await get_tree().process_frame
	if is_instance_valid(timeline_scroll):
		var vbar: VScrollBar = timeline_scroll.get_v_scroll_bar()
		if vbar != null:
			timeline_scroll.scroll_vertical = int(vbar.max_value)

func _refresh_ui() -> void:
	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	var flag_str: String = str(c_info.get("flag", "🌍"))
	var c_name: String = str(c_info.get("name", gs.country_code))

	name_label.text = "%s (%d Yaş)" % [gs.full_name, gs.age]
	sub_identity_label.text = "%s %s, %s  •  %d. Kuşak" % [flag_str, c_name, gs.city, gs.generation]
	class_badge_label.text = "[%s]  •  %s" % [gs.get_social_class_label(), gs.get_education_label()]

	var net_flow: int = gs.annual_income + gs.part_time_income - gs.annual_expenses
	var flow_str: String = ("+%d" % net_flow) if net_flow >= 0 else str(net_flow)
	job_and_money_label.text = "💼 %s   |   💰 Bakiye: %s %d   (Yıllık Net: %s %s)" % [
		gs.current_job_title, gs.currency_symbol, gs.money, gs.currency_symbol, flow_str
	]

	# Yaşam evresi mühür ikonu
	var seal_file: String = "res://assets/illustrations/seal_infancy.svg"
	if gs.age >= 60:
		seal_file = "res://assets/illustrations/seal_senior.svg"
	elif gs.age >= 23:
		seal_file = "res://assets/illustrations/seal_adult.svg"
	elif gs.age >= 13:
		seal_file = "res://assets/illustrations/seal_youth.svg"
	elif gs.age >= 4:
		seal_file = "res://assets/illustrations/seal_childhood.svg"
	if ResourceLoader.exists(seal_file):
		stage_seal_rect.texture = load(seal_file)

	# Portreyi yeniden çiz
	portrait_view.setup_portrait(gs.get_portrait_dict())

	# 6 İstatistik barını güncelle
	var map_vals: Dictionary = {
		"health": gs.health,
		"happiness": gs.happiness,
		"smart": gs.smart,
		"reputation": gs.reputation,
		"sanity": gs.sanity,
		"karma": gs.karma
	}
	for k in map_vals.keys():
		var v: int = int(map_vals[k])
		if stat_bars.has(k):
			var pb: ProgressBar = stat_bars[k]
			pb.value = float(v)
		if stat_val_labels.has(k):
			var lbl: Label = stat_val_labels[k]
			lbl.text = "%%%d" % v

# 4 Ana Çekmece (Drawer) İçerikleri
func _open_drawer(drawer_key: String) -> void:
	for ch in drawer_content_vbox.get_children():
		ch.queue_free()

	match drawer_key:
		"career":
			drawer_title_lbl.text = "💼 KARİYER, EĞİTİM VE FİNANS"
			_populate_career_drawer()
		"relations":
			drawer_title_lbl.text = "🤝 AİLE VE İLİŞKİLER"
			_populate_relations_drawer()
		"lifestyle":
			drawer_title_lbl.text = "🌍 YAŞAM TARZI VE GÖÇ"
			_populate_lifestyle_drawer()
		"identity":
			drawer_title_lbl.text = "📜 KİMLİK, İZLER VE KELEBEK ETKİSİ"
			_populate_identity_drawer()

	drawer_overlay.visible = true

func _add_drawer_section_header(title_txt: String) -> void:
	var lbl: Label = Label.new()
	lbl.text = "✦ " + title_txt
	lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_PRUSSIAN)
	lbl.add_theme_font_size_override("font_size", 22)
	drawer_content_vbox.add_child(lbl)

func _populate_career_drawer() -> void:
	var summary_card: PanelContainer = PanelContainer.new()
	summary_card.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_SAGE, 14))
	var rtl: RichTextLabel = RichTextLabel.new()
	rtl.bbcode_enabled = true
	rtl.fit_content = true
	rtl.scroll_active = false
	rtl.text = "[b]Mevcut Meslek:[/b] %s (%d yıl deneyim)\n" % [gs.current_job_title, gs.job_experience_years] + 		"[b]Eğitim Durumu:[/b] %s\n" % gs.get_education_label() + 		"[b]Nakit Bakiye:[/b] %s %d  |  [b]Toplam Net Servet:[/b] %s %d\n" % [gs.currency_symbol, gs.money, gs.currency_symbol, economy.get_total_net_worth(gs)] + 		"[b]Öğrenci Kredisi Borcu:[/b] %s %d" % [gs.currency_symbol, gs.student_loan]
	summary_card.add_child(rtl)
	drawer_content_vbox.add_child(summary_card)

	# Terfi butonu
	if gs.current_job_id != "unemployed" and gs.age >= 18:
		var promo_btn: Button = Button.new()
		promo_btn.text = "📈 Mevcut İşinde Terfi / Zam Talep Et"
		ThemeBuilder.apply_button_theme(promo_btn, ThemeBuilder.COLOR_OCHRE, ThemeBuilder.COLOR_INK_DARK, 20)
		promo_btn.pressed.connect(func() -> void:
			var msg: String = economy.request_promotion(gs)
			_append_timeline_entry(msg, ThemeBuilder.COLOR_OCHRE)
			_open_drawer("career")
			_refresh_ui()
		)
		drawer_content_vbox.add_child(promo_btn)

	# Üniversite Bölümleri (17-26 yaş arası lise mezunları için)
	if gs.age >= 17 and gs.education_level == "lise_mezunu":
		_add_drawer_section_header("Üniversite Fakülteleri (4 Yıllık Lisans)")
		var majors: Array = [
			["Tıp Fakültesi", "tag_tip_diplomasi", 78],
			["Hukuk Fakültesi", "tag_hukuk_diplomasi", 72],
			["Bilgisayar & Yazılım Mühendisliği", "tag_muhendislik_diplomasi", 70],
			["İktisat, İşletme & Finans", "tag_finans_diplomasi", 60],
			["Siyaset Bilimi & Uluslararası İlişkiler", "tag_siyaset_diplomasi", 62],
			["Edebiyat, Sanat & Gazetecilik", "tag_sanat_diplomasi", 52]
		]
		for mj in majors:
			var m_name: String = str(mj[0])
			var m_tag: String = str(mj[1])
			var req_sm: int = int(mj[2])
			var u_btn: Button = Button.new()
			u_btn.text = "🎓 %s (Gereken Zeka: %d) - Kredili/Burslu Kayıt Ol" % [m_name, req_sm]
			ThemeBuilder.apply_button_theme(u_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 19)
			u_btn.disabled = (gs.smart < req_sm)
			u_btn.pressed.connect(func() -> void:
				var msg: String = economy.enroll_university(gs, m_name, m_tag, true)
				_append_timeline_entry(msg, ThemeBuilder.COLOR_PRUSSIAN)
				_open_drawer("career")
				_refresh_ui()
			)
			drawer_content_vbox.add_child(u_btn)

	# Yatırım & Enflasyondan Korunma Araçları
	if gs.age >= 18:
		_add_drawer_section_header("Yatırım, Döviz/Altın ve Portföy Yönetimi")
		var inv_amount: int = max(100, int(round(1000.0 * gs.usd_exchange_rate)))
		var fx_btn: Button = Button.new()
		fx_btn.text = "🪙 Döviz / Altın Sepeti Al (%s %d) - Enflasyon Koruması (Mevcut: %s %d)" % [
			gs.currency_symbol, inv_amount, gs.currency_symbol, int(gs.financial_portfolio.get("fx_usd", 0))
		]
		ThemeBuilder.apply_button_theme(fx_btn, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 18)
		fx_btn.pressed.connect(func() -> void:
			if gs.money >= inv_amount:
				gs.money -= inv_amount
				gs.financial_portfolio["fx_usd"] = int(gs.financial_portfolio.get("fx_usd", 0)) + inv_amount
				_append_timeline_entry("🪙 Birikiminin %s %d kısmını döviz ve altın sepetine çevirerek enflasyon korumasına aldın." % [gs.currency_symbol, inv_amount], ThemeBuilder.COLOR_SAGE)
				_open_drawer("career")
				_refresh_ui()
		)
		drawer_content_vbox.add_child(fx_btn)

		var idx_btn: Button = Button.new()
		idx_btn.text = "📊 Küresel Hisse Senedi Fonu Al (%s %d) (Mevcut: %s %d)" % [
			gs.currency_symbol, inv_amount, gs.currency_symbol, int(gs.financial_portfolio.get("index_fund", 0))
		]
		ThemeBuilder.apply_button_theme(idx_btn, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 18)
		idx_btn.pressed.connect(func() -> void:
			if gs.money >= inv_amount:
				gs.money -= inv_amount
				gs.financial_portfolio["index_fund"] = int(gs.financial_portfolio.get("index_fund", 0)) + inv_amount
				_append_timeline_entry("📊 Küresel endeks fonuna %s %d yatırım yaptın." % [gs.currency_symbol, inv_amount], ThemeBuilder.COLOR_SAGE)
				_open_drawer("career")
				_refresh_ui()
		)
		drawer_content_vbox.add_child(idx_btn)

		var liquidate_btn: Button = Button.new()
		liquidate_btn.text = "💵 Tüm Yatırım Portföyünü Nakde Çevir"
		ThemeBuilder.apply_button_theme(liquidate_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 18)
		liquidate_btn.pressed.connect(func() -> void:
			var total_p: int = int(gs.financial_portfolio.get("fx_usd", 0)) + int(gs.financial_portfolio.get("index_fund", 0)) + int(gs.financial_portfolio.get("crypto_spec", 0))
			if total_p > 0:
				gs.money += total_p
				gs.financial_portfolio = {"fx_usd": 0, "index_fund": 0, "crypto_spec": 0}
				_append_timeline_entry("💵 Yatırım portföyünü bozdurarak %s %d nakit elde ettin." % [gs.currency_symbol, total_p], ThemeBuilder.COLOR_SAGE)
				_open_drawer("career")
				_refresh_ui()
		)
		drawer_content_vbox.add_child(liquidate_btn)

	# Tam Zamanlı İş İlanları (60+ Meslekten Yaşa ve Niteliklere Göre Listeleme)
	if gs.age >= 16:
		_add_drawer_section_header("Tam Zamanlı İş ve Kariyer İlanları")
		for career in economy.careers_list:
			var c_title: String = str(career.get("title", "İş"))
			var min_sm: int = int(career.get("min_smart", 0))
			var req_edu: String = str(career.get("req_education", "none"))
			var base_usd: int = int(career.get("base_salary_usd", 10000))
			var est_sal: int = int(round(float(base_usd) * gs.usd_exchange_rate))

			var job_btn: Button = Button.new()
			job_btn.text = "💼 %s  •  ~%s %d/yıl  (Zeka: %d+ | Eğitim: %s)" % [
				c_title, gs.currency_symbol, est_sal, min_sm, req_edu.to_upper()
			]
			job_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
			ThemeBuilder.apply_button_theme(job_btn, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 18)
			var captured_career: Dictionary = career
			job_btn.pressed.connect(func() -> void:
				var res: Dictionary = economy.apply_for_career(gs, captured_career)
				_append_timeline_entry(str(res.get("msg", "")), ThemeBuilder.COLOR_SAGE if bool(res.get("ok", false)) else ThemeBuilder.COLOR_TERRACOTTA)
				_open_drawer("career")
				_refresh_ui()
			)
			drawer_content_vbox.add_child(job_btn)

func _populate_relations_drawer() -> void:
	var c_info: Dictionary = countries_db.get(gs.country_code, {})

	if gs.age >= 16:
		var top_actions: HBoxContainer = HBoxContainer.new()
		top_actions.add_theme_constant_override("separation", 10)
		drawer_content_vbox.add_child(top_actions)

		var meet_btn: Button = Button.new()
		meet_btn.text = "❤️ Yeni Biriyle Tanış (Flört)"
		meet_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		ThemeBuilder.apply_button_theme(meet_btn, ThemeBuilder.COLOR_TERRACOTTA, ThemeBuilder.COLOR_PAPER_BG, 19)
		meet_btn.pressed.connect(func() -> void:
			var msg: String = npc_engine.find_new_partner(gs, c_info)
			_append_timeline_entry(msg, ThemeBuilder.COLOR_TERRACOTTA)
			_open_drawer("relations")
			_refresh_ui()
		)
		top_actions.add_child(meet_btn)

		if not gs.get_spouse().is_empty() or gs.age >= 21:
			var child_btn: Button = Button.new()
			child_btn.text = "👶 Çocuk Sahibi Ol / Evlat Edin"
			child_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			ThemeBuilder.apply_button_theme(child_btn, ThemeBuilder.COLOR_SAGE, ThemeBuilder.COLOR_PAPER_BG, 19)
			child_btn.pressed.connect(func() -> void:
				var target_npc: Dictionary = gs.get_spouse()
				if target_npc.is_empty():
					target_npc = {"alive": true, "name": "Evlat Edinme Kurumu", "relation": 90}
				var msg: String = npc_engine.interact_with_npc(gs, target_npc, "have_child", c_info)
				_append_timeline_entry(msg, ThemeBuilder.COLOR_SAGE)
				_open_drawer("relations")
				_refresh_ui()
			)
			top_actions.add_child(child_btn)

	_add_drawer_section_header("Aile Bireyleri, Eş, Çocuklar ve Dostlar")
	for npc in gs.npcs:
		var card: PanelContainer = PanelContainer.new()
		var is_alive_npc: bool = bool(npc.get("alive", true))
		var border_col: Color = ThemeBuilder.COLOR_SAGE if is_alive_npc else ThemeBuilder.COLOR_INK_MUTED
		card.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, border_col, 12))
		drawer_content_vbox.add_child(card)

		var nvbox: VBoxContainer = VBoxContainer.new()
		nvbox.add_theme_constant_override("separation", 8)
		card.add_child(nvbox)

		var status_str: String = "%d Yaş • %s" % [int(npc.get("age", 20)), str(npc.get("job_title", ""))] if is_alive_npc else "🕯️ Merhum / Vefat Etti"
		var n_lbl: Label = Label.new()
		n_lbl.text = "%s (%s)  —  %s  |  İlişki: %%%d" % [
			str(npc.get("name", "")),
			str(npc.get("role", "")),
			status_str,
			int(npc.get("relation", 50))
		]
		n_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		n_lbl.add_theme_font_size_override("font_size", 19)
		nvbox.add_child(n_lbl)

		if is_alive_npc:
			var act_hbox: HBoxContainer = HBoxContainer.new()
			act_hbox.add_theme_constant_override("separation", 8)
			nvbox.add_child(act_hbox)

			var captured_npc: Dictionary = npc
			var btn_chat: Button = Button.new()
			btn_chat.text = "☕ Sohbet"
			ThemeBuilder.apply_button_theme(btn_chat, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 17)
			btn_chat.pressed.connect(func() -> void:
				var msg: String = npc_engine.interact_with_npc(gs, captured_npc, "chat", c_info)
				_append_timeline_entry(msg, ThemeBuilder.COLOR_OCHRE)
				_open_drawer("relations")
				_refresh_ui()
			)
			act_hbox.add_child(btn_chat)

			var btn_time: Button = Button.new()
			btn_time.text = "🎭 Vakit Geçir"
			ThemeBuilder.apply_button_theme(btn_time, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 17)
			btn_time.pressed.connect(func() -> void:
				var msg: String = npc_engine.interact_with_npc(gs, captured_npc, "spend_time", c_info)
				_append_timeline_entry(msg, ThemeBuilder.COLOR_OCHRE)
				_open_drawer("relations")
				_refresh_ui()
			)
			act_hbox.add_child(btn_time)

			if gs.age >= 18:
				var btn_gift: Button = Button.new()
				btn_gift.text = "🎁 Harçlık/Hediye"
				ThemeBuilder.apply_button_theme(btn_gift, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 17)
				btn_gift.pressed.connect(func() -> void:
					var msg: String = npc_engine.interact_with_npc(gs, captured_npc, "gift_money", c_info)
					_append_timeline_entry(msg, ThemeBuilder.COLOR_SAGE)
					_open_drawer("relations")
					_refresh_ui()
				)
				act_hbox.add_child(btn_gift)

			if str(captured_npc.get("role", "")) == "Partner" and gs.get_spouse().is_empty():
				var btn_marry: Button = Button.new()
				btn_marry.text = "💍 Evlenme Teklif Et"
				ThemeBuilder.apply_button_theme(btn_marry, ThemeBuilder.COLOR_TERRACOTTA, ThemeBuilder.COLOR_PAPER_BG, 17)
				btn_marry.pressed.connect(func() -> void:
					var msg: String = npc_engine.interact_with_npc(gs, captured_npc, "propose_marriage", c_info)
					_append_timeline_entry(msg, ThemeBuilder.COLOR_TERRACOTTA)
					_open_drawer("relations")
					_refresh_ui()
				)
				act_hbox.add_child(btn_marry)

func _populate_lifestyle_drawer() -> void:
	_add_drawer_section_header("Sağlık, Zihin ve Kişisel Gelişim Aktiviteleri")

	var activities: Array = [
		["🏥 Kapsamlı Hastane Muayenesi ve Tedavi", 180, {"health": 14, "sanity": 3}, "Uzman hekim kontrolünden geçtin ve tedavin yapıldı."],
		["🛋️ Psikoterapi ve Ruhsal Danışmanlık Seansı", 140, {"sanity": 15, "happiness": 6}, "Terapistinle geçmiş travmalarını ve kaygılarını çözümledin."],
		["🏋️ Düzenli Spor, Doğa Yürüyüşü ve Kondisyon", 50, {"health": 8, "happiness": 6, "sanity": 5}, "Bedensel disiplin ve temiz hava enerjini tazeledi."],
		["📖 Felsefe, Bilim ve Klasik Edebiyat Okumaları", 30, {"smart": 8, "sanity": 4, "karma": 3}, "Kütüphanede geçirdiğin saatler zihnini berraklaştırdı."],
		["🍲 Hayırseverlik ve Aşevi Gönüllülüğü", 80, {"karma": 12, "reputation": 7, "happiness": 6}, "İhtiyaç sahiplerine el uzatarak toplumsal dayanışmayı büyüttün."]
	]

	for act in activities:
		var a_title: String = str(act[0])
		var base_cost_usd: int = int(act[1])
		var local_cost: int = int(round(float(base_cost_usd) * gs.usd_exchange_rate))
		var eff: Dictionary = act[2]
		var desc: String = str(act[3])

		var a_btn: Button = Button.new()
		a_btn.text = "%s (%s %d)" % [a_title, gs.currency_symbol, local_cost]
		a_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		ThemeBuilder.apply_button_theme(a_btn, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 19)
		a_btn.pressed.connect(func() -> void:
			if gs.age >= 18 and gs.money < local_cost:
				_append_timeline_entry("⚠️ Bu aktivite için yeterli paran yok (%s %d gerekli)." % [gs.currency_symbol, local_cost], ThemeBuilder.COLOR_TERRACOTTA)
			else:
				if gs.age >= 18:
					gs.money -= local_cost
				gs.apply_effects(eff)
				_append_timeline_entry("✨ " + desc, ThemeBuilder.COLOR_SAGE)
			_open_drawer("lifestyle")
			_refresh_ui()
		)
		drawer_content_vbox.add_child(a_btn)

	if gs.age >= 18:
		_add_drawer_section_header("Yıllık Yaşam Standardı Seçimi (Gider & Refah Dengesi)")
		var styles_hbox: HBoxContainer = HBoxContainer.new()
		styles_hbox.add_theme_constant_override("separation", 10)
		drawer_content_vbox.add_child(styles_hbox)

		for st_item in [["mutevazi", "Mütevazı (%65 Gider)"], ["standart", "Standart (%100 Gider)"], ["luks", "Lüks (%225 Gider)"]]:
			var st_code: String = str(st_item[0])
			var st_lbl: String = str(st_item[1])
			var s_btn: Button = Button.new()
			s_btn.text = ("✓ " if gs.lifestyle_level == st_code else "") + st_lbl
			s_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			var bg_c: Color = ThemeBuilder.COLOR_OCHRE if gs.lifestyle_level == st_code else ThemeBuilder.COLOR_PAPER_ACCENT
			ThemeBuilder.apply_button_theme(s_btn, bg_c, ThemeBuilder.COLOR_INK_DARK, 18)
			s_btn.pressed.connect(func() -> void:
				gs.lifestyle_level = st_code
				_open_drawer("lifestyle")
				_refresh_ui()
			)
			styles_hbox.add_child(s_btn)

		_add_drawer_section_header("🌍 Sınır Ötesi Göç ve Yeni Ülkeye Yerleşim (15 Ülke)")
		for t_code in countries_db.keys():
			if str(t_code) == gs.country_code:
				continue
			var t_info: Dictionary = countries_db[t_code]
			var row_hbox: HBoxContainer = HBoxContainer.new()
			row_hbox.add_theme_constant_override("separation", 8)
			drawer_content_vbox.add_child(row_hbox)

			var c_lbl: Label = Label.new()
			c_lbl.text = "%s %s (Kişi Başı: $%d)" % [
				str(t_info.get("flag", "🌍")),
				str(t_info.get("name", t_code)),
				int(t_info.get("gdp_per_capita_usd", 10000))
			]
			c_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			c_lbl.add_theme_font_size_override("font_size", 18)
			row_hbox.add_child(c_lbl)

			var target_str: String = str(t_code)
			var btn_legal: Button = Button.new()
			btn_legal.text = "🛂 Yasal Vize"
			ThemeBuilder.apply_button_theme(btn_legal, ThemeBuilder.COLOR_PRUSSIAN, ThemeBuilder.COLOR_PAPER_BG, 16)
			btn_legal.pressed.connect(func() -> void:
				var res: Dictionary = economy.attempt_migration(gs, target_str, true)
				_append_timeline_entry(str(res.get("msg", "")), ThemeBuilder.COLOR_PRUSSIAN)
				drawer_overlay.visible = false
				_refresh_ui()
			)
			row_hbox.add_child(btn_legal)

			var btn_illegal: Button = Button.new()
			btn_illegal.text = "🌊 Kaçak Rota"
			ThemeBuilder.apply_button_theme(btn_illegal, ThemeBuilder.COLOR_PLUM, ThemeBuilder.COLOR_PAPER_BG, 16)
			btn_illegal.pressed.connect(func() -> void:
				var res: Dictionary = economy.attempt_migration(gs, target_str, false)
				_append_timeline_entry(str(res.get("msg", "")), ThemeBuilder.COLOR_PLUM)
				drawer_overlay.visible = false
				_refresh_ui()
			)
			row_hbox.add_child(btn_illegal)

func _populate_identity_drawer() -> void:
	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	_add_drawer_section_header("8 Milyarda 1: Demografik ve Kişisel Kimlik")

	var id_card: PanelContainer = PanelContainer.new()
	id_card.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_PRUSSIAN, 14))
	var id_rtl: RichTextLabel = RichTextLabel.new()
	id_rtl.bbcode_enabled = true
	id_rtl.fit_content = true
	id_rtl.scroll_active = false
	id_rtl.text = "[b]Ad Soyad:[/b] %s\n" % gs.full_name + 		"[b]Doğum Yeri:[/b] %s  |  [b]Güncel Ülke:[/b] %s (%s)\n" % [gs.origin_country_code, str(c_info.get("name", "")), gs.city] + 		"[b]Sosyal Sınıf:[/b] %s\n" % gs.get_social_class_label() + 		"[b]Kazanılan Kişilik Özellikleri (Traits):[/b] %s\n" % (", ".join(gs.traits) if not gs.traits.is_empty() else "Henüz belirginleşmedi") + 		"[b]Hayat İzleri (Etiketler):[/b] %s" % (", ".join(gs.life_tags) if not gs.life_tags.is_empty() else "Yok")
	id_card.add_child(id_rtl)
	drawer_content_vbox.add_child(id_card)

	_add_drawer_section_header("🦋 Bekleyen Kelebek Etkileri (Geçmiş Kararlarının Tohumları)")
	if gs.scheduled_events.is_empty():
		var empty_lbl: Label = Label.new()
		empty_lbl.text = "Şu anda geleceğe ertelenmiş gizli bir kelebek etkisi bulunmuyor."
		empty_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_INK_MUTED)
		drawer_content_vbox.add_child(empty_lbl)
	else:
		for item in gs.scheduled_events:
			var sc_card: PanelContainer = PanelContainer.new()
			sc_card.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_TERRACOTTA, 12))
			var sc_lbl: Label = Label.new()
			sc_lbl.text = "📌 %d Yaşında Tetiklenecek İz: %s" % [
				int(item.get("trigger_age", gs.age + 1)),
				str(item.get("origin_note", "Geçmişteki bir seçimin sonucu"))
			]
			sc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			sc_card.add_child(sc_lbl)
			drawer_content_vbox.add_child(sc_card)
