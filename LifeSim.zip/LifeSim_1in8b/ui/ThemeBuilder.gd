extends RefCounted

# Zorunlu Editöryal Çini Mürekkebi ve Guaj Boya Renk Paleti
const COLOR_PAPER_BG: Color = Color("#F4EFE6")
const COLOR_PAPER_CARD: Color = Color("#EBE3D5")
const COLOR_PAPER_ACCENT: Color = Color("#E0D5C1")
const COLOR_INK_DARK: Color = Color("#1C1917")
const COLOR_INK_SOFT: Color = Color("#3F3A34")
const COLOR_INK_MUTED: Color = Color("#6E655C")

const COLOR_TERRACOTTA: Color = Color("#C84B31")
const COLOR_SAGE: Color = Color("#4A6B53")
const COLOR_OCHRE: Color = Color("#D49B35")
const COLOR_PRUSSIAN: Color = Color("#355070")
const COLOR_PLUM: Color = Color("#6D435A")

static func make_card_style(bg: Color = COLOR_PAPER_CARD, border_col: Color = COLOR_INK_DARK, border_w: int = 2, corner_r: int = 10, pad: int = 14) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border_col
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(corner_r)
	sb.content_margin_left = float(pad)
	sb.content_margin_right = float(pad)
	sb.content_margin_top = float(pad)
	sb.content_margin_bottom = float(pad)
	sb.shadow_color = Color(0.11, 0.098, 0.09, 0.14)
	sb.shadow_size = 3
	sb.shadow_offset = Vector2(2.0, 3.0)
	return sb

static func make_ribbon_card_style(bg: Color = COLOR_PAPER_CARD, left_stripe: Color = COLOR_PRUSSIAN, pad: int = 14) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = left_stripe
	sb.border_width_left = 8
	sb.border_width_top = 1
	sb.border_width_right = 2
	sb.border_width_bottom = 2
	sb.set_corner_radius_all(8)
	sb.content_margin_left = float(pad + 4)
	sb.content_margin_right = float(pad)
	sb.content_margin_top = float(pad - 2)
	sb.content_margin_bottom = float(pad - 2)
	sb.shadow_color = Color(0.11, 0.098, 0.09, 0.10)
	sb.shadow_size = 2
	sb.shadow_offset = Vector2(1.0, 2.0)
	return sb

static func make_button_style(bg: Color, border_col: Color = COLOR_INK_DARK, border_w: int = 2, corner_r: int = 8, pad_h: int = 14, pad_v: int = 10) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border_col
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(corner_r)
	sb.content_margin_left = float(pad_h)
	sb.content_margin_right = float(pad_h)
	sb.content_margin_top = float(pad_v)
	sb.content_margin_bottom = float(pad_v)
	sb.shadow_color = Color(0.11, 0.098, 0.09, 0.18)
	sb.shadow_size = 2
	sb.shadow_offset = Vector2(2.0, 3.0)
	return sb

static func make_progress_bg() -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = COLOR_PAPER_ACCENT
	sb.border_color = COLOR_INK_DARK
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(6)
	return sb

static func make_progress_fill(fill_color: Color) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = fill_color
	sb.border_color = COLOR_INK_DARK
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_bottom = 1
	sb.border_width_right = 2
	sb.set_corner_radius_all(5)
	return sb

static func apply_button_theme(btn: Button, accent_bg: Color = COLOR_PAPER_ACCENT, text_col: Color = COLOR_INK_DARK, font_sz: int = 21) -> void:
	var normal_sb: StyleBoxFlat = make_button_style(accent_bg, COLOR_INK_DARK, 2, 8, 14, 10)
	var hover_sb: StyleBoxFlat = make_button_style(accent_bg.lightened(0.06), COLOR_INK_DARK, 2, 8, 14, 10)
	var pressed_sb: StyleBoxFlat = make_button_style(accent_bg.darkened(0.08), COLOR_INK_DARK, 3, 8, 14, 10)
	pressed_sb.shadow_offset = Vector2(0.5, 1.0)
	var disabled_sb: StyleBoxFlat = make_button_style(COLOR_PAPER_CARD, COLOR_INK_MUTED, 1, 8, 14, 10)
	disabled_sb.shadow_size = 0

	btn.add_theme_stylebox_override("normal", normal_sb)
	btn.add_theme_stylebox_override("hover", hover_sb)
	btn.add_theme_stylebox_override("pressed", pressed_sb)
	btn.add_theme_stylebox_override("disabled", disabled_sb)
	btn.add_theme_stylebox_override("focus", hover_sb)

	btn.add_theme_color_override("font_color", text_col)
	btn.add_theme_color_override("font_hover_color", text_col)
	btn.add_theme_color_override("font_pressed_color", text_col)
	btn.add_theme_color_override("font_disabled_color", COLOR_INK_MUTED)
	btn.add_theme_font_size_override("font_size", font_sz)

static func apply_seal_age_button_theme(btn: Button) -> void:
	var normal_sb: StyleBoxFlat = make_button_style(COLOR_TERRACOTTA, COLOR_INK_DARK, 3, 22, 20, 14)
	normal_sb.shadow_size = 4
	normal_sb.shadow_offset = Vector2(2.0, 4.0)
	var hover_sb: StyleBoxFlat = make_button_style(COLOR_TERRACOTTA.lightened(0.08), COLOR_INK_DARK, 3, 22, 20, 14)
	var pressed_sb: StyleBoxFlat = make_button_style(COLOR_TERRACOTTA.darkened(0.10), COLOR_INK_DARK, 3, 22, 20, 14)
	pressed_sb.shadow_offset = Vector2(1.0, 1.0)

	btn.add_theme_stylebox_override("normal", normal_sb)
	btn.add_theme_stylebox_override("hover", hover_sb)
	btn.add_theme_stylebox_override("pressed", pressed_sb)
	btn.add_theme_stylebox_override("focus", hover_sb)

	btn.add_theme_color_override("font_color", COLOR_PAPER_BG)
	btn.add_theme_color_override("font_hover_color", COLOR_PAPER_BG)
	btn.add_theme_color_override("font_pressed_color", COLOR_PAPER_CARD)
	btn.add_theme_font_size_override("font_size", 24)

static func get_category_color(category: String) -> Color:
	match category:
		"egitim", "akademi", "kariyer":
			return COLOR_PRUSSIAN
		"saglik", "ask", "kriz":
			return COLOR_TERRACOTTA
		"finans", "ekonomi", "refah":
			return COLOR_SAGE
		"aile", "firsat", "oyun", "kultamo":
			return COLOR_OCHRE
		"suc", "felsefe", "kader", "sir":
			return COLOR_PLUM
		"goc", "askerlik":
			return COLOR_PRUSSIAN
		_:
			return COLOR_INK_SOFT

static func build_global_theme() -> Theme:
	var theme: Theme = Theme.new()
	theme.set_color("font_color", "Label", COLOR_INK_DARK)
	theme.set_font_size("font_size", "Label", 20)
	theme.set_color("default_color", "RichTextLabel", COLOR_INK_DARK)
	theme.set_font_size("normal_font_size", "RichTextLabel", 21)
	theme.set_font_size("bold_font_size", "RichTextLabel", 22)
	theme.set_stylebox("panel", "PanelContainer", make_card_style())
	return theme
