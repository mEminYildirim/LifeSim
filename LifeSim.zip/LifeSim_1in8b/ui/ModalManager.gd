extends Control

const ThemeBuilder = preload("res://ui/ThemeBuilder.gd")
const HandDrawnPortrait = preload("res://ui/HandDrawnPortrait.gd")

signal event_choice_selected(event_data: Dictionary, choice_data: Dictionary)
signal new_life_requested(custom_country: String, custom_gender: String)
signal continue_as_child_requested(child_npc: Dictionary)

var backdrop: ColorRect
var card_wrapper: MarginContainer
var card_panel: PanelContainer
var card_vbox: VBoxContainer

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false

	backdrop = ColorRect.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.color = Color(0.11, 0.098, 0.09, 0.68)
	add_child(backdrop)

	var center_scroll: ScrollContainer = ScrollContainer.new()
	center_scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(center_scroll)

	card_wrapper = MarginContainer.new()
	card_wrapper.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_wrapper.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card_wrapper.add_theme_constant_override("margin_left", 38)
	card_wrapper.add_theme_constant_override("margin_right", 38)
	card_wrapper.add_theme_constant_override("margin_top", 80)
	card_wrapper.add_theme_constant_override("margin_bottom", 80)
	center_scroll.add_child(card_wrapper)

	card_panel = PanelContainer.new()
	card_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	card_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_card_style(ThemeBuilder.COLOR_PAPER_BG, ThemeBuilder.COLOR_INK_DARK, 3, 14, 24))
	card_wrapper.add_child(card_panel)

	card_vbox = VBoxContainer.new()
	card_vbox.add_theme_constant_override("separation", 16)
	card_panel.add_child(card_vbox)

func _clear_card() -> void:
	for child in card_vbox.get_children():
		child.queue_free()

func _animate_open() -> void:
	visible = true
	card_panel.modulate = Color(1.0, 1.0, 1.0, 0.0)
	card_panel.scale = Vector2(0.94, 0.94)
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(card_panel, "modulate:a", 1.0, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(card_panel, "scale", Vector2.ONE, 0.24).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func close_modal() -> void:
	visible = false
	_clear_card()

func _load_vignette_svg_or_procedural(vignette_key: String, is_seal: bool = false) -> Control:
	var file_prefix: String = "seal_" if is_seal else "vignette_"
	var path: String = "res://assets/illustrations/" + file_prefix + vignette_key + ".svg"
	if ResourceLoader.exists(path):
		var tex: Texture2D = load(path)
		if tex != null:
			var tr: TextureRect = TextureRect.new()
			tr.texture = tex
			tr.custom_minimum_size = Vector2(136.0, 136.0)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			return tr
	var proc: Control = HandDrawnPortrait.new()
	proc.custom_minimum_size = Vector2(136.0, 136.0)
	proc.setup_vignette(vignette_key)
	return proc

# 1. Doğum İstatistik Raporu (8 Milyarda 1: Doğum Raporu)
func show_birth_report(gs: Object, country_info: Dictionary) -> void:
	_clear_card()

	var top_badge: Label = Label.new()
	top_badge.text = "✦ 8 MİLYARDA 1: DOĞUM İSTATİSTİK RAPORU ✦"
	top_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	top_badge.add_theme_color_override("font_color", ThemeBuilder.COLOR_TERRACOTTA)
	top_badge.add_theme_font_size_override("font_size", 21)
	card_vbox.add_child(top_badge)

	var seal_center: CenterContainer = CenterContainer.new()
	seal_center.add_child(_load_vignette_svg_or_procedural("globe_1in8b", true))
	card_vbox.add_child(seal_center)

	var title_lbl: Label = Label.new()
	title_lbl.text = gs.full_name + " Dünyaya Geldi!"
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_lbl.add_theme_font_size_override("font_size", 28)
	card_vbox.add_child(title_lbl)

	var sub_lbl: Label = Label.new()
	var gender_tr: String = "Kız Bebek" if gs.gender == "F" else "Erkek Bebek"
	sub_lbl.text = "%s (%s) • %s • %s" % [
		str(country_info.get("name", "Türkiye")),
		str(gs.city),
		gender_tr,
		str(gs.get_social_class_label())
	]
	sub_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_PRUSSIAN)
	sub_lbl.add_theme_font_size_override("font_size", 20)
	card_vbox.add_child(sub_lbl)

	var report_box: PanelContainer = PanelContainer.new()
	report_box.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_OCHRE, 16))
	card_vbox.add_child(report_box)

	var rtl: RichTextLabel = RichTextLabel.new()
	rtl.bbcode_enabled = true
	rtl.fit_content = true
	rtl.scroll_active = false
	var pop_pct: float = float(country_info.get("global_pop_pct", 1.1))
	var life_exp: int = int(country_info.get("life_expectancy", 78))
	var gdp_pc: int = int(country_info.get("gdp_per_capita_usd", 12000))
	var birth_note: String = str(country_info.get("birth_report_text", ""))
	rtl.text = "[b]Küresel Demografik Gerçeklik:[/b]\n" + 		"• Dünya nüfusunun yalnızca [b]%%%s[/b]'i bu ülkede doğuyor.\n" % str(pop_pct) + 		"• Doğuşta beklenen ortalama yaşam süresi: [b]%d yıl[/b].\n" % life_exp + 		"• Kişi başı ortalama yıllık gelir: [b]$%d[/b].\n" % gdp_pc + 		"• Ailen gelir dağılımında [b]%s[/b] diliminde yer alıyor.\n\n" % gs.get_social_class_label() + 		"[i]%s[/i]" % birth_note
	report_box.add_child(rtl)

	var parents_lbl: RichTextLabel = RichTextLabel.new()
	parents_lbl.bbcode_enabled = true
	parents_lbl.fit_content = true
	parents_lbl.scroll_active = false
	parents_lbl.text = "[b]Aile Ocağı:[/b] " + gs.get_parents_summary_text()
	card_vbox.add_child(parents_lbl)

	var start_btn: Button = Button.new()
	start_btn.text = "Hayat Yolculuğuna Başla"
	ThemeBuilder.apply_seal_age_button_theme(start_btn)
	start_btn.pressed.connect(func() -> void:
		close_modal()
	)
	card_vbox.add_child(start_btn)

	_animate_open()

# 2. Olay Kartı ve Seçenekler (Kelebek Etkisi & Kilitli Seçenek Şeffaflığı)
func show_event_modal(event_data: Dictionary, gs: Object, causality: Object) -> void:
	_clear_card()

	var cat: String = str(event_data.get("category", "yasam"))
	var cat_col: Color = ThemeBuilder.get_category_color(cat)

	# Eğer geçmişteki bir kararın gecikmeli sonucuysa kırmızı damga göster
	var origin_note: String = str(event_data.get("_origin_note", ""))
	if origin_note != "":
		var trace_panel: PanelContainer = PanelContainer.new()
		trace_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_TERRACOTTA, 10))
		var trace_lbl: Label = Label.new()
		trace_lbl.text = "📌 GEÇMİŞİN İZİ: " + origin_note
		trace_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		trace_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_TERRACOTTA)
		trace_lbl.add_theme_font_size_override("font_size", 19)
		trace_panel.add_child(trace_lbl)
		card_vbox.add_child(trace_panel)

	var header_hbox: HBoxContainer = HBoxContainer.new()
	header_hbox.add_theme_constant_override("separation", 14)
	card_vbox.add_child(header_hbox)

	var vig_code: String = str(event_data.get("vignette", "luck"))
	var vig_ctrl: Control = _load_vignette_svg_or_procedural(vig_code, false)
	vig_ctrl.custom_minimum_size = Vector2(110.0, 110.0)
	header_hbox.add_child(vig_ctrl)

	var title_vbox: VBoxContainer = VBoxContainer.new()
	title_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_vbox.add_theme_constant_override("separation", 6)
	header_hbox.add_child(title_vbox)

	var cat_badge: Label = Label.new()
	cat_badge.text = "[%s • %d YAŞ]" % [cat.to_upper(), gs.age]
	cat_badge.add_theme_color_override("font_color", cat_col)
	cat_badge.add_theme_font_size_override("font_size", 18)
	title_vbox.add_child(cat_badge)

	var title_lbl: Label = Label.new()
	title_lbl.text = str(event_data.get("title", "Yaşam Dönemeçi"))
	title_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_lbl.add_theme_font_size_override("font_size", 26)
	title_vbox.add_child(title_lbl)

	var ctx_note: String = str(event_data.get("context_note", ""))
	if ctx_note != "":
		var ctx_lbl: Label = Label.new()
		ctx_lbl.text = ctx_note
		ctx_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ctx_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_INK_MUTED)
		ctx_lbl.add_theme_font_size_override("font_size", 17)
		title_vbox.add_child(ctx_lbl)

	var body_panel: PanelContainer = PanelContainer.new()
	body_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, cat_col, 16))
	card_vbox.add_child(body_panel)

	var body_rtl: RichTextLabel = RichTextLabel.new()
	body_rtl.bbcode_enabled = true
	body_rtl.fit_content = true
	body_rtl.scroll_active = false
	body_rtl.text = str(event_data.get("text", ""))
	body_panel.add_child(body_rtl)

	var choices: Array = event_data.get("choices", [])
	for choice in choices:
		if typeof(choice) != TYPE_DICTIONARY:
			continue
		var eval_res: Dictionary = causality.evaluate_choice_lock(choice, gs)
		var is_unlocked: bool = bool(eval_res.get("unlocked", true))
		var lock_reason: String = str(eval_res.get("reason", ""))

		var ch_btn: Button = Button.new()
		ch_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ch_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var choice_txt: String = str(choice.get("text", "Devam et"))
		if is_unlocked:
			ch_btn.text = "✒️  " + choice_txt
			ThemeBuilder.apply_button_theme(ch_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 20)
			var captured_choice: Dictionary = choice
			ch_btn.pressed.connect(func() -> void:
				close_modal()
				event_choice_selected.emit(event_data, captured_choice)
			)
		else:
			ch_btn.text = "🔒  %s\n      [KİLİTLİ: %s]" % [choice_txt, lock_reason]
			ch_btn.disabled = true
			ThemeBuilder.apply_button_theme(ch_btn, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_MUTED, 19)
		card_vbox.add_child(ch_btn)

	_animate_open()

# 3. Yeni Hayat / Özel Hayat Kurma Modalı
func show_new_life_modal(countries_db: Dictionary) -> void:
	_clear_card()

	var title_lbl: Label = Label.new()
	title_lbl.text = "✦ YENİ BİR YAŞAM SAYFASI AÇ ✦"
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.add_theme_font_size_override("font_size", 26)
	card_vbox.add_child(title_lbl)

	var desc_lbl: Label = Label.new()
	desc_lbl.text = "Gerçek dünya nüfus olasılıklarıyla (8 Milyarda 1 kader çarkı) rastgele doğabilir veya ülkeni ve cinsiyetini kendin seçebilirsin."
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_INK_SOFT)
	card_vbox.add_child(desc_lbl)

	var random_btn: Button = Button.new()
	random_btn.text = "🎲 8 Milyarda 1: Rastgele Kaderle Doğ"
	ThemeBuilder.apply_seal_age_button_theme(random_btn)
	random_btn.pressed.connect(func() -> void:
		close_modal()
		new_life_requested.emit("", "")
	)
	card_vbox.add_child(random_btn)

	var sep_lbl: Label = Label.new()
	sep_lbl.text = "─── VEYA ÖZEL HAYAT KUR ───"
	sep_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sep_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_INK_MUTED)
	card_vbox.add_child(sep_lbl)

	var country_opt: OptionButton = OptionButton.new()
	ThemeBuilder.apply_button_theme(country_opt, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 20)
	var codes: Array = countries_db.keys()
	for i in range(codes.size()):
		var c_code: String = str(codes[i])
		var c_info: Dictionary = countries_db.get(c_code, {})
		country_opt.add_item("%s %s (%s)" % [str(c_info.get("flag", "🌍")), str(c_info.get("name", c_code)), c_code], i)
		country_opt.set_item_metadata(i, c_code)
	card_vbox.add_child(country_opt)

	var gender_opt: OptionButton = OptionButton.new()
	ThemeBuilder.apply_button_theme(gender_opt, ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_INK_DARK, 20)
	gender_opt.add_item("Rastgele Cinsiyet", 0)
	gender_opt.set_item_metadata(0, "")
	gender_opt.add_item("Kadın (F)", 1)
	gender_opt.set_item_metadata(1, "F")
	gender_opt.add_item("Erkek (M)", 2)
	gender_opt.set_item_metadata(2, "M")
	card_vbox.add_child(gender_opt)

	var custom_btn: Button = Button.new()
	custom_btn.text = "✒️ Seçilen Ülkede Dünyaya Gel"
	ThemeBuilder.apply_button_theme(custom_btn, ThemeBuilder.COLOR_SAGE, ThemeBuilder.COLOR_PAPER_BG, 21)
	custom_btn.pressed.connect(func() -> void:
		var sel_c: String = str(country_opt.get_selected_metadata())
		var sel_g: String = str(gender_opt.get_selected_metadata())
		close_modal()
		new_life_requested.emit(sel_c, sel_g)
	)
	card_vbox.add_child(custom_btn)

	var cancel_btn: Button = Button.new()
	cancel_btn.text = "Vazgeç ve Mevcut Hayata Dön"
	ThemeBuilder.apply_button_theme(cancel_btn, ThemeBuilder.COLOR_PAPER_ACCENT, ThemeBuilder.COLOR_INK_DARK, 19)
	cancel_btn.pressed.connect(func() -> void:
		close_modal()
	)
	card_vbox.add_child(cancel_btn)

	_animate_open()

# 4. Ölüm, Hayat Sonu Arketipi ve 2. Kuşak Miras Devri Ekranı
func show_death_modal(gs: Object, ending_info: Dictionary, global_comparison: Dictionary) -> void:
	_clear_card()

	var top_lbl: Label = Label.new()
	top_lbl.text = "✦ BİR ÖMÜR TAMAMLANDI ✦"
	top_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	top_lbl.add_theme_color_override("font_color", ThemeBuilder.COLOR_PLUM)
	top_lbl.add_theme_font_size_override("font_size", 22)
	card_vbox.add_child(top_lbl)

	var vig_center: CenterContainer = CenterContainer.new()
	vig_center.add_child(_load_vignette_svg_or_procedural("death", false))
	card_vbox.add_child(vig_center)

	var name_lbl: Label = Label.new()
	name_lbl.text = "%s (%d - %d)" % [gs.full_name, gs.birth_year, gs.birth_year + gs.age]
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_font_size_override("font_size", 26)
	card_vbox.add_child(name_lbl)

	var arch_panel: PanelContainer = PanelContainer.new()
	arch_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_PLUM, 16))
	card_vbox.add_child(arch_panel)

	var arch_rtl: RichTextLabel = RichTextLabel.new()
	arch_rtl.bbcode_enabled = true
	arch_rtl.fit_content = true
	arch_rtl.scroll_active = false
	arch_rtl.text = "[b]Hayat Sonu Arketipi:[/b] [color=#6D435A][b]%s[/b][/color]\n" % str(ending_info.get("title", "Sessiz Yolcu")) + 		"[i]%s[/i]\n\n" % str(ending_info.get("epitaph", "")) + 		"[b]Vefat Nedeni:[/b] %s (%d yaşında)\n" % [gs.death_reason, gs.age] + 		"[b]Net Miras & Servet:[/b] %s %d\n" % [gs.currency_symbol, gs.money] + 		"[b]Kuşak:[/b] %d. Kuşak" % gs.generation
	arch_panel.add_child(arch_rtl)

	# 1in8b Küresel Karşılaştırma Grafiği
	var comp_panel: PanelContainer = PanelContainer.new()
	comp_panel.add_theme_stylebox_override("panel", ThemeBuilder.make_ribbon_card_style(ThemeBuilder.COLOR_PAPER_CARD, ThemeBuilder.COLOR_PRUSSIAN, 14))
	card_vbox.add_child(comp_panel)

	var comp_vbox: VBoxContainer = VBoxContainer.new()
	comp_vbox.add_theme_constant_override("separation", 8)
	comp_panel.add_child(comp_vbox)

	var comp_title: Label = Label.new()
	comp_title.text = "🌍 8 Milyar İnsan İçinde Küresel Yüzdeliğin"
	comp_title.add_theme_color_override("font_color", ThemeBuilder.COLOR_PRUSSIAN)
	comp_title.add_theme_font_size_override("font_size", 20)
	comp_vbox.add_child(comp_title)

	var metrics: Array = [
		["Yaşam Süresi Yüzdeliği", int(global_comparison.get("longevity_pct", 50)), ThemeBuilder.COLOR_SAGE],
		["Küresel Servet Yüzdeliği", int(global_comparison.get("wealth_pct", 50)), ThemeBuilder.COLOR_OCHRE],
		["Yaşam Mutluluğu Yüzdeliği", int(global_comparison.get("happiness_pct", 50)), ThemeBuilder.COLOR_TERRACOTTA],
		["Bilgelik & İtibar Yüzdeliği", int(global_comparison.get("wisdom_pct", 50)), ThemeBuilder.COLOR_PRUSSIAN]
	]
	for m in metrics:
		var m_lbl: Label = Label.new()
		m_lbl.text = "%s: Dünya nüfusunun %%%d'inden daha yüksek" % [str(m[0]), int(m[1])]
		m_lbl.add_theme_font_size_override("font_size", 17)
		comp_vbox.add_child(m_lbl)

		var pb: ProgressBar = ProgressBar.new()
		pb.min_value = 0.0
		pb.max_value = 100.0
		pb.value = float(m[1])
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0.0, 16.0)
		pb.add_theme_stylebox_override("background", ThemeBuilder.make_progress_bg())
		pb.add_theme_stylebox_override("fill", ThemeBuilder.make_progress_fill(m[2]))
		comp_vbox.add_child(pb)

	# Eğer yaşayan çocuğu varsa 2. Kuşak Miras Devri butonu aktif olur
	var living_children: Array = gs.get_living_children()
	if living_children.size() > 0:
		var heir: Dictionary = living_children[0]
		var heir_btn: Button = Button.new()
		heir_btn.text = "👑 Mirasını Çocuğuna Devret: %s (%d Yaş) İle Devam Et (%d. Kuşak)" % [
			str(heir.get("name", "Evlat")),
			int(heir.get("age", 18)),
			gs.generation + 1
		]
		heir_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ThemeBuilder.apply_button_theme(heir_btn, ThemeBuilder.COLOR_SAGE, ThemeBuilder.COLOR_PAPER_BG, 20)
		heir_btn.pressed.connect(func() -> void:
			close_modal()
			continue_as_child_requested.emit(heir)
		)
		card_vbox.add_child(heir_btn)

	var restart_btn: Button = Button.new()
	restart_btn.text = "🎲 Tamamen Yeni Bir Hayat Başlat"
	ThemeBuilder.apply_seal_age_button_theme(restart_btn)
	restart_btn.pressed.connect(func() -> void:
		close_modal()
		new_life_requested.emit("", "")
	)
	card_vbox.add_child(restart_btn)

	_animate_open()
