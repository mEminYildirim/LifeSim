extends Control

# Prosedürel El Çizimi Portre ve Vinyet Motoru (Artisanal Ink & Gouache)
const COLOR_PAPER_BG: Color = Color("#F4EFE6")
const COLOR_PAPER_CARD: Color = Color("#EBE3D5")
const COLOR_PAPER_ACCENT: Color = Color("#E0D5C1")
const COLOR_INK_DARK: Color = Color("#1C1917")
const COLOR_INK_SOFT: Color = Color("#3F3A34")
const COLOR_TERRACOTTA: Color = Color("#C84B31")
const COLOR_SAGE: Color = Color("#4A6B53")
const COLOR_OCHRE: Color = Color("#D49B35")
const COLOR_PRUSSIAN: Color = Color("#355070")
const COLOR_PLUM: Color = Color("#6D435A")

var mode: String = "portrait" # "portrait" veya "vignette"
var vignette_code: String = "exam"
var character_data: Dictionary = {
	"seed": 104729,
	"age": 18,
	"gender": "F",
	"country_code": "TR",
	"social_class": "middle",
	"health": 82,
	"happiness": 74,
	"smart": 68,
	"sanity": 78,
	"job_category": "student",
	"tags": []
}

func setup_portrait(data: Dictionary) -> void:
	mode = "portrait"
	character_data = data.duplicate(true)
	queue_redraw()

func setup_vignette(code: String, seed_val: int = 4242) -> void:
	mode = "vignette"
	vignette_code = code
	character_data["seed"] = seed_val
	queue_redraw()

# Deterministik organik sapma (hash)
func _hash_float(n: float) -> float:
	return fract(sin(n * 12.9898 + float(character_data.get("seed", 101)) * 0.13) * 43758.5453)

func fract(v: float) -> float:
	return v - floor(v)

# El Titremesi (Organic Ink Sketch Algorithm) - Çift geçişli mürekkep çizgisi
func draw_hand_line(from: Vector2, to: Vector2, col: Color = COLOR_INK_DARK, width: float = 2.2, jitter_amp: float = 1.35) -> void:
	var dist: float = from.distance_to(to)
	var steps: int = clampi(int(dist / 9.0), 3, 24)
	var pts1: PackedVector2Array = PackedVector2Array()
	var pts2: PackedVector2Array = PackedVector2Array()
	var dir: Vector2 = (to - from).normalized()
	var normal: Vector2 = Vector2(-dir.y, dir.x)

	for i in range(steps + 1):
		var t: float = float(i) / float(steps)
		var base_pt: Vector2 = from.lerp(to, t)
		var env: float = sin(t * PI)
		var j1: float = (_hash_float(base_pt.x * 0.37 + base_pt.y * 0.71 + float(i)) - 0.5) * 2.0 * jitter_amp * env
		var j2: float = (_hash_float(base_pt.y * 0.53 + base_pt.x * 0.29 + float(i + 19)) - 0.5) * 2.0 * jitter_amp * 0.85 * env
		pts1.append(base_pt + normal * j1)
		pts2.append(base_pt + normal * (j2 + 0.55))

	draw_polyline(pts1, col, width, true)
	var second_col: Color = Color(col.r, col.g, col.b, col.a * 0.42)
	draw_polyline(pts2, second_col, maxf(1.0, width * 0.58), true)

# El Çizimi Bezier Eğrisi (Double-Stroke Organic Ink Curve)
func draw_hand_bezier(p0: Vector2, p1: Vector2, p2: Vector2, col: Color = COLOR_INK_DARK, width: float = 2.2, jitter_amp: float = 1.1) -> void:
	var steps: int = 16
	var pts1: PackedVector2Array = PackedVector2Array()
	var pts2: PackedVector2Array = PackedVector2Array()
	for i in range(steps + 1):
		var t: float = float(i) / float(steps)
		var omt: float = 1.0 - t
		var pt: Vector2 = (omt * omt) * p0 + (2.0 * omt * t) * p1 + (t * t) * p2
		var env: float = sin(t * PI)
		var jx: float = (_hash_float(float(i) * 3.1 + p0.x) - 0.5) * jitter_amp * env
		var jy: float = (_hash_float(float(i) * 5.7 + p2.y) - 0.5) * jitter_amp * env
		pts1.append(pt + Vector2(jx, jy))
		pts2.append(pt + Vector2(-jy * 0.7 + 0.5, jx * 0.7 + 0.5))
	draw_polyline(pts1, col, width, true)
	draw_polyline(pts2, Color(col.r, col.g, col.b, col.a * 0.38), maxf(1.0, width * 0.55), true)

# El Çizimi Çerçeve ve Tarama (Ink Box + Cross-Hatching)
func draw_ink_box(rect: Rect2, fill_col: Color, ink_col: Color = COLOR_INK_DARK, border_w: float = 2.4) -> void:
	draw_rect(rect, fill_col, true)
	var tl: Vector2 = rect.position
	var tr: Vector2 = Vector2(rect.end.x, rect.position.y)
	var br: Vector2 = rect.end
	var bl: Vector2 = Vector2(rect.position.x, rect.end.y)
	draw_hand_line(tl, tr, ink_col, border_w, 1.1)
	draw_hand_line(tr, br, ink_col, border_w, 1.1)
	draw_hand_line(br, bl, ink_col, border_w, 1.1)
	draw_hand_line(bl, tl, ink_col, border_w, 1.1)

func draw_cross_hatching(center: Vector2, radius: float, col: Color, spacing: float = 8.0) -> void:
	var steps: int = int((radius * 1.6) / spacing)
	for i in range(-steps, steps + 1):
		var offset: float = float(i) * spacing
		var y_span: float = sqrt(maxf(0.0, radius * radius - offset * offset)) * 0.75
		if y_span > 4.0:
			var p1: Vector2 = center + Vector2(offset - y_span * 0.35, -y_span)
			var p2: Vector2 = center + Vector2(offset + y_span * 0.35, y_span)
			draw_line(p1, p2, Color(col.r, col.g, col.b, 0.16), 1.1, true)

func _draw() -> void:
	var rect: Rect2 = Rect2(Vector2.ZERO, size)
	if rect.size.x < 20.0 or rect.size.y < 20.0:
		return

	if mode == "vignette":
		_draw_vignette_canvas(rect)
	else:
		_draw_character_portrait(rect)

func _get_skin_tone(country: String, seed_val: int, health: int) -> Color:
	var base: Color = Color("#E8C8A9")
	match country:
		"NG":
			base = Color("#7A4B32") if (seed_val % 2 == 0) else Color("#633924")
		"IN", "EG":
			base = Color("#C69065") if (seed_val % 2 == 0) else Color("#B57C52")
		"BR", "CO", "AR":
			var idx: int = seed_val % 3
			if idx == 0:
				base = Color("#D8A67E")
			elif idx == 1:
				base = Color("#B88058")
			else:
				base = Color("#E5C19E")
		"JP", "KR", "CN":
			base = Color("#ECD1B4") if (seed_val % 2 == 0) else Color("#E2C2A0")
		"NO", "GB", "DE", "RU":
			base = Color("#F0D6C2") if (seed_val % 2 == 0) else Color("#E7C7AE")
		"TR", "US":
			base = Color("#E5C2A3") if (seed_val % 2 == 0) else Color("#D4A984")
	if health < 35:
		base = base.lerp(Color("#D6CFC2"), 0.32)
	return base

func _get_hair_color(country: String, seed_val: int, age: int) -> Color:
	var base: Color = Color("#26201C")
	if country in ["NO", "DE", "GB", "RU", "US"]:
		var m: int = seed_val % 4
		if m == 0:
			base = Color("#B88B4A") # Küllü sarı / kumral
		elif m == 1:
			base = Color("#8C4A32") # Kızıl kahve
		elif m == 2:
			base = Color("#4A3728") # Kestane
		else:
			base = Color("#26201C")
	elif country in ["TR", "BR", "CO", "AR"]:
		base = Color("#3A281E") if (seed_val % 2 == 0) else Color("#1E1916")
	else:
		base = Color("#1C1815")

	if age >= 52:
		var grey_t: float = clampf(float(age - 52) / 32.0, 0.15, 0.92)
		base = base.lerp(Color("#D8D2C7"), grey_t)
	return base

func _draw_character_portrait(rect: Rect2) -> void:
	var pad: float = 6.0
	var box: Rect2 = Rect2(Vector2(pad, pad), rect.size - Vector2(pad * 2.0, pad * 2.0))
	draw_ink_box(box, COLOR_PAPER_CARD, COLOR_INK_DARK, 2.6)

	var c: Vector2 = box.position + box.size * 0.5
	var s: float = minf(box.size.x, box.size.y) / 180.0

	var seed_val: int = int(character_data.get("seed", 104729))
	var age: int = int(character_data.get("age", 18))
	var gender: String = str(character_data.get("gender", "M"))
	var country: String = str(character_data.get("country_code", "TR"))
	var s_class: String = str(character_data.get("social_class", "middle"))
	var health: int = int(character_data.get("health", 80))
	var happiness: int = int(character_data.get("happiness", 75))
	var sanity: int = int(character_data.get("sanity", 75))
	var tags: Array = character_data.get("tags", [])

	# Arka plan guaj hale (Sosyal sınıf ve ruh haline göre)
	var aura_col: Color = COLOR_OCHRE
	if s_class in ["high", "elite"]:
		aura_col = COLOR_PLUM
	elif s_class in ["low", "extreme_poor"]:
		aura_col = COLOR_INK_SOFT
	elif happiness >= 70:
		aura_col = COLOR_SAGE
	elif health < 40 or sanity < 40:
		aura_col = COLOR_TERRACOTTA

	draw_circle(c + Vector2(-4.0 * s, -6.0 * s), 64.0 * s, Color(aura_col.r, aura_col.g, aura_col.b, 0.20))
	draw_cross_hatching(c, 66.0 * s, COLOR_INK_SOFT, 9.0 * s)

	var skin_col: Color = _get_skin_tone(country, seed_val, health)
	var hair_col: Color = _get_hair_color(country, seed_val, age)

	# Yaşa göre kafa ve omuz oranları
	var head_rx: float = 34.0 * s
	var head_ry: float = 40.0 * s
	var head_center: Vector2 = c + Vector2(0.0, -8.0 * s)
	var shoulder_w: float = 56.0 * s
	var shoulder_y: float = c.y + 42.0 * s

	if age <= 3:
		head_rx = 36.0 * s
		head_ry = 35.0 * s
		head_center = c + Vector2(0.0, 2.0 * s)
		shoulder_w = 38.0 * s
		shoulder_y = c.y + 46.0 * s
	elif age <= 12:
		head_rx = 33.0 * s
		head_ry = 36.0 * s
		head_center = c + Vector2(0.0, -4.0 * s)
		shoulder_w = 45.0 * s
		shoulder_y = c.y + 44.0 * s
	elif age >= 65:
		head_center = c + Vector2(0.0, -3.0 * s)
		shoulder_w = 50.0 * s
		shoulder_y = c.y + 46.0 * s

	# 1. Omuz ve Kıyafet Çizimi
	var coat_col: Color = COLOR_PRUSSIAN
	if age <= 3:
		coat_col = COLOR_OCHRE
	elif age <= 12:
		coat_col = COLOR_PRUSSIAN
	elif s_class in ["high", "elite"]:
		coat_col = COLOR_PLUM
	elif s_class in ["low", "extreme_poor"]:
		coat_col = COLOR_INK_SOFT
	else:
		coat_col = COLOR_SAGE if (seed_val % 2 == 0) else COLOR_PRUSSIAN

	var torso_pts: PackedVector2Array = PackedVector2Array([
		Vector2(c.x - shoulder_w, box.end.y - 4.0 * s),
		Vector2(c.x - shoulder_w * 0.88, shoulder_y),
		Vector2(c.x - 14.0 * s, head_center.y + head_ry * 0.85),
		Vector2(c.x + 14.0 * s, head_center.y + head_ry * 0.85),
		Vector2(c.x + shoulder_w * 0.88, shoulder_y),
		Vector2(c.x + shoulder_w, box.end.y - 4.0 * s)
	])
	draw_colored_polygon(torso_pts, coat_col)
	draw_hand_line(torso_pts[0], torso_pts[1], COLOR_INK_DARK, 2.5 * s)
	draw_hand_line(torso_pts[1], torso_pts[2], COLOR_INK_DARK, 2.5 * s)
	draw_hand_line(torso_pts[3], torso_pts[4], COLOR_INK_DARK, 2.5 * s)
	draw_hand_line(torso_pts[4], torso_pts[5], COLOR_INK_DARK, 2.5 * s)

	# Yaka / Kravat / Fular detayları
	var neck_base: Vector2 = Vector2(c.x, head_center.y + head_ry * 0.92)
	if age >= 13:
		draw_hand_line(neck_base + Vector2(-14.0 * s, -2.0 * s), neck_base + Vector2(0.0, 18.0 * s), COLOR_PAPER_BG, 3.0 * s, 0.6)
		draw_hand_line(neck_base + Vector2(14.0 * s, -2.0 * s), neck_base + Vector2(0.0, 18.0 * s), COLOR_PAPER_BG, 3.0 * s, 0.6)
		if s_class in ["high", "elite", "middle"] and age >= 22:
			draw_hand_line(neck_base + Vector2(0.0, 14.0 * s), neck_base + Vector2(0.0, 38.0 * s), COLOR_TERRACOTTA, 4.2 * s, 0.5)

	# Boyun
	var neck_rect: Rect2 = Rect2(Vector2(c.x - 11.0 * s, head_center.y + head_ry * 0.65), Vector2(22.0 * s, 20.0 * s))
	draw_rect(neck_rect, skin_col, true)
	draw_hand_line(neck_rect.position, neck_rect.position + Vector2(0.0, neck_rect.size.y), COLOR_INK_DARK, 2.0 * s, 0.6)
	draw_hand_line(Vector2(neck_rect.end.x, neck_rect.position.y), neck_rect.end, COLOR_INK_DARK, 2.0 * s, 0.6)

	# Kulaklar
	draw_circle(head_center + Vector2(-head_rx * 0.98, 2.0 * s), 7.5 * s, skin_col)
	draw_circle(head_center + Vector2(head_rx * 0.98, 2.0 * s), 7.5 * s, skin_col)
	draw_arc(head_center + Vector2(-head_rx * 0.98, 2.0 * s), 7.5 * s, PI * 0.5, PI * 1.5, 10, COLOR_INK_DARK, 2.2 * s)
	draw_arc(head_center + Vector2(head_rx * 0.98, 2.0 * s), 7.5 * s, -PI * 0.5, PI * 0.5, 10, COLOR_INK_DARK, 2.2 * s)

	# Uzun saç arka katmanı (Kadın veya uzun saçlı karakterler için)
	if gender == "F" and age >= 4:
		var back_hair: PackedVector2Array = PackedVector2Array([
			head_center + Vector2(-head_rx * 1.12, -10.0 * s),
			head_center + Vector2(-head_rx * 1.25, head_ry * 1.05),
			head_center + Vector2(head_rx * 1.25, head_ry * 1.05),
			head_center + Vector2(head_rx * 1.12, -10.0 * s)
		])
		draw_colored_polygon(back_hair, hair_col)
		draw_hand_line(back_hair[0], back_hair[1], COLOR_INK_DARK, 2.4 * s)
		draw_hand_line(back_hair[3], back_hair[2], COLOR_INK_DARK, 2.4 * s)

	# 2. Kafa / Yüz Poligonu
	var face_pts: PackedVector2Array = PackedVector2Array()
	var num_pts: int = 28
	for i in range(num_pts):
		var ang: float = (float(i) / float(num_pts)) * TAU
		var rx: float = head_rx
		var ry: float = head_ry
		# Çene ve yanak formu (Yaşa göre değişir)
		if sin(ang) > 0.25:
			if age <= 5:
				rx *= 1.08 # Tombul bebek yanakları
			elif age >= 18 and age <= 55:
				rx *= 0.92 # Belirgin yetişkin çene hattı
		face_pts.append(head_center + Vector2(cos(ang) * rx, sin(ang) * ry))

	draw_colored_polygon(face_pts, skin_col)
	for i in range(num_pts):
		var p_a: Vector2 = face_pts[i]
		var p_b: Vector2 = face_pts[(i + 1) % num_pts]
		draw_line(p_a, p_b, COLOR_INK_DARK, 2.4 * s, true)

	# Yanak алlığı / Guaj gölge
	var cheek_col: Color = Color(COLOR_TERRACOTTA.r, COLOR_TERRACOTTA.g, COLOR_TERRACOTTA.b, 0.18 if health >= 50 else 0.06)
	draw_circle(head_center + Vector2(-17.0 * s, 8.0 * s), 9.0 * s, cheek_col)
	draw_circle(head_center + Vector2(17.0 * s, 8.0 * s), 9.0 * s, cheek_col)

	# 3. Gözler, Gözbebekleri ve Kaşlar
	var eye_y: float = head_center.y - 4.0 * s
	var eye_dx: float = 13.5 * s
	var eye_r: float = (5.2 if age <= 5 else 4.2) * s

	for side in [-1.0, 1.0]:
		var ex: float = head_center.x + side * eye_dx
		var eye_pos: Vector2 = Vector2(ex, eye_y)
		draw_circle(eye_pos, eye_r * 1.35, COLOR_PAPER_BG)
		draw_arc(eye_pos, eye_r * 1.35, 0.0, TAU, 12, COLOR_INK_DARK, 1.8 * s)
		draw_circle(eye_pos, eye_r * 0.72, COLOR_INK_DARK)
		if happiness >= 65:
			draw_circle(eye_pos + Vector2(-1.2 * s, -1.2 * s), 1.3 * s, COLOR_PAPER_BG)

		# Stres / Düşük Akıl Sağlığı / Yaşlılık göz altı halkaları
		if sanity < 45 or health < 40 or age >= 52:
			draw_hand_bezier(
				eye_pos + Vector2(-6.5 * s, 5.5 * s),
				eye_pos + Vector2(0.0, 8.5 * s),
				eye_pos + Vector2(6.5 * s, 5.5 * s),
				COLOR_INK_SOFT, 1.4 * s, 0.5
			)

		# Kaşlar
		var brow_y: float = eye_y - 9.5 * s
		var brow_tilt: float = 0.0
		if happiness < 35 or sanity < 35:
			brow_tilt = 2.8 * s * side
		elif happiness > 75:
			brow_tilt = -1.8 * s * side
		draw_hand_bezier(
			Vector2(ex - 7.5 * s, brow_y + brow_tilt),
			Vector2(ex, brow_y - 3.0 * s),
			Vector2(ex + 7.5 * s, brow_y - brow_tilt),
			COLOR_INK_DARK, 2.4 * s, 0.6
		)

	# 4. Burun
	if age <= 4:
		draw_hand_bezier(
			head_center + Vector2(-2.5 * s, 4.0 * s),
			head_center + Vector2(0.0, 7.0 * s),
			head_center + Vector2(3.0 * s, 4.0 * s),
			COLOR_INK_DARK, 1.8 * s, 0.4
		)
	else:
		draw_hand_line(head_center + Vector2(0.0, -3.0 * s), head_center + Vector2(-2.5 * s, 9.5 * s), COLOR_INK_DARK, 2.0 * s, 0.6)
		draw_hand_line(head_center + Vector2(-2.5 * s, 9.5 * s), head_center + Vector2(3.5 * s, 10.5 * s), COLOR_INK_DARK, 2.0 * s, 0.5)

	# 5. Ağız İfadesi
	var mouth_y: float = head_center.y + 21.0 * s
	var smile_offset: float = clampf(float(happiness - 50) / 10.0, -5.5, 6.5) * s
	draw_hand_bezier(
		Vector2(head_center.x - 11.0 * s, mouth_y - smile_offset * 0.35),
		Vector2(head_center.x, mouth_y + smile_offset),
		Vector2(head_center.x + 11.0 * s, mouth_y - smile_offset * 0.35),
		COLOR_INK_DARK, 2.4 * s, 0.6
	)

	# 6. Yaşlılık Kırışıklıkları (56+ Yaş)
	if age >= 56:
		var wy: float = head_center.y - 21.0 * s
		draw_hand_line(Vector2(head_center.x - 14.0 * s, wy), Vector2(head_center.x + 14.0 * s, wy), COLOR_INK_SOFT, 1.3 * s, 0.7)
		if age >= 68:
			draw_hand_line(Vector2(head_center.x - 11.0 * s, wy - 4.5 * s), Vector2(head_center.x + 11.0 * s, wy - 4.5 * s), COLOR_INK_SOFT, 1.2 * s, 0.7)
			# Kaz ayakları (Crow's feet)
			draw_line(head_center + Vector2(-22.0 * s, eye_y - head_center.y), head_center + Vector2(-27.0 * s, eye_y - head_center.y - 3.0 * s), COLOR_INK_SOFT, 1.2 * s)
			draw_line(head_center + Vector2(22.0 * s, eye_y - head_center.y), head_center + Vector2(27.0 * s, eye_y - head_center.y - 3.0 * s), COLOR_INK_SOFT, 1.2 * s)

	# 7. Saç Stili (Yaş ve Cinsiyete Göre)
	if age <= 2:
		# Bebek kıvrık saç telleri
		draw_hand_bezier(
			head_center + Vector2(-4.0 * s, -head_ry),
			head_center + Vector2(2.0 * s, -head_ry - 11.0 * s),
			head_center + Vector2(9.0 * s, -head_ry - 3.0 * s),
			COLOR_INK_DARK, 2.4 * s, 0.6
		)
	else:
		var hair_top: PackedVector2Array = PackedVector2Array([
			head_center + Vector2(-head_rx * 1.02, -6.0 * s),
			head_center + Vector2(-head_rx * 0.88, -head_ry * 0.96),
			head_center + Vector2(0.0, -head_ry * 1.12),
			head_center + Vector2(head_rx * 0.88, -head_ry * 0.96),
			head_center + Vector2(head_rx * 1.02, -6.0 * s),
			head_center + Vector2(head_rx * 0.55, -head_ry * 0.62),
			head_center + Vector2(-head_rx * 0.45, -head_ry * 0.68)
		])
		draw_colored_polygon(hair_top, hair_col)
		draw_polyline(hair_top, COLOR_INK_DARK, 2.4 * s, true)

	# 8. Sakal / Bıyık (Yetişkin Erkeklerde Seed'e Göre)
	if gender == "M" and age >= 22 and (seed_val % 3 != 0):
		draw_hand_bezier(
			Vector2(head_center.x - 10.0 * s, mouth_y - 3.5 * s),
			Vector2(head_center.x, mouth_y - 6.5 * s),
			Vector2(head_center.x + 10.0 * s, mouth_y - 3.5 * s),
			hair_col, 3.2 * s, 0.5
		)

	# 9. Gözlük (Yüksek Zeka veya İleri Yaşta)
	var smart_val: int = int(character_data.get("smart", 50))
	if (smart_val >= 72 and age >= 10) or age >= 64:
		var g_left: Vector2 = Vector2(head_center.x - eye_dx, eye_y)
		var g_right: Vector2 = Vector2(head_center.x + eye_dx, eye_y)
		draw_arc(g_left, 9.0 * s, 0.0, TAU, 16, COLOR_INK_DARK, 2.0 * s)
		draw_arc(g_right, 9.0 * s, 0.0, TAU, 16, COLOR_INK_DARK, 2.0 * s)
		draw_line(g_left + Vector2(9.0 * s, 0.0), g_right - Vector2(9.0 * s, 0.0), COLOR_INK_DARK, 2.0 * s)

	# 10. Yara İzi (`tag_yarali` veya `suclu` geçmişi varsa)
	if "tag_yarali" in tags or "savas_gazisi" in tags:
		draw_hand_line(
			head_center + Vector2(10.0 * s, -14.0 * s),
			head_center + Vector2(18.0 * s, 10.0 * s),
			COLOR_TERRACOTTA, 2.2 * s, 0.4
		)

func _draw_vignette_canvas(rect: Rect2) -> void:
	var pad: float = 6.0
	var box: Rect2 = Rect2(Vector2(pad, pad), rect.size - Vector2(pad * 2.0, pad * 2.0))
	draw_ink_box(box, COLOR_PAPER_BG, COLOR_INK_DARK, 2.2)

	var c: Vector2 = box.position + box.size * 0.5
	var r: float = minf(box.size.x, box.size.y) * 0.34

	# Kategoriye göre guaj fırça lekesi
	var wash_col: Color = COLOR_OCHRE
	match vignette_code:
		"exam", "academy", "migration", "politics", "tech":
			wash_col = COLOR_PRUSSIAN
		"hospital", "heartbreak", "love", "crisis", "home", "protest":
			wash_col = COLOR_TERRACOTTA
		"finance", "military", "sports", "work", "science", "nature":
			wash_col = COLOR_SAGE
		"court", "crime", "philosophy", "death", "secret":
			wash_col = COLOR_PLUM
		_:
			wash_col = COLOR_OCHRE

	draw_circle(c + Vector2(-4.0, 3.0), r * 1.15, Color(wash_col.r, wash_col.g, wash_col.b, 0.22))
	draw_cross_hatching(c, r * 1.1, COLOR_INK_SOFT, 8.0)

	# El çizimi sembolik vinyet illüstrasyonu
	match vignette_code:
		"exam", "academy":
			var b_rect: Rect2 = Rect2(c - Vector2(r * 0.75, r * 0.85), Vector2(r * 1.5, r * 1.7))
			draw_ink_box(b_rect, COLOR_PAPER_CARD, COLOR_INK_DARK, 2.4)
			for i in range(4):
				var ly: float = b_rect.position.y + (0.25 + float(i) * 0.18) * b_rect.size.y
				draw_hand_line(Vector2(b_rect.position.x + 12.0, ly), Vector2(b_rect.end.x - 12.0, ly), COLOR_INK_SOFT, 2.0)
			draw_circle(b_rect.end - Vector2(18.0, 18.0), 10.0, COLOR_TERRACOTTA)
		"hospital":
			draw_circle(c, r * 0.85, COLOR_PAPER_CARD)
			draw_arc(c, r * 0.85, 0.0, TAU, 24, COLOR_INK_DARK, 2.6)
			draw_rect(Rect2(c - Vector2(r * 0.18, r * 0.52), Vector2(r * 0.36, r * 1.04)), COLOR_TERRACOTTA, true)
			draw_rect(Rect2(c - Vector2(r * 0.52, r * 0.18), Vector2(r * 1.04, r * 0.36)), COLOR_TERRACOTTA, true)
		"love", "heartbreak":
			draw_circle(c + Vector2(-r * 0.32, -r * 0.15), r * 0.42, COLOR_TERRACOTTA)
			draw_circle(c + Vector2(r * 0.32, -r * 0.15), r * 0.42, COLOR_TERRACOTTA)
			var tri: PackedVector2Array = PackedVector2Array([
				c + Vector2(-r * 0.70, -r * 0.02),
				c + Vector2(r * 0.70, -r * 0.02),
				c + Vector2(0.0, r * 0.78)
			])
			draw_colored_polygon(tri, COLOR_TERRACOTTA)
			if vignette_code == "heartbreak":
				draw_hand_line(c + Vector2(0.0, -r * 0.45), c + Vector2(-8.0, r * 0.1), COLOR_INK_DARK, 3.5)
				draw_hand_line(c + Vector2(-8.0, r * 0.1), c + Vector2(6.0, r * 0.65), COLOR_INK_DARK, 3.5)
		"finance":
			var p0: Vector2 = c + Vector2(-r * 0.8, r * 0.55)
			var p1: Vector2 = c + Vector2(-r * 0.25, r * 0.05)
			var p2: Vector2 = c + Vector2(r * 0.15, r * 0.30)
			var p3: Vector2 = c + Vector2(r * 0.8, -r * 0.65)
			draw_hand_line(p0, p1, COLOR_SAGE, 4.0)
			draw_hand_line(p1, p2, COLOR_TERRACOTTA, 4.0)
			draw_hand_line(p2, p3, COLOR_SAGE, 4.5)
			draw_circle(p3, 6.0, COLOR_OCHRE)
		"migration":
			draw_circle(c, r * 0.82, COLOR_PRUSSIAN)
			draw_arc(c, r * 0.82, 0.0, TAU, 24, COLOR_INK_DARK, 2.8)
			draw_hand_line(c - Vector2(r * 0.8, 0.0), c + Vector2(r * 0.8, 0.0), COLOR_OCHRE, 2.0)
			draw_hand_line(c - Vector2(0.0, r * 0.8), c + Vector2(0.0, r * 0.8), COLOR_OCHRE, 2.0)
		"court", "crime":
			draw_hand_line(c + Vector2(-r * 0.6, r * 0.6), c + Vector2(r * 0.4, -r * 0.4), COLOR_INK_DARK, 5.0)
			var head_box: Rect2 = Rect2(c + Vector2(r * 0.1, -r * 0.7), Vector2(r * 0.55, r * 0.35))
			draw_ink_box(head_box, COLOR_PLUM, COLOR_INK_DARK, 2.5)
		_:
			draw_circle(c, r * 0.78, COLOR_PAPER_CARD)
			draw_arc(c, r * 0.78, 0.0, TAU, 24, COLOR_INK_DARK, 2.8)
			draw_hand_line(c + Vector2(-r * 0.45, 0.0), c + Vector2(r * 0.45, 0.0), wash_col, 3.5)
			draw_hand_line(c + Vector2(0.0, -r * 0.45), c + Vector2(0.0, r * 0.45), wash_col, 3.5)
