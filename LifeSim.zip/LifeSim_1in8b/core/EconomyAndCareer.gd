extends RefCounted

# Ülke Ekonomisi, Enflasyon, Vergi, 60+ Meslek, Yatırım, Emlak ve Göç Motoru
var countries_db: Dictionary = {}
var careers_list: Array = []
var assets_catalog: Array = []
var endings_catalog: Array = []

func setup(c_db: Dictionary, careers_data: Dictionary) -> void:
	countries_db = c_db
	careers_list = careers_data.get("careers", [])
	assets_catalog = careers_data.get("assets", [])
	endings_catalog = careers_data.get("endings", [])

# Her yaş ilerlediğinde eğitim aşamalarını, maaşı, vergiyi, enflasyonu ve yatırımları işletir
func process_yearly_economy_and_school(gs: Object) -> Array:
	var logs: Array = []
	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	var inflation_rate: float = float(c_info.get("inflation_rate", 0.04))
	var tax_rate: float = float(c_info.get("tax_rate", 0.22))

	# 1. Otomatik Zorunlu Eğitim Geçişleri (0-18 Yaş)
	if gs.age == 6:
		gs.education_level = "ilkokul"
		gs.current_job_title = "İlkokul Öğrencisi"
		gs.current_job_category = "student"
		gs.add_tag("ilkokul_ogrencisi")
		logs.append("🎒 İlkokul sıralarına adım attın. Okuma yazma ve sayılarla tanışıyorsun.")
	elif gs.age == 11:
		gs.education_level = "ortaokul"
		gs.current_job_title = "Ortaokul Öğrencisi"
		gs.remove_tag("ilkokul_ogrencisi")
		gs.add_tag("ortaokul_ogrencisi")
		logs.append("📚 Ortaokula başladın; dersler ve arkadaşlıklar karmaşıklaşıyor.")
	elif gs.age == 15:
		gs.education_level = "lise"
		gs.current_job_title = "Lise Öğrencisi"
		gs.remove_tag("ortaokul_ogrencisi")
		gs.add_tag("lise_ogrencisi")
		logs.append("🏫 Lise yılların başladı. Gelecek kaygısı ve gençlik enerjisi bir arada.")
	elif gs.age == 18 and gs.education_level == "lise":
		gs.education_level = "lise_mezunu"
		gs.remove_tag("lise_ogrencisi")
		gs.add_tag("lise_mezunu")
		if gs.current_job_id == "unemployed":
			gs.current_job_title = "Lise Mezunu (İşsiz)"
			gs.current_job_category = "none"
		logs.append("🎓 Liseden mezun oldun. Önünde üniversite, meslek veya iş hayatı yolları var.")
	elif gs.age == 22 and gs.education_level == "universite_ogrencisi":
		gs.education_level = "universite_mezunu"
		gs.remove_tag("universite_ogrencisi")
		gs.add_tag("universite_mezunu")
		gs.smart = clampi(gs.smart + 6, 0, 100)
		gs.reputation = clampi(gs.reputation + 5, 0, 100)
		if gs.current_job_id == "unemployed":
			gs.current_job_title = "Üniversite Mezunu (%s)" % (gs.university_major if gs.university_major != "" else "Lisans")
		logs.append("🎓 Üniversiteden (%s) başarıyla mezun oldun! Artık diplomalı bir uzmansın." % (gs.university_major if gs.university_major != "" else "Lisans"))

	# 18 yaşındayken ailesinden ilk cep harçlığı destek paketi
	if gs.age == 18:
		var starter_multiplier: float = 1.0
		match gs.social_class:
			"extreme_poor": starter_multiplier = 0.15
			"low": starter_multiplier = 0.5
			"middle": starter_multiplier = 1.6
			"high": starter_multiplier = 5.5
			"elite": starter_multiplier = 18.0
		var gift: int = int(round(1200.0 * gs.usd_exchange_rate * starter_multiplier))
		gs.money += gift
		logs.append("🧧 18 yaşına bastığında ailenin sana sağlayabildiği başlangıç desteği: %s %d." % [gs.currency_symbol, gift])

	# 2. Yetişkin Gelir, Enflasyon, Vergi ve Yaşam Maliyeti Hesabı (18+ Yaş)
	if gs.age >= 18:
		var gross_income: int = gs.annual_income + gs.part_time_income
		for asset in gs.owned_assets:
			gross_income += int(asset.get("annual_yield", 0))

		var net_income: int = int(round(float(gross_income) * (1.0 - tax_rate)))

		# Yaşam tarzı gideri
		var base_living_cost_usd: float = float(c_info.get("annual_living_cost_usd", 6000.0))
		var style_mult: float = 1.0
		if gs.lifestyle_level == "mutevazi":
			style_mult = 0.65
			gs.happiness = clampi(gs.happiness - 1, 0, 100)
		elif gs.lifestyle_level == "luks":
			style_mult = 2.25
			gs.happiness = clampi(gs.happiness + 3, 0, 100)
			gs.reputation = clampi(gs.reputation + 2, 0, 100)

		# Çocuk sayısı gideri artırır
		var child_count: int = gs.get_living_children().size()
		var family_mult: float = 1.0 + float(child_count) * 0.24

		var living_expense: int = int(round(base_living_cost_usd * gs.usd_exchange_rate * style_mult * family_mult))
		for asset in gs.owned_assets:
			living_expense += int(asset.get("upkeep", 0))

		# Öğrenci kredisi / Banka borcu ödemesi
		if gs.student_loan > 0:
			var payment: int = mini(gs.student_loan, int(round(1200.0 * gs.usd_exchange_rate)))
			living_expense += payment
			gs.student_loan -= payment

		gs.annual_expenses = living_expense
		var net_cashflow: int = net_income - living_expense
		gs.money += net_cashflow

		# Kronik enflasyon etkisi (Özellikle TR, AR, NG, EG gibi ülkelerde nakit erimesi)
		if inflation_rate >= 0.12 and gs.money > 0:
			var erosion: int = int(round(float(gs.money) * (inflation_rate * 0.45)))
			gs.money -= erosion
			logs.append("📉 Yüksek enflasyon (%%%d) nedeniyle nakit birikiminin alım gücü %s %d eridi." % [
				int(round(inflation_rate * 100.0)), gs.currency_symbol, erosion
			])

		# Döviz / Fon / Kripto portföy getirileri
		var fx_bal: int = int(gs.financial_portfolio.get("fx_usd", 0))
		if fx_bal > 0:
			var fx_gain: int = int(round(float(fx_bal) * (inflation_rate + 0.03)))
			gs.financial_portfolio["fx_usd"] = fx_bal + fx_gain

		var idx_bal: int = int(gs.financial_portfolio.get("index_fund", 0))
		if idx_bal > 0:
			var market_ret: float = randf_range(-0.08, 0.19)
			var idx_gain: int = int(round(float(idx_bal) * (market_ret + inflation_rate * 0.6)))
			gs.financial_portfolio["index_fund"] = max(0, idx_bal + idx_gain)

		var cry_bal: int = int(gs.financial_portfolio.get("crypto_spec", 0))
		if cry_bal > 0:
			var cry_ret: float = randf_range(-0.45, 0.75)
			var cry_gain: int = int(round(float(cry_bal) * cry_ret))
			gs.financial_portfolio["crypto_spec"] = max(0, cry_bal + cry_gain)

		# İş tecrübesi ve düzenli maaş artışı
		if gs.current_job_id != "unemployed" and gs.current_job_id != "retired":
			gs.job_experience_years += 1
			var raise_pct: float = inflation_rate * 0.85 + 0.04
			gs.annual_income = int(round(float(gs.annual_income) * (1.0 + raise_pct)))

		# Borç ve İflas kontrolü
		if gs.money < -int(15000.0 * gs.usd_exchange_rate):
			gs.happiness = clampi(gs.happiness - 6, 0, 100)
			gs.sanity = clampi(gs.sanity - 5, 0, 100)
			gs.add_tag("agir_borclu")
			logs.append("⚠️ Ağır borç batağındasın! Alacaklılar kapını aşındırıyor, ruh sağlığın yıpranıyor.")

		# Sosyal sınıf güncellemesi
		var total_wealth: int = get_total_net_worth(gs)
		var wealth_in_usd: float = float(total_wealth) / maxf(0.01, gs.usd_exchange_rate)
		if wealth_in_usd < 1500.0:
			gs.social_class = "extreme_poor"
		elif wealth_in_usd < 15000.0:
			gs.social_class = "low"
		elif wealth_in_usd < 120000.0:
			gs.social_class = "middle"
		elif wealth_in_usd < 850000.0:
			gs.social_class = "high"
		else:
			gs.social_class = "elite"

	return logs

func get_total_net_worth(gs: Object) -> int:
	var total: int = gs.money
	total += int(gs.financial_portfolio.get("fx_usd", 0))
	total += int(gs.financial_portfolio.get("index_fund", 0))
	total += int(gs.financial_portfolio.get("crypto_spec", 0))
	for a in gs.owned_assets:
		total += int(a.get("value", 0))
	total -= gs.student_loan
	return total

# Üniversiteye Başvuru
func enroll_university(gs: Object, major_name: String, major_tag: String, use_loan: bool) -> String:
	if gs.age < 17:
		return "Üniversite için henüz yaşın küçük."
	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	var tuition_usd: float = float(c_info.get("uni_tuition_usd", 1500.0))
	var total_tuition: int = int(round(tuition_usd * 4.0 * gs.usd_exchange_rate))

	if not use_loan and gs.money < total_tuition:
		return "Peşin eğitim ücreti (%s %d) için yeterli birikimin yok. Öğrenci kredisi/burs seçeneğini dene." % [gs.currency_symbol, total_tuition]

	if use_loan:
		gs.student_loan += total_tuition
		gs.add_tag("ogrenci_kredisi_borcu")
	else:
		gs.money -= total_tuition

	gs.education_level = "universite_ogrencisi"
	gs.university_major = major_name
	gs.current_job_title = "Üniversite Öğrencisi (%s)" % major_name
	gs.current_job_category = "student"
	gs.add_tag("universite_ogrencisi")
	if major_tag != "":
		gs.add_tag(major_tag)
	return "🎓 %s bölümüne kaydoldun! 4 yıllık akademik yolculuğun başladı." % major_name

# Meslek Başvurusu (60+ Meslek Ağacı)
func apply_for_career(gs: Object, career: Dictionary) -> Dictionary:
	if gs.age < int(career.get("min_age", 18)):
		return {"ok": false, "msg": "Bu meslek için en az %d yaşında olmalısın." % int(career.get("min_age", 18))}

	var min_smart: int = int(career.get("min_smart", 0))
	if gs.smart < min_smart:
		return {"ok": false, "msg": "Mülakatta elendin: Zeka/Beceri puanın en az %d olmalı." % min_smart}

	var req_edu: String = str(career.get("req_education", "none"))
	if req_edu == "universite" and not (gs.education_level in ["universite_mezunu", "yuksek_lisans", "doktora"]):
		return {"ok": false, "msg": "Bu pozisyon için Üniversite Diploması şart koşuluyor."}

	var req_tag: String = str(career.get("req_tag", ""))
	if req_tag != "" and not gs.has_tag(req_tag):
		return {"ok": false, "msg": "Özel uzmanlık şartı sağlanmıyor: %s." % req_tag.replace("tag_", "").to_upper()}

	if gs.has_tag("sabikali") and bool(career.get("clean_record", true)):
		return {"ok": false, "msg": "Adli sicil kaydın (sabıkan) nedeniyle başvurunun reddine karar verildi."}

	var c_info: Dictionary = countries_db.get(gs.country_code, {})
	var gdp_mult: float = clampf(float(c_info.get("gdp_per_capita_usd", 12000)) / 18000.0, 0.35, 3.8)
	var base_usd: float = float(career.get("base_salary_usd", 12000.0))
	var local_salary: int = int(round(base_usd * gdp_mult * gs.usd_exchange_rate))

	gs.current_job_id = str(career.get("id", "worker"))
	gs.current_job_title = str(career.get("title", "Çalışan"))
	gs.current_job_category = str(career.get("category", "general"))
	gs.annual_income = local_salary
	gs.job_experience_years = 0
	gs.add_tag("calisan")
	var grant_tag: String = str(career.get("grant_tag", ""))
	if grant_tag != "":
		gs.add_tag(grant_tag)

	return {
		"ok": true,
		"msg": "💼 Tebrikler! %s olarak işe başladın. Yıllık brüt maaşın: %s %d." % [gs.current_job_title, gs.currency_symbol, local_salary]
	}

# Terfi / Zam İste
func request_promotion(gs: Object) -> String:
	if gs.current_job_id in ["unemployed", "retired", "student"]:
		return "Şu anda tam zamanlı bir işte çalışmıyorsun."
	if gs.job_experience_years < 2:
		return "Terfi istemek için mevcut işinde en az 2 yıl deneyim kazanmalısın."

	var chance: float = float(gs.smart + gs.reputation) / 180.0
	if randf() < chance:
		var boost: int = int(round(float(gs.annual_income) * 0.24))
		gs.annual_income += boost
		gs.reputation = clampi(gs.reputation + 5, 0, 100)
		gs.happiness = clampi(gs.happiness + 6, 0, 100)
		if not gs.current_job_title.begins_with("Kıdemli "):
			gs.current_job_title = "Kıdemli " + gs.current_job_title
		return "📈 Üstün performansın onaylandı! Terfi aldın ve maaşın yıllık %s %d arttı." % [gs.currency_symbol, boost]
	else:
		gs.happiness = clampi(gs.happiness - 4, 0, 100)
		return "📋 Yönetim bütçe kısıtlamalarını gerekçe göstererek zam talebini bu yıl reddetti."

# Başka Ülkeye Göç Et (Yasal Vize veya Kaçak Rota)
func attempt_migration(gs: Object, target_country_code: String, legal_route: bool) -> Dictionary:
	if target_country_code == gs.country_code:
		return {"ok": false, "msg": "Zaten bu ülkede yaşıyorsun."}

	var target_info: Dictionary = countries_db.get(target_country_code, {})
	var target_name: String = str(target_info.get("name", target_country_code))

	if legal_route:
		var visa_fee: int = int(round(2500.0 * gs.usd_exchange_rate))
		if gs.money < visa_fee:
			return {"ok": false, "msg": "Vize harcı, uçak bileti ve ilk yerleşim fonu için en az %s %d gerekli." % [gs.currency_symbol, visa_fee]}
		var points: int = gs.smart + (25 if gs.education_level in ["universite_mezunu", "yuksek_lisans", "doktora"] else 0) + (15 if gs.reputation >= 60 else 0)
		if gs.has_tag("sabikali"):
			points -= 50
		if points >= 72 or randf() < 0.45:
			gs.money -= visa_fee
			_convert_currency_and_move(gs, target_country_code, target_info)
			gs.add_tag("gocmen")
			gs.add_tag("yasal_gocmen")
			return {"ok": true, "msg": "✈️ %s Konsolosluğu çalışma ve oturum vizeni onayladı! Yeni hayatın %s şehrinde başlıyor." % [target_name, gs.city]}
		else:
			gs.money -= int(visa_fee * 0.25)
			gs.happiness = clampi(gs.happiness - 6, 0, 100)
			return {"ok": false, "msg": "🛂 %s Konsolosluğu vize başvurunu 'ülkeye geri dönüş bağlarının zayıflığı ve puan yetersizliği' gerekçesiyle reddetti." % target_name}
	else:
		var smuggler_fee: int = int(round(1400.0 * gs.usd_exchange_rate))
		if gs.money < smuggler_fee:
			return {"ok": false, "msg": "İnsan kaçakçıları geçiş için peşin %s %d istiyor." % [gs.currency_symbol, smuggler_fee]}
		gs.money -= smuggler_fee
		var roll: float = randf()
		if roll < 0.48:
			_convert_currency_and_move(gs, target_country_code, target_info)
			gs.health = clampi(gs.health - 12, 0, 100)
			gs.sanity = clampi(gs.sanity - 10, 0, 100)
			gs.add_tag("gocmen")
			gs.add_tag("kayitsiz_gocmen")
			return {"ok": true, "msg": "🌊 Ölüm tehlikesiyle dolu karanlık bir yolculuktan sonra %s topraklarına ulaştın. Kayıtsız bir göçmen olarak sıfırdan tutunmaya çalışacaksın." % target_name}
		elif roll < 0.82:
			gs.health = clampi(gs.health - 18, 0, 100)
			gs.happiness = clampi(gs.happiness - 15, 0, 100)
			return {"ok": false, "msg": "🚨 Sınır muhafızları tarafından yakalandın! Paran yandı, gözaltında hırpalandın ve sınır dışı edildin."}
		else:
			gs.health = clampi(gs.health - 30, 0, 100)
			gs.add_tag("tag_yarali")
			return {"ok": false, "msg": "💥 Kaçakçıların kamyoneti sınırda kaza yaptı! Ağır yaralı kurtuldun ve ülkene geri gönderildin."}

func _convert_currency_and_move(gs: Object, new_code: String, new_info: Dictionary) -> void:
	var old_rate: float = maxf(0.001, gs.usd_exchange_rate)
	var new_rate: float = float(new_info.get("exchange_rate_to_usd", 1.0))
	var ratio: float = new_rate / old_rate

	gs.money = int(round(float(gs.money) * ratio))
	gs.student_loan = int(round(float(gs.student_loan) * ratio))
	gs.financial_portfolio["fx_usd"] = int(round(float(gs.financial_portfolio.get("fx_usd", 0)) * ratio))
	gs.financial_portfolio["index_fund"] = int(round(float(gs.financial_portfolio.get("index_fund", 0)) * ratio))
	gs.financial_portfolio["crypto_spec"] = int(round(float(gs.financial_portfolio.get("crypto_spec", 0)) * ratio))

	gs.country_code = new_code
	gs.currency_symbol = str(new_info.get("currency_symbol", "$"))
	gs.usd_exchange_rate = new_rate
	var cities: Array = new_info.get("cities", ["Merkez"])
	gs.city = str(cities[randi() % max(1, cities.size())])
	gs.current_job_id = "unemployed"
	gs.current_job_title = "Yeni Göçmen (İşsiz)"
	gs.annual_income = 0

# Ölümde Hayat Sonu Arketipi ve 1in8b Küresel Karşılaştırma Hesabı
func evaluate_ending_archetype(gs: Object) -> Dictionary:
	var best_match: Dictionary = {
		"id": "default_traveler",
		"title": "Zamanın Sessiz Tanığı",
		"epitaph": "Fırtınalı bir dünyada kendi payına düşen nefesleri topladı, sevdiklerinin kalbinde sade bir iz bırakarak göçtü."
	}
	var best_score: int = -1

	for end_item in endings_catalog:
		var score: int = 0
		var req_tags: Array = end_item.get("req_tags", [])
		var all_matched: bool = true
		for rt in req_tags:
			if gs.has_tag(str(rt)):
				score += 25
			else:
				all_matched = false
				break
		if not all_matched:
			continue

		var min_age: int = int(end_item.get("min_age", 0))
		if gs.age < min_age:
			continue

		var req_class: String = str(end_item.get("social_class", ""))
		if req_class != "" and gs.social_class != req_class:
			continue
		if req_class != "":
			score += 15

		var min_karma: int = int(end_item.get("min_karma", -1))
		if min_karma >= 0 and gs.karma < min_karma:
			continue
		var max_karma: int = int(end_item.get("max_karma", 101))
		if max_karma <= 100 and gs.karma > max_karma:
			continue

		score += int(end_item.get("priority", 10))
		if score > best_score:
			best_score = score
			best_match = end_item

	return best_match

func compute_1in8b_global_comparison(gs: Object) -> Dictionary:
	var longevity_pct: int = clampi(int(round((float(gs.age) / 88.0) * 95.0)), 3, 99)
	var net_usd: float = float(get_total_net_worth(gs)) / maxf(0.01, gs.usd_exchange_rate)
	var wealth_pct: int = 15
	if net_usd <= 0.0:
		wealth_pct = 8
	elif net_usd < 2500.0:
		wealth_pct = 28
	elif net_usd < 15000.0:
		wealth_pct = 54
	elif net_usd < 85000.0:
		wealth_pct = 78
	elif net_usd < 500000.0:
		wealth_pct = 93
	else:
		wealth_pct = 99

	var happiness_pct: int = clampi(gs.happiness, 5, 99)
	var wisdom_pct: int = clampi(int((gs.smart + gs.reputation + gs.karma) / 3.0), 8, 99)
	return {
		"longevity_pct": longevity_pct,
		"wealth_pct": wealth_pct,
		"happiness_pct": happiness_pct,
		"wisdom_pct": wisdom_pct
	}
