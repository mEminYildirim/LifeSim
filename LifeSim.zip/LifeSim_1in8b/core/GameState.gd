extends RefCounted

# Karakterin tüm istatistikleri, geçmişi, etiketleri, envanteri ve kuşak hafızası
var seed_val: int = 104729
var generation: int = 1
var birth_year: int = 2026
var age: int = 0
var is_alive: bool = true
var death_reason: String = ""

var first_name: String = "Deniz"
var last_name: String = "Yılmaz"
var full_name: String = "Deniz Yılmaz"
var gender: String = "F" # "F" veya "M"

var country_code: String = "TR"
var origin_country_code: String = "TR"
var city: String = "İstanbul"
var currency_symbol: String = "₺"
var usd_exchange_rate: float = 34.0
var social_class: String = "middle" # extreme_poor, low, middle, high, elite

# 6 Temel İstatistik (0 - 100)
var health: int = 85
var happiness: int = 80
var smart: int = 60
var reputation: int = 50
var sanity: int = 82
var karma: int = 60

# Finans ve Kariyer
var money: int = 0
var annual_income: int = 0
var annual_expenses: int = 0
var bank_debt: int = 0
var student_loan: int = 0
var lifestyle_level: String = "standart" # mutevazi, standart, luks

var education_level: String = "bebek" # bebek, ilkokul, ortaokul, lise, universite, yuksek_lisans, doktora
var university_major: String = ""
var current_job_id: String = "unemployed"
var current_job_title: String = "Bebek"
var current_job_category: String = "none"
var job_experience_years: int = 0
var part_time_job_id: String = ""
var part_time_income: int = 0

# Varlıklar ve Yatırımlar
var owned_assets: Array = [] # [{id, name, category, value, annual_yield, upkeep}]
var financial_portfolio: Dictionary = {
	"fx_usd": 0,       # Döviz / Altın koruma birikimi (yerel para karşılığı)
	"index_fund": 0,   # Küresel Hisse / Fon
	"crypto_spec": 0   # Yüksek riskli spekülatif portföy
}

# Etiketler, Kişilik Özellikleri ve Kelebek Etkisi Kuyruğu
var life_tags: Array = []         # ["lise_ogrencisi", "akademik_basari", ...]
var traits: Array = []            # ["Azimli", "Merhametli", ...]
var seen_events: Array = []       # Tekrarlanamaz olayların ID listesi
var scheduled_events: Array = []  # [{trigger_age, event_id, origin_note}]
var active_story_arcs: Dictionary = {} # {arc_id: current_stage_index}

# İlişkiler (NPCEngine tarafından yönetilir)
var npcs: Array = [] # [{id, name, role, gender, age, alive, relation, smart, wealth_tier, job_title, married_to_player}]
var timeline_history: Array = [] # [{age, year, entries: []}]

func reset_for_new_life(c_code: String, c_info: Dictionary, custom_gender: String = "", inherited_money: int = 0, gen_num: int = 1, inherited_last_name: String = "") -> void:
	randomize()
	seed_val = randi_range(100000, 999999)
	generation = gen_num
	birth_year = randi_range(2004, 2026)
	age = 0
	is_alive = true
	death_reason = ""

	country_code = c_code
	origin_country_code = c_code
	currency_symbol = str(c_info.get("currency_symbol", "₺"))
	usd_exchange_rate = float(c_info.get("exchange_rate_to_usd", 1.0))

	var cities: Array = c_info.get("cities", ["Merkez"])
	city = str(cities[randi() % max(1, cities.size())])

	if custom_gender in ["F", "M"]:
		gender = custom_gender
	else:
		gender = "F" if (randf() < 0.5) else "M"

	var f_names: Array = c_info.get("female_names", ["Ayşe"]) if gender == "F" else c_info.get("male_names", ["Mehmet"])
	var l_names: Array = c_info.get("surnames", ["Yılmaz"])
	first_name = str(f_names[randi() % max(1, f_names.size())])
	last_name = inherited_last_name if inherited_last_name != "" else str(l_names[randi() % max(1, l_names.size())])
	full_name = first_name + " " + last_name

	# Sosyal sınıf dağılımı (Ülkenin gelir dağılımı ağırlıklarına göre)
	var class_weights: Dictionary = c_info.get("class_distribution", {
		"extreme_poor": 10, "low": 30, "middle": 42, "high": 14, "elite": 4
	})
	social_class = _roll_weighted_key(class_weights, "middle")
	if inherited_money > 0:
		if inherited_money >= int(250000.0 * usd_exchange_rate):
			social_class = "elite"
		elif inherited_money >= int(60000.0 * usd_exchange_rate):
			social_class = "high"
		else:
			social_class = "middle"

	var base_health: int = int(c_info.get("base_health_index", 78))
	health = clampi(base_health + randi_range(-10, 12), 45, 100)
	happiness = clampi(72 + randi_range(-12, 18), 40, 100)
	smart = clampi(52 + randi_range(-18, 32), 25, 98)
	reputation = clampi(45 + randi_range(-10, 15), 20, 90)
	sanity = clampi(80 + randi_range(-10, 15), 45, 100)
	karma = 60

	money = inherited_money
	annual_income = 0
	annual_expenses = 0
	bank_debt = 0
	student_loan = 0
	lifestyle_level = "standart"

	education_level = "bebek"
	university_major = ""
	current_job_id = "unemployed"
	current_job_title = "Bebek"
	current_job_category = "none"
	job_experience_years = 0
	part_time_job_id = ""
	part_time_income = 0

	owned_assets = []
	financial_portfolio = {"fx_usd": 0, "index_fund": 0, "crypto_spec": 0}
	life_tags = ["bebek"]
	if social_class in ["extreme_poor", "low"]:
		life_tags.append("dar_gelirli_cocukluk")
	elif social_class in ["high", "elite"]:
		life_tags.append("varlikli_cocukluk")

	traits = []
	seen_events = []
	scheduled_events = []
	active_story_arcs = {}
	npcs = []
	timeline_history = []

func _roll_weighted_key(weights: Dictionary, fallback: String) -> String:
	var total: int = 0
	for k in weights.keys():
		total += int(weights.get(k, 0))
	if total <= 0:
		return fallback
	var roll: int = randi() % total
	var acc: int = 0
	for k in weights.keys():
		acc += int(weights.get(k, 0))
		if roll < acc:
			return str(k)
	return fallback

func has_tag(t: String) -> bool:
	return t in life_tags

func add_tag(t: String) -> void:
	if t != "" and not (t in life_tags):
		life_tags.append(t)

func remove_tag(t: String) -> void:
	life_tags.erase(t)

func add_trait(tr_name: String) -> void:
	if tr_name != "" and not (tr_name in traits):
		traits.append(tr_name)

func clamp_all_stats() -> void:
	health = clampi(health, 0, 100)
	happiness = clampi(happiness, 0, 100)
	smart = clampi(smart, 0, 100)
	reputation = clampi(reputation, 0, 100)
	sanity = clampi(sanity, 0, 100)
	karma = clampi(karma, 0, 100)

func get_stat_value(stat_name: String) -> int:
	match stat_name:
		"health": return health
		"happiness": return happiness
		"smart": return smart
		"reputation": return reputation
		"sanity": return sanity
		"karma": return karma
		_: return 0

func apply_effects(effects: Dictionary) -> Array:
	var summary_badges: Array = []
	var stat_map: Dictionary = {
		"health": ["Sağlık", "❤️"],
		"happiness": ["Mutluluk", "☀️"],
		"smart": ["Zeka", "🧠"],
		"reputation": ["İtibar", "👑"],
		"sanity": ["Akıl Sağlığı", "🌀"],
		"karma": ["Vicdan", "⚖️"]
	}
	for k in stat_map.keys():
		if effects.has(k):
			var delta: int = int(effects.get(k, 0))
			if delta != 0:
				match k:
					"health": health += delta
					"happiness": happiness += delta
					"smart": smart += delta
					"reputation": reputation += delta
					"sanity": sanity += delta
					"karma": karma += delta
				var sign_str: String = "+" if delta > 0 else ""
				var info: Array = stat_map[k]
				summary_badges.append("%s %s %s%d" % [str(info[1]), str(info[0]), sign_str, delta])

	var money_pct: float = float(effects.get("money_pct", 0.0))
	if absf(money_pct) > 0.001 and money > 0:
		var pct_delta: int = int(round(float(money) * money_pct))
		money += pct_delta
		var s_pct: String = "+" if pct_delta >= 0 else ""
		summary_badges.append("💰 Birikim %s%s %d" % [s_pct, currency_symbol, pct_delta])

	var money_flat: int = int(effects.get("money_flat", 0))
	if money_flat != 0:
		# Yerel satın alma gücüne göre ölçeklendir (eğer olay genel ise)
		var scaled_flat: int = money_flat
		if effects.get("raw_currency", false) == false:
			scaled_flat = int(round(float(money_flat) * clampf(usd_exchange_rate * 0.12, 0.5, 45.0)))
		money += scaled_flat
		var s_flat: String = "+" if scaled_flat >= 0 else ""
		summary_badges.append("💵 %s%s %d" % [s_flat, currency_symbol, scaled_flat])

	clamp_all_stats()
	return summary_badges

func get_social_class_label() -> String:
	match social_class:
		"extreme_poor": return "DERİN YOKSULLUK"
		"low": return "DAR GELİRLİ / İŞÇİ SINIFI"
		"middle": return "ORTA SINIF"
		"high": return "ÜST-ORTA / REFAH SINIFI"
		"elite": return "ELİT / ZENGİN KESİM"
		_: return "ORTA SINIF"

func get_education_label() -> String:
	match education_level:
		"bebek": return "Okul Öncesi / Bebeklik"
		"ilkokul": return "İlköğretim Öğrencisi"
		"ortaokul": return "Ortaokul Öğrencisi"
		"lise": return "Lise Öğrencisi"
		"lise_mezunu": return "Lise Mezunu"
		"meslek_yuksek": return "Meslek Yüksekokulu Mezunu"
		"universite_ogrencisi": return "Üniversite Öğrencisi (%s)" % (university_major if university_major != "" else "Genel")
		"universite_mezunu": return "Üniversite Mezunu (%s)" % (university_major if university_major != "" else "Lisans")
		"yuksek_lisans": return "Yüksek Lisans / Uzman (%s)" % (university_major if university_major != "" else "Akademik")
		"doktora": return "Doktora / Akademisyen"
		_: return "Temel Eğitim"

func get_parents_summary_text() -> String:
	var parts: Array = []
	for npc in npcs:
		var r: String = str(npc.get("role", ""))
		if r in ["Anne", "Baba"] and bool(npc.get("alive", true)):
			parts.append("%s %s (%d yaş, %s)" % [
				r,
				str(npc.get("name", "")),
				int(npc.get("age", 30)),
				str(npc.get("job_title", "Çalışan"))
			])
	if parts.is_empty():
		return "Kimsesiz / Yetiştirme Yurdu"
	return " ve ".join(parts)

func get_living_children() -> Array:
	var res: Array = []
	for npc in npcs:
		if str(npc.get("role", "")) == "Çocuk" and bool(npc.get("alive", true)):
			res.append(npc)
	return res

func get_spouse() -> Dictionary:
	for npc in npcs:
		if bool(npc.get("married_to_player", false)) and bool(npc.get("alive", true)):
			return npc
	return {}

func get_portrait_dict() -> Dictionary:
	return {
		"seed": seed_val,
		"age": age,
		"gender": gender,
		"country_code": country_code,
		"social_class": social_class,
		"health": health,
		"happiness": happiness,
		"smart": smart,
		"sanity": sanity,
		"job_category": current_job_category,
		"tags": life_tags
	}
