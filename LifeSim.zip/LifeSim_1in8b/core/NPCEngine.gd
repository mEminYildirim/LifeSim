extends RefCounted

# Aile, Arkadaşlar, Eş, Çocuklar, Miras ve 2. Kuşak Geçiş Motoru

func generate_initial_family(gs: Object, c_info: Dictionary) -> void:
	gs.npcs.clear()
	var f_names: Array = c_info.get("female_names", ["Zeynep", "Elif", "Selin"])
	var m_names: Array = c_info.get("male_names", ["Mehmet", "Ali", "Kerem"])

	var mother_name: String = str(f_names[randi() % max(1, f_names.size())]) + " " + gs.last_name
	var father_name: String = str(m_names[randi() % max(1, m_names.size())]) + " " + gs.last_name

	var parent_jobs: Dictionary = {
		"extreme_poor": ["Gündelikçi İşçi", "Seyyar Satıcı", "Mevsimlik Tarım İşçisi"],
		"low": ["Fabrika İşçisi", "Kasiyer", "Belediye Şoförü", "Terzi"],
		"middle": ["İlkokul Öğretmeni", "Muhasebeci", "Hemşire", "Teknisyen"],
		"high": ["Başhekim Cerrah", "Hukuk Müşaviri", "Başmühendis", "Mimar"],
		"elite": ["Holding Yönetim Kurulu Üyesi", "Büyükelçi", "Yatırım Fonu Kurucusu"]
	}
	var job_pool: Array = parent_jobs.get(gs.social_class, parent_jobs["middle"])

	gs.npcs.append({
		"id": "npc_mother",
		"name": mother_name,
		"role": "Anne",
		"gender": "F",
		"age": randi_range(22, 36),
		"alive": true,
		"relation": randi_range(75, 98),
		"smart": randi_range(45, 88),
		"wealth_tier": gs.social_class,
		"job_title": str(job_pool[randi() % job_pool.size()]),
		"married_to_player": false
	})

	gs.npcs.append({
		"id": "npc_father",
		"name": father_name,
		"role": "Baba",
		"gender": "M",
		"age": randi_range(25, 40),
		"alive": true,
		"relation": randi_range(70, 95),
		"smart": randi_range(45, 88),
		"wealth_tier": gs.social_class,
		"job_title": str(job_pool[randi() % job_pool.size()]),
		"married_to_player": false
	})

	# %55 ihtimalle bir kardeş
	if randf() < 0.55:
		var sib_gender: String = "F" if (randf() < 0.5) else "M"
		var sib_pool: Array = f_names if sib_gender == "F" else m_names
		var sib_name: String = str(sib_pool[randi() % max(1, sib_pool.size())]) + " " + gs.last_name
		gs.npcs.append({
			"id": "npc_sibling_1",
			"name": sib_name,
			"role": "Kardeş",
			"gender": sib_gender,
			"age": randi_range(1, 6),
			"alive": true,
			"relation": randi_range(65, 92),
			"smart": randi_range(40, 90),
			"wealth_tier": gs.social_class,
			"job_title": "Çocuk",
			"married_to_player": false
		})

func process_yearly_npcs(gs: Object, c_info: Dictionary) -> Array:
	var logs: Array = []
	var life_exp: int = int(c_info.get("life_expectancy", 78))

	for npc in gs.npcs:
		if not bool(npc.get("alive", true)):
			continue
		npc["age"] = int(npc.get("age", 0)) + 1
		var n_age: int = int(npc["age"])
		var role: String = str(npc.get("role", ""))

		if role in ["Kardeş", "Çocuk"]:
			if n_age == 7:
				npc["job_title"] = "İlkokul Öğrencisi"
			elif n_age == 15:
				npc["job_title"] = "Lise Öğrencisi"
			elif n_age == 19:
				npc["job_title"] = "Üniversite Öğrencisi"
			elif n_age == 23:
				npc["job_title"] = "Genç Profesyonel"

		# Yaşlılık vefat kontrolü (Ebeveynler ve Eş için)
		if n_age >= (life_exp - 8):
			var death_prob: float = clampf(float(n_age - (life_exp - 10)) * 0.045, 0.02, 0.45)
			if randf() < death_prob:
				npc["alive"] = false
				gs.happiness = clampi(gs.happiness - 18, 0, 100)
				gs.sanity = clampi(gs.sanity - 8, 0, 100)
				logs.append("🕯️ Acı Kayıp: %s (%s) %d yaşında hayata gözlerini yumdu." % [str(npc.get("name", "")), role, n_age])

				if role in ["Anne", "Baba"]:
					var inh_mult: float = 0.0
					match str(npc.get("wealth_tier", "middle")):
						"extreme_poor": inh_mult = -0.4 # Borç kalma riski
						"low": inh_mult = 0.8
						"middle": inh_mult = 4.5
						"high": inh_mult = 18.0
						"elite": inh_mult = 65.0
					var inheritance: int = int(round(1500.0 * gs.usd_exchange_rate * inh_mult))
					if inheritance > 0:
						gs.money += inheritance
						logs.append("📜 Aile Mirası: Vefat eden %s tarafından sana %s %d miras kaldı." % [role.to_lower(), gs.currency_symbol, inheritance])
					elif inheritance < 0:
						gs.money += inheritance
						logs.append("⚠️ Ödenmemiş Aile Borcu: Vefatın ardından kalan %s %d borcu üstlenmek zorunda kaldın." % [gs.currency_symbol, abs(inheritance)])

	# Okul veya iş yıllarında otomatik yeni arkadaş edinme
	if gs.age in [8, 15, 20, 27] and gs.npcs.size() < 9:
		var f_names: Array = c_info.get("female_names", ["Deniz"])
		var m_names: Array = c_info.get("male_names", ["Can"])
		var s_names: Array = c_info.get("surnames", ["Kaya"])
		var fr_g: String = "F" if (randf() < 0.5) else "M"
		var pool: Array = f_names if fr_g == "F" else m_names
		var fr_name: String = str(pool[randi() % max(1, pool.size())]) + " " + str(s_names[randi() % max(1, s_names.size())])
		gs.npcs.append({
			"id": "npc_friend_" + str(gs.age),
			"name": fr_name,
			"role": "Arkadaş",
			"gender": fr_g,
			"age": gs.age + randi_range(-1, 2),
			"alive": true,
			"relation": randi_range(60, 85),
			"smart": randi_range(45, 90),
			"wealth_tier": gs.social_class,
			"job_title": "Sınıf/İş Arkadaşı",
			"married_to_player": false
		})
		logs.append("🤝 %s ile yakın bir dostluk kurdun." % fr_name)

	return logs

func interact_with_npc(gs: Object, npc: Dictionary, action: String, c_info: Dictionary) -> String:
	if not bool(npc.get("alive", true)):
		return "Hayatta olmayan biriyle etkileşime geçemezsin."

	var n_name: String = str(npc.get("name", "Kişi"))
	var rel: int = int(npc.get("relation", 50))

	match action:
		"chat":
			npc["relation"] = clampi(rel + randi_range(5, 11), 0, 100)
			gs.happiness = clampi(gs.happiness + 4, 0, 100)
			gs.sanity = clampi(gs.sanity + 3, 0, 100)
			return "☕ %s ile uzun ve samimi bir sohbet ettiniz. Aranızdaki bağ güçlendi." % n_name
		"spend_time":
			var cost: int = int(round(45.0 * gs.usd_exchange_rate))
			if gs.money >= cost and gs.age >= 14:
				gs.money -= cost
			npc["relation"] = clampi(rel + randi_range(9, 16), 0, 100)
			gs.happiness = clampi(gs.happiness + 7, 0, 100)
			return "🎭 %s ile birlikte keyifli bir gün geçirdiniz." % n_name
		"gift_money":
			var gift_amt: int = int(round(350.0 * gs.usd_exchange_rate))
			if gs.money < gift_amt:
				return "Hediye/destek vermek için en az %s %d nakit paran olmalı." % [gs.currency_symbol, gift_amt]
			gs.money -= gift_amt
			npc["relation"] = clampi(rel + 18, 0, 100)
			gs.karma = clampi(gs.karma + 5, 0, 100)
			return "🎁 %s adlı yakınını %s %d maddi destekle sevindirdin." % [n_name, gs.currency_symbol, gift_amt]
		"propose_marriage":
			if gs.age < 18:
				return "Evlilik için en az 18 yaşında olmalısın."
			if not gs.get_spouse().is_empty():
				return "Zaten evlisin!"
			if rel < 75:
				return "%s evlilik teklifini reddetti: İlişki düzeyiniz henüz yeterince güçlü değil (En az 75 olmalı)." % n_name
			npc["role"] = "Eş"
			npc["married_to_player"] = true
			gs.add_tag("evli")
			gs.happiness = clampi(gs.happiness + 18, 0, 100)
			return "💍 %s evlilik teklifini gözyaşları içinde kabul etti! Hayatlarınızı birleştirdiniz." % n_name
		"have_child":
			if gs.age < 19 or gs.age > 54:
				return "Çocuk sahibi olmak için uygun yaş aralığında değilsin."
			var f_names: Array = c_info.get("female_names", ["Ada"])
			var m_names: Array = c_info.get("male_names", ["Atlas"])
			var ch_g: String = "F" if (randf() < 0.5) else "M"
			var pool: Array = f_names if ch_g == "F" else m_names
			var ch_name: String = str(pool[randi() % max(1, pool.size())]) + " " + gs.last_name
			gs.npcs.append({
				"id": "npc_child_" + str(gs.age) + "_" + str(randi() % 100),
				"name": ch_name,
				"role": "Çocuk",
				"gender": ch_g,
				"age": 0,
				"alive": true,
				"relation": 95,
				"smart": clampi(gs.smart + randi_range(-10, 18), 35, 99),
				"wealth_tier": gs.social_class,
				"job_title": "Bebek",
				"married_to_player": false
			})
			gs.add_tag("ebeveyn")
			gs.happiness = clampi(gs.happiness + 16, 0, 100)
			return "👶 Ailenize yeni bir can katıldı! Çocuğunuz %s dünyaya geldi." % ch_name
		_:
			return "%s ile görüşüldü." % n_name

func find_new_partner(gs: Object, c_info: Dictionary) -> String:
	if gs.age < 16:
		return "Romantik tanışmalar için henüz çok gençsin."
	var f_names: Array = c_info.get("female_names", ["Elif"])
	var m_names: Array = c_info.get("male_names", ["Kerem"])
	var s_names: Array = c_info.get("surnames", ["Demir"])
	var p_gender: String = "M" if gs.gender == "F" else "F"
	var pool: Array = f_names if p_gender == "F" else m_names
	var p_name: String = str(pool[randi() % max(1, pool.size())]) + " " + str(s_names[randi() % max(1, s_names.size())])

	gs.npcs.append({
		"id": "npc_partner_" + str(gs.age) + "_" + str(randi() % 99),
		"name": p_name,
		"role": "Partner",
		"gender": p_gender,
		"age": clampi(gs.age + randi_range(-3, 4), 16, 85),
		"alive": true,
		"relation": randi_range(68, 88),
		"smart": randi_range(50, 92),
		"wealth_tier": gs.social_class,
		"job_title": "Profesyonel Çalışan",
		"married_to_player": false
	})
	gs.happiness = clampi(gs.happiness + 10, 0, 100)
	return "❤️ Sosyal bir buluşmada %s ile tanıştın ve aranızda sıcak bir yakınlaşma başladı!" % p_name

# 2. Kuşak Miras Devri (Karakter öldüğünde çocuğunun hayatından devam etme)
func transfer_legacy_to_child(gs: Object, child_npc: Dictionary, c_info: Dictionary) -> void:
	var inherited_cash: int = max(0, gs.money)
	for a in gs.owned_assets:
		inherited_cash += int(a.get("value", 0))
	inherited_cash += int(gs.financial_portfolio.get("fx_usd", 0))
	inherited_cash += int(gs.financial_portfolio.get("index_fund", 0))

	var child_full_name: String = str(child_npc.get("name", "Deniz Yılmaz"))
	var name_parts: PackedStringArray = child_full_name.split(" ")
	var ch_first: String = name_parts[0] if name_parts.size() > 0 else "Deniz"
	var ch_last: String = name_parts[name_parts.size() - 1] if name_parts.size() > 1 else gs.last_name
	var ch_age: int = clampi(int(child_npc.get("age", 18)), 0, 65)
	var ch_gender: String = str(child_npc.get("gender", "F"))

	gs.reset_for_new_life(gs.country_code, c_info, ch_gender, inherited_cash, gs.generation + 1, ch_last)
	gs.first_name = ch_first
	gs.full_name = ch_first + " " + ch_last
	gs.age = ch_age
	gs.smart = clampi(int(child_npc.get("smart", 68)), 35, 99)
	if ch_age >= 22:
		gs.education_level = "universite_mezunu"
		gs.current_job_title = "Mirasçı & Genç Profesyonel"
		gs.add_tag("universite_mezunu")
	elif ch_age >= 18:
		gs.education_level = "lise_mezunu"
		gs.current_job_title = "Genç Mirasçı"
		gs.add_tag("lise_mezunu")
	elif ch_age >= 6:
		gs.education_level = "ilkokul"
		gs.current_job_title = "Öğrenci"
	gs.add_tag("mirasci_kusak")
	generate_initial_family(gs, c_info)
