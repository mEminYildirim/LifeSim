extends RefCounted

# Kelebek Etkisi, Sıkı Ön Koşul Filtreleme (Causality Filter) ve Zaman Ayarlı Sonuç Kuyruğu
var all_events_by_id: Dictionary = {}
var childhood_events: Array = []
var youth_events: Array = []
var adult_events: Array = []
var senior_events: Array = []
var country_specific_events: Dictionary = {} # {country_code: [events]}
var story_arcs: Array = []

func register_databases(
	countries_db: Dictionary,
	ev_child: Array,
	ev_youth: Array,
	ev_adult: Array,
	ev_senior: Array,
	arcs_list: Array
) -> void:
	all_events_by_id.clear()
	childhood_events = ev_child
	youth_events = ev_youth
	adult_events = ev_adult
	senior_events = ev_senior
	story_arcs = arcs_list
	country_specific_events.clear()

	for ev in childhood_events:
		all_events_by_id[str(ev.get("id", ""))] = ev
	for ev in youth_events:
		all_events_by_id[str(ev.get("id", ""))] = ev
	for ev in adult_events:
		all_events_by_id[str(ev.get("id", ""))] = ev
	for ev in senior_events:
		all_events_by_id[str(ev.get("id", ""))] = ev

	for c_code in countries_db.keys():
		var c_data: Dictionary = countries_db.get(c_code, {})
		var c_evs: Array = c_data.get("local_events", [])
		country_specific_events[c_code] = c_evs
		for ev in c_evs:
			all_events_by_id[str(ev.get("id", ""))] = ev

	for arc in story_arcs:
		var stages: Array = arc.get("stages", [])
		for st in stages:
			all_events_by_id[str(st.get("id", ""))] = st

# Oyuncunun o yıl karşılaşacağı olayı seçer (Önce Kelebek Etkisi Kuyruğu, sonra Hikaye Zinciri, sonra Bağlamsal Havuz)
func pick_event_for_age(gs: Object) -> Dictionary:
	# 1. Zaman Ayarlı Sonuç Kuyruğu (Scheduled Butterfly Consequences) kontrolü
	for i in range(gs.scheduled_events.size() - 1, -1, -1):
		var item: Dictionary = gs.scheduled_events[i]
		var trig_age: int = int(item.get("trigger_age", -1))
		if gs.age >= trig_age:
			var ev_id: String = str(item.get("event_id", ""))
			var origin_note: String = str(item.get("origin_note", "Geçmişteki bir seçiminin yankısı"))
			gs.scheduled_events.remove_at(i)
			if all_events_by_id.has(ev_id):
				var scheduled_ev: Dictionary = all_events_by_id[ev_id].duplicate(true)
				scheduled_ev["_origin_note"] = origin_note
				return scheduled_ev

	# 2. Ülkeye Özel Zorunlu Dönüm Noktası Olayları (Sınav, Askerlik vb.)
	var local_pool: Array = country_specific_events.get(gs.country_code, [])
	var high_priority_local: Array = []
	for ev in local_pool:
		if is_event_eligible(ev, gs):
			if int(ev.get("weight", 50)) >= 90:
				high_priority_local.append(ev)
	if high_priority_local.size() > 0 and randf() < 0.72:
		var chosen_hp: Dictionary = _pick_weighted(high_priority_local)
		return chosen_hp.duplicate(true)

	# 3. Çok Aşamalı Hikaye Zinciri (Story Arcs) Başlatma veya İlerletme
	var arc_candidate: Dictionary = _check_story_arcs(gs)
	if not arc_candidate.is_empty():
		return arc_candidate

	# 4. Yaşa ve Ülkeye Uygun Bağlamsal Olay Havuzu
	var pool: Array = []
	for ev in local_pool:
		if is_event_eligible(ev, gs):
			pool.append(ev)

	var stage_list: Array = []
	if gs.age <= 12:
		stage_list = childhood_events
	elif gs.age <= 22:
		stage_list = youth_events
	elif gs.age <= 59:
		stage_list = adult_events
	else:
		stage_list = senior_events

	for ev in stage_list:
		if is_event_eligible(ev, gs):
			pool.append(ev)

	if pool.is_empty():
		return {}

	var picked: Dictionary = _pick_weighted(pool)
	return picked.duplicate(true)

func _check_story_arcs(gs: Object) -> Dictionary:
	if gs.age < 16 or randf() > 0.28:
		return {}
	for arc in story_arcs:
		var arc_id: String = str(arc.get("arc_id", ""))
		var stages: Array = arc.get("stages", [])
		if stages.is_empty():
			continue
		var cur_idx: int = int(gs.active_story_arcs.get(arc_id, 0))
		if cur_idx == 0:
			# İlk aşama başlatılabilir mi?
			var first_ev: Dictionary = stages[0]
			if is_event_eligible(first_ev, gs):
				if randf() < 0.22:
					var copy_ev: Dictionary = first_ev.duplicate(true)
					copy_ev["_arc_id"] = arc_id
					copy_ev["_arc_stage"] = 0
					return copy_ev
	return {}

func is_event_eligible(ev: Dictionary, gs: Object) -> bool:
	var ev_id: String = str(ev.get("id", ""))
	var repeatable: bool = bool(ev.get("repeatable", false))
	if not repeatable and (ev_id in gs.seen_events):
		return false

	var min_age: int = int(ev.get("min_age", 0))
	var max_age: int = int(ev.get("max_age", 120))
	if gs.age < min_age or gs.age > max_age:
		return false

	var conds: Dictionary = ev.get("conditions", {})
	if conds.is_empty():
		return true

	# Ülke filtresi
	var countries: Array = conds.get("countries", [])
	if not countries.is_empty() and not (gs.country_code in countries):
		return false

	# Sosyal sınıf filtresi
	var classes: Array = conds.get("classes", [])
	if not classes.is_empty() and not (gs.social_class in classes):
		return false

	# Cinsiyet filtresi (varsa)
	var req_gender: String = str(conds.get("gender", ""))
	if req_gender != "" and gs.gender != req_gender:
		return false

	# Zorunlu etiketler (required_tags)
	var req_tags: Array = conds.get("required_tags", [])
	for rt in req_tags:
		if not gs.has_tag(str(rt)):
			return false

	# Yasaklı etiketler (blocked_tags)
	var blk_tags: Array = conds.get("blocked_tags", [])
	for bt in blk_tags:
		if gs.has_tag(str(bt)):
			return false

	# Minimum istatistikler
	var min_stats: Dictionary = conds.get("min_stats", {})
	for st_key in min_stats.keys():
		if gs.get_stat_value(str(st_key)) < int(min_stats.get(st_key, 0)):
			return false

	# Maksimum istatistikler
	var max_stats: Dictionary = conds.get("max_stats", {})
	for st_key in max_stats.keys():
		if gs.get_stat_value(str(st_key)) > int(max_stats.get(st_key, 100)):
			return false

	return true

# Kilitli Seçenek Şeffaflığı (Transparency in Choices)
func evaluate_choice_lock(choice: Dictionary, gs: Object) -> Dictionary:
	var reasons: Array = []

	var req_stats: Dictionary = choice.get("req_stats", {})
	var stat_names_tr: Dictionary = {
		"health": "Sağlık",
		"happiness": "Mutluluk",
		"smart": "Zeka",
		"reputation": "İtibar",
		"sanity": "Akıl Sağlığı",
		"karma": "Vicdan"
	}
	for sk in req_stats.keys():
		var needed: int = int(req_stats.get(sk, 0))
		if gs.get_stat_value(str(sk)) < needed:
			var tr_label: String = str(stat_names_tr.get(sk, sk))
			reasons.append("%s En Az %d Olmalı" % [tr_label, needed])

	var req_money: int = int(choice.get("req_money", 0))
	if req_money > 0:
		var scaled_req: int = int(round(float(req_money) * clampf(gs.usd_exchange_rate * 0.12, 0.5, 45.0)))
		if gs.money < scaled_req:
			reasons.append("En Az %s %d Birikim Gerekli" % [gs.currency_symbol, scaled_req])

	var req_tags: Array = choice.get("req_tags", [])
	for rt in req_tags:
		var tag_str: String = str(rt)
		if not gs.has_tag(tag_str):
			var explicit_reason: String = str(choice.get("lock_reason", ""))
			if explicit_reason != "":
				reasons.append(explicit_reason)
			else:
				reasons.append(_format_tag_human(tag_str) + " Gerekli")

	if reasons.is_empty():
		return {"unlocked": true, "reason": ""}
	return {"unlocked": false, "reason": ", ".join(reasons)}

func _format_tag_human(tag: String) -> String:
	var clean: String = tag.replace("tag_", "").replace("_", " ").capitalize()
	return clean

func apply_choice_consequences(event_data: Dictionary, choice: Dictionary, gs: Object) -> Dictionary:
	var ev_id: String = str(event_data.get("id", ""))
	if ev_id != "" and not (ev_id in gs.seen_events):
		gs.seen_events.append(ev_id)

	var badges: Array = gs.apply_effects(choice.get("effects", {}))

	var add_tags: Array = choice.get("add_tags", [])
	for t in add_tags:
		gs.add_tag(str(t))

	var rem_tags: Array = choice.get("remove_tags", [])
	for t in rem_tags:
		gs.remove_tag(str(t))

	var tr_to_add: String = str(choice.get("add_trait", ""))
	if tr_to_add != "":
		gs.add_trait(tr_to_add)
		badges.append("✨ Özellik: " + tr_to_add)

	# Zaman ayarlı kelebek etkisi sonucu varsa kuyruğa ekle
	var sched: Dictionary = choice.get("schedule_consequence", {})
	if not sched.is_empty():
		var delay_y: int = int(sched.get("delay_years", 2))
		var target_ev: String = str(sched.get("event_id", ""))
		var o_note: String = str(sched.get("origin_note", str(event_data.get("title", "Geçmiş seçim"))))
		if target_ev != "":
			gs.scheduled_events.append({
				"trigger_age": gs.age + max(1, delay_y),
				"event_id": target_ev,
				"origin_note": o_note
			})
			badges.append("🦋 Kelebek Etkisi Kaydedildi")

	return {
		"outcome_text": str(choice.get("outcome_text", "Kararının sonuçları hayatına işlendi.")),
		"badges": badges
	}

func _pick_weighted(list: Array) -> Dictionary:
	var total_w: int = 0
	for item in list:
		total_w += max(1, int(item.get("weight", 50)))
	var roll: int = randi() % max(1, total_w)
	var acc: int = 0
	for item in list:
		acc += max(1, int(item.get("weight", 50)))
		if roll < acc:
			return item
	return list[0]
