extends RefCounted

# 13-22 Yaş Arası Detaylı Gençlik Olayları (56 Olay)
static func get_events() -> Array:
	return [
	  {
	    "id": "yth_01_kimlik_bunalimi_ve_ayna",
	    "title": "Aynadaki Yabancı: Ergenlik ve Kimlik Arayışı",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "13-16 yaş arası bedensel değişim ve 'Ben kimim?' sorusu.",
	    "text": "Odanın aynasına baktığında artık bir çocuk görmüyorsun. Toplumun senden bekledikleri ile kalbinin içindeki fırtına birbirine çarparak seni uykusuz bırakıyor.",
	    "min_age": 13,
	    "max_age": 16,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Felsefe ve edebiyat klasiklerine dalarak düşüncelerini olgunlaştır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Varoluşsal sancılarını entelektüel bir derinliğe dönüştürdün.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 10,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "felsefi_zihin"
	        ],
	        "remove_tags": [],
	        "add_trait": "Düşünür",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Müzik, spor veya sokak sanatıyla enerjini dışa vur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kendini ifade edecek sağlıklı bir kanal buldun; sosyal çevren genişledi.",
	        "effects": {
	          "health": 8,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Herkese öfkelenip odana kapan ve ailene cephe al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Evde gergin rüzgarlar esti, yalnızlığın derinleşti.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_02_ilk_ask_ve_mektup",
	    "title": "Sıranın Altına Bırakılan İlk Aşk Notu",
	    "category": "ask",
	    "vignette": "love",
	    "context_note": "Gençlik yıllarının kalp çarpıntısı ve ilk duygusal açılma.",
	    "text": "Teneffüs dönüşü defterinin arasında özenle katlanmış bir kağıt buldun. Uzun süredir uzaktan bakıştığın sınıf arkadaşın seni okul çıkışında çınar ağacının altına çağırıyor.",
	    "min_age": 14,
	    "max_age": 18,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kalbin küt küt atarak buluşmaya git ve duygularını samimiyetle aç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Utangaç gülümsemelerle başlayan ilk gençlik aşkın, hayatının en saf ve unutulmaz anısı oldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 6,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ilk_ask_hatirasi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {
	          "delay_years": 12,
	          "event_id": "adt_69_ilk_askin_yillar_sonra_mesaji",
	          "origin_note": "Lise yıllarında çınar ağacının altında başlayan ilk aşkının yıllar sonraki yankısı"
	        }
	      },
	      {
	        "text": "Heyecandan elin ayağına dolaşıp buluşmaya gitmekten vazgeç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Fırsat kaçtı; haftalarca koridorda karşılaştığınızda gözlerini kaçırdın.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "'Şu an sadece sınavlarıma odaklanmalıyım' diyerek kibarca arkadaş kalmayı öner",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Duygularını kontrol ettin ve ders disiplinine sadık kaldın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_03_arka_sokak_sigara_ve_ceteler",
	    "title": "Okul Arkası: 'Bir Kereden Bir Şey Olmaz' Teklifi",
	    "category": "kriz",
	    "vignette": "crime",
	    "context_note": "Akran baskısı ve zararlı alışkanlık/suç eşiği.",
	    "text": "Okulun arka bahçe duvarında toplanan havalı ama belalı bir grup, sana sigara/yasaklı madde uzatıp akşam yapacakları küçük bir market hırsızlığına gözcü olmanı istiyor.",
	    "min_age": 13,
	    "max_age": 18,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Net bir tavırla reddet ve oradan uzaklaş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Arkanızdan alay etseler de kendi iradenin efendisi olduğunu kanıtladın.",
	        "effects": {
	          "health": 6,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "iradeli"
	        ],
	        "remove_tags": [],
	        "add_trait": "İradeli",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gruba dahil olmak için teklifi kabul et ve gözcülük yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gece polis sireni çaldığında kaçarken yakalandın; siciline gençlik suçu uyarısı işlendi!",
	        "effects": {
	          "health": -8,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": -20,
	          "sanity": -12,
	          "karma": -18,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "genclik_hatasi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Grubun içindeki yakın arkadaşını kolundan tutup oradan çekip kurtar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem kendini hem de dostunu karanlık bir yoldan döndürdün!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 18,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_04_lise_munazara_turnuvasi",
	    "title": "Ulusal Liselerarası Münazara Şampiyonası",
	    "category": "egitim",
	    "vignette": "politics",
	    "context_note": "Hitabet, mantık yürütme ve ikna sanatı.",
	    "text": "Ülke çapında düzenlenen münazara finalinde salon tıklım tıklım. Jüri size savunması en zor tezi verdi; kürsüye çıkma sırası sende.",
	    "min_age": 15,
	    "max_age": 18,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tarihsel örnekler ve keskin bir mantıkla karşı tezi çürüt",
	        "lock_reason": "Zeka En Az 60 Olmalı",
	        "req_stats": {
	          "smart": 60
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Salon ayakta alkışladı! En İyi Konuşmacı ödülünü aldın; hukuk ve siyaset kapıları aralandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 12,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "munazara_sampiyonu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Heyecanlanıp not kağıtlarını karıştır ama içtenlikle konuşmayı tamamla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Birincilik gelmese de sahne cesaretin takdir topladı.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 4,
	          "reputation": 6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_05_yaz_tatili_ilk_is",
	    "title": "Yaz Sıcağında İlk Alın Teri: Garsonluk ve Çıraklık",
	    "category": "ekonomi",
	    "vignette": "work",
	    "context_note": "Gençlikte kendi paranı kazanmanın verdiği özgüven.",
	    "text": "Yaz tatilinde akranların plajda veya oyun başında vakit geçirirken, yoğun bir kafede/atölyede günde 10 saat çalışmaya başladın.",
	    "min_age": 15,
	    "max_age": 19,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yaz boyu azimle çalış, bahşişleri biriktir ve insan sarrafı ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ayakların şişti ama ilk kez kendi kazandığın parayla bilgisayar/kitap almanın gururunu yaşadın!",
	        "effects": {
	          "health": -2,
	          "happiness": 12,
	          "smart": 5,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 950,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "caliskan_genc"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İlk haftanın sonunda patronun azarlamasına kızıp işi bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Paradan oldun ama ezdirmeme tavrını korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 2,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_06_kopya_sebekesi_teklifi",
	    "title": "Sınav Öncesi Karanlık Teklif: Çalınmış Sorular",
	    "category": "egitim",
	    "vignette": "secret",
	    "context_note": "Üniversite/lise sınavları öncesi ahlaki ve hukuki uçurum.",
	    "text": "Büyük sınavdan iki gün önce şifreli bir mesajlaşma grubundan biri sana ulaştı: 'Belli bir ücret karşılığında sınav sorularının kitapçığını gece yarısı gönderebiliriz' diyor.",
	    "min_age": 17,
	    "max_age": 20,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Teklifi reddet, mesajı sil ve sadece kendi alın terine güven",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sınav sabahı vicdanın tertemiz olarak sıraya oturdun ve kendi hakkınla kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 18,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parayı ödeyip soruları al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 1500,
	        "req_tags": [],
	        "outcome_text": "Sınavdan 6 ay sonra yapılan incelemede şebeke çökertildi; sınavın iptal edildiği gibi 2 yıl men cezası aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": -28,
	          "smart": 0,
	          "reputation": -30,
	          "sanity": -22,
	          "karma": -25,
	          "money_flat": -1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sinav_iptali",
	          "sabikali"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_07_universite_yurt_odasi_krizi",
	    "title": "Yurt Odasında Gece Yarısı Gürültüsü ve Çatışma",
	    "category": "aile",
	    "vignette": "home",
	    "context_note": "Üniversite veya gençlik yıllarında farklı karakterlerle aynı odayı paylaşma sınavı.",
	    "text": "Sabah erken saatte çok kritik bir vize sınavın var; ancak oda arkadaşın ışığı açmış, yüksek sesle müzik dinleyip telefonla konuşuyor.",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sakin ama kararlı bir dille ortak yaşam kurallarını masaya yatır ve anlaşma sağla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Oda arkadaşın hatasını anladı; dönem boyu saygılı bir düzen kuruldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kulaklığını takıp sabahlamcılar salonunda (etüt odasında) çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Tartışmaya girmeden sınavına odaklandın ve yüksek not aldın.",
	        "effects": {
	          "health": -3,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kavgaya tutuşup yurt idaresiyle papaz ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İkiniz de kınama cezası aldınız ve sinirlerin yıprandı.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_08_erasmus_ve_degisim_bursu",
	    "title": "Sınırların Ötesi: Yurtdışı Öğrenci Değişim Bursu",
	    "category": "egitim",
	    "vignette": "migration",
	    "context_note": "Genç yaşta farklı bir ülkede bir dönem yaşama ve vizyon kazanma fırsatı.",
	    "text": "Okulun uluslararası ofisi panosunda yurtdışı değişim programı (Erasmus / Exchange) başvurularının başladığı duyuruldu. Kontenjan sadece 3 kişi!",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yabancı dil ve not ortalamanla burslu kontenjanı kazanıp 6 ay yurtdışında oku",
	        "lock_reason": "Değişim Bursu İçin Zeka 64+ Gerekli",
	        "req_stats": {
	          "smart": 64
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Farklı kültürlerden dostlar edindin, dilin kusursuzlaştı ve küresel bir vizyon kazandın!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 12,
	          "reputation": 16,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "uluslararasi_vizyon"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kendi imkanlarınla sırt çantalı (Interrail / Backpacker) bir yaz gezisine çık",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 800,
	        "req_tags": [],
	        "outcome_text": "Hostellerde kalarak az parayla dünyayı tanımanın yollarını öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": -800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_09_amfide_politik_protesto",
	    "title": "Kampüs Meydanında Pankartlar ve Polis Kordonu",
	    "category": "kriz",
	    "vignette": "protest",
	    "context_note": "Gençlik idealizmi, öğrenci hakları ve güvenlik güçleriyle karşı karşıya gelme.",
	    "text": "Yemekhane zamlarını ve barınma krizini protesto eden yüzlerce öğrenci rektörlük önünde toplandı. Çevik kuvvet kalkanlarıyla kampüs kapısını kapattı.",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Öğrenci temsilcisi olarak rektörlükle barışçıl müzakere masasına otur",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kriz şiddete dönüşmeden zamları geri aldırdın; tüm kampüste saygın bir lider oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 6,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ogrenci_lideri"
	        ],
	        "remove_tags": [],
	        "add_trait": "Uzlaştırıcı",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "En ön safta slogan atıp barikata yüklen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Biber gazına maruz kaldın ve bir gece gözaltında tutuldun; ancak muhalif çevrelerde adın duyuldu.",
	        "effects": {
	          "health": -10,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": -8,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "aktivist"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kütüphanenin arka kapısından çıkıp eve git",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Başın derde girmedi.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_10_kalp_kirikligi_ve_terk_edilis",
	    "title": "Yağmurlu Durakta Beklenmedik Ayrılık",
	    "category": "ask",
	    "vignette": "heartbreak",
	    "context_note": "Gençlikte yaşanan ilk büyük duygusal yıkım ve başa çıkma biçimi.",
	    "text": "Çok değer verdiğin ve geleceğe dair hayaller kurduğun partnerin, soğuk bir akşamüstü 'Artık aynı yolda yürümüyoruz' diyerek arkasını dönüp gitti.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Acını spora, sanata ve akademik yükselişe kanalize ederek küllerinden doğ",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ayrılık acısı seni kırmak yerine çok daha güçlü, olgun ve başarılı birine dönüştürdü!",
	        "effects": {
	          "health": 8,
	          "happiness": -4,
	          "smart": 10,
	          "reputation": 10,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "duygusal_olgunluk"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Aylarca depresyona girip derslerini ve sağlığını boşver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Karanlık bir dönem geçirdin; dostlarının desteğiyle güçbela toparlandın.",
	        "effects": {
	          "health": -10,
	          "happiness": -20,
	          "smart": -5,
	          "reputation": 0,
	          "sanity": -16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_11_hackathon_48_saat",
	    "title": "48 Saatlik Uykusuz Hackathon Maratonu",
	    "category": "kariyer",
	    "vignette": "tech",
	    "context_note": "Genç yazılımcı ve tasarımcıların teknoloji üretme heyecanı.",
	    "text": "Üniversite teknoparkında 48 saat sürecek ulusal bir yazılım ve girişimcilik yarışması (Hackathon) başladı. Masanın üzeri kahve kupaları ve kablo yığınlarıyla dolu.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yapay zeka destekli erken teşhis/eğitim prototipi geliştirip birinciliği al",
	        "lock_reason": "Birincilik İçin Zeka 65+ Gerekli",
	        "req_stats": {
	          "smart": 65
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Jüri başkanı sahnede size ödül çekini ve ilk staj/iş teklifini sundu!",
	        "effects": {
	          "health": -5,
	          "happiness": 20,
	          "smart": 12,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hackathon_birincisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tasarım ve sunum kısmını üstlenerek finalistler arasına gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sektörden pek çok mühendis ve yatırımcıyla kartvizit alışverişi yaptın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 6,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_12_gece_yarisi_yasadisi_yaris",
	    "title": "Çevre Yolunda Gece Yarısı Hız Tutkusu",
	    "category": "kriz",
	    "vignette": "sports",
	    "context_note": "Gençlik adrenalini ve ölümcül trafik riski.",
	    "text": "Gece saat 02:00. Arkadaş grubun modifiye edilmiş bir araçla boş çevre yolunda tehlikeli bir hız denemesi yapmak istiyor ve seni de yan koltuğa çağırıyor.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Araca binmeyi reddet ve arkadaşlarını da anahtarı bırakmaya ikna et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "O gece yağmur nedeniyle virajda yaşanan zincirleme kazadan hepinizi kurtardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 10,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Adrenaline kapılıp araca bin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Araç ıslak zeminde bariyerlere çarptı! Aylarca fizik tedavi görmek zorunda kaldın.",
	        "effects": {
	          "health": -32,
	          "happiness": -20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -16,
	          "karma": 0,
	          "money_flat": -1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "tag_yarali"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_13_garaj_muzik_grubu",
	    "title": "Bodrum Katında Kurulan Amatör Müzik Grubu",
	    "category": "kariyer",
	    "vignette": "music",
	    "context_note": "Gençlik enerjisinin müziğe ve sahneye dönüşmesi.",
	    "text": "Yumurta kartonlarıyla ses yalıtımı yaptığınız nemli bir bodrum katında arkadaşlarınla prova yapıyorsunuz. Şehirdeki gençlik festivalinde sahne alma şansı doğdu.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi bestelerinizi çalarak festivalde seyirciyi coştur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sahne enerjin büyüleyiciydi; yerel mekanlardan ücretli konser teklifleri gelmeye başladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sahne_deneyimi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Grup içi egolar yüzünden dağılmadan önce stüdyo kaydı alıp hatıra bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Grubunuz dağılsa da kaydettiğiniz şarkılar dijital platformlarda binlerce kez dinlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_14_profesore_asistanlik",
	    "title": "Kürsü Başkanının Araştırma Teklifi",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Akademik kariyerin ve bilimsel yayıncılığın ilk basamağı.",
	    "text": "Bölümün en sert ama en saygın profesörü, yazdığın dönem ödevini okuduktan sonra seni odasına çağırdı. Uluslararası bir makalede yardımcı araştırmacı olmanı öneriyor.",
	    "min_age": 19,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "universite_ogrencisi"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yaz tatilini laboratuvarda/arşivde geçirip makaleye imzanı at",
	        "lock_reason": "Zeka En Az 66 Olmalı",
	        "req_stats": {
	          "smart": 66
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Daha lisans öğrencisiyken uluslararası indeksli bir dergide makalen yayımlandı!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 14,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "akademik_yayin",
	          "akademik_basari"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {
	          "delay_years": 6,
	          "event_id": "adt_70_akademik_atif_odulu",
	          "origin_note": "Üniversite yıllarında profesörle yayımladığın bilimsel makalenin uluslararası yankısı"
	        }
	      },
	      {
	        "text": "Sosyal hayatını ve yaz işini tercih ederek teklifi kibarca reddet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yazın dinlendin ve harçlık kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_15_kripto_ve_harclik_spekulasyonu",
	    "title": "Yurt Koridorunda Kripto Para Fısıltısı",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Gençler arasında hızla yayılan finansal spekülasyon dalgası.",
	    "text": "Kantin ve yurt koridorlarında herkes yeni çıkan bir altcoin projesinden bahsediyor. Bursunu ve harçlığını yatırırsan bir ayda ikiye katlayacağı söyleniyor.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Temkinli davran; sadece kaybetmeyi göze alacağın küçük bir miktarla grafik analizi öğren",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Finansal piyasaların işleyişini öğrendin ve makul bir kârla zamanında çıktın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 750,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tüm harçlığını ve kredi paranı tek bir tokene bas",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Geliştiriciler projeyi boşaltıp kaçtı (Rug-pull)! Ay sonuna kadar makarnaya talim ettin.",
	        "effects": {
	          "health": 0,
	          "happiness": -16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": 0,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_16_siber_guvenlik_acigi",
	    "title": "Üniversite Sisteminde Bulunan Güvenlik Açığı",
	    "category": "kariyer",
	    "vignette": "tech",
	    "context_note": "Siyah şapkalı (Black-hat) korsanlık ile Beyaz şapkalı (White-hat) siber güvenlik uzmanlığı ayrımı.",
	    "text": "Gece yarısı okulun otomasyon sistemine girerken veri tabanında tüm notları ve kişisel verileri açıkta bırakan kritik bir yazılım zaafiyeti (SQL/API açığı) keşfettin!",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 60
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Açığı kötüye kullanma; detaylı bir teknik raporla Bilgi İşlem Dairesi'ne bildir (White-Hat)",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Rektörlük dürüstlüğünü ödüllendirdi ve seni siber güvenlik ekibine yarı-zamanlı uzman olarak aldı!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 10,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 16,
	          "money_flat": 1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "siber_uzman"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Para karşılığında diğer öğrencilerin devamsızlık ve notlarını gizlice değiştir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Birkaç ay iyi para kazandın ama log kayıtlarından yakalanıp disiplin kuruluna sevk edildin!",
	        "effects": {
	          "health": 0,
	          "happiness": -20,
	          "smart": 0,
	          "reputation": -25,
	          "sanity": -15,
	          "karma": -20,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "disiplin_cezasi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_17_ev_arkadasi_kira_kacisi",
	    "title": "Kira Günü Sürprizi: Kaçan Ev Arkadaşı",
	    "category": "ekonomi",
	    "vignette": "home",
	    "context_note": "Gençlikte ortak ev yaşamının maddi tuzakları.",
	    "text": "Sabah uyandığında öğrenci evindeki oda arkadaşının eşyalarını toplayıp gittiğini, üstelik son 2 ayın elektrik-doğalgaz faturalarını ve kira payını ödemediğini fark ettin!",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ev sahibiyle dürüstçe konuş, ek iş yaparak borcu kapat ve yeni güvenilir bir ortak bul",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zorlu bir ay geçirdin ama kriz yönetimi becerin ve itibarın sağlam kaldı.",
	        "effects": {
	          "health": -4,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": -900,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sen de eşyalarını toplayıp gece yarısı evi terk et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Paranı kurtardın ama ev sahibi arkandan hukuki takip başlattı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": -12,
	          "sanity": 0,
	          "karma": -10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_18_spor_sakatligi_ve_donus",
	    "title": "Kritik Maçta Çapraz Bağ Sakatlığı",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Genç sporcuların kariyerini tehdit eden fiziksel sınav.",
	    "text": "Okul/kulüp takımıyla çıktığın turnuva maçında havada topa yükselip yere ters bastığın an dizinden korkunç bir ses geldi.",
	    "min_age": 14,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ameliyat sonrası her gün disiplinle fizik tedavi egzersizlerini uygula",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aylar süren sabrın sonunda sahalara eskisinden daha güçlü döndün.",
	        "effects": {
	          "health": 10,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tedaviyi aksatıp sporu tamamen bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dizinde hafif bir aksama kaldı ve kilo almaya başladın.",
	        "effects": {
	          "health": -14,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_19_felsefe_kulubu_ve_varolus",
	    "title": "Gece Yarısı Çay Ocağında Varoluşçuluk Tartışması",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "Gençlikte dünyayı değiştirme arzusu ve düşünsel kimlik.",
	    "text": "Kampüsün dumanlı çay ocağında Camus, Sartre, İbn Haldun ve modern toplum üzerine sabaha kadar süren ateşli bir tartışmanın ortasındasın.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tartışmaları derleyip aylık bir düşünce ve edebiyat fanzini çıkar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Fanzinin elden ele dolaştı; entelektüel çevrede saygın bir kalem oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 10,
	          "reputation": 14,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "edebi_kalem"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece dinleyici kalıp kendi iç dünyanı sorgula",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bakış açın zenginleşti.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_20_ailenin_meslek_dayatmasi",
	    "title": "Tercih Formu Başında Aile Kavgası",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Kendi tutkuların ile ailenin 'garanti meslek' beklentisi arasındaki çatışma.",
	    "text": "Gelecek planlarını yaptığın akşam baban masaya vurdu: 'Sanatla, felsefeyle, girişimle karın doymaz! Bizim dediğimiz garanti bölüme/işe gireceksin!'",
	    "min_age": 17,
	    "max_age": 20,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Aileni kırmadan ama kararlılıkla kendi seçtiğin bölümün/yolun arkasında dur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İlk yıl soğuk rüzgarlar esse de başarınla haklılığını kanıtladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kendi_yolunu_cizen"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ailenin istediği yolu seç ama gizlice kendi tutkunu da yan dal olarak sürdür",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İki karpuzu bir koltuğa sığdırmak yorucu olsa da hem aileni mutlu ettin hem hayalini korudun.",
	        "effects": {
	          "health": -4,
	          "happiness": 6,
	          "smart": 12,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_21_gonullu_arama_kurtarma",
	    "title": "Üniversite Arama Kurtarma ve Doğa Kulübü",
	    "category": "saglik",
	    "vignette": "nature",
	    "context_note": "Doğa sporları ve afet bilinci.",
	    "text": "Dağcılık ve arama-kurtarma kulübünün kış kampında çığ ve ilk yardım eğitimi veriliyor.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Eğitimi tamamlayıp sertifikalı arama-kurtarma gönüllüsü ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem kondisyonun zirveye çıktı hem de kriz anlarında hayat kurtarma becerisi edindin!",
	        "effects": {
	          "health": 14,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "arama_kurtarma"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hafta sonu doğa yürüyüşleriyle yetin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Temiz hava sana iyi geldi.",
	        "effects": {
	          "health": 6,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_22_ikinci_el_kitap_ve_sahaf",
	    "title": "Sahaflar Çarşısında İhtiyar Kitapçının Çırağı",
	    "category": "ekitim",
	    "vignette": "academy",
	    "context_note": "Nadir kitaplar ve kültür tarihiyle kurulan bağ.",
	    "text": "Dar bir pasajdaki asırlık sahaf dükkanının sahibi, rafları tasnif etmen karşılığında sana harçlık ve istediğin nadir eserleri okuma izni teklif ediyor.",
	    "min_age": 15,
	    "max_age": 21,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hafta sonları sahafta çalış; nadir baskıları ve kültür tarihini öğren",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kültürel birikimin ve esnaf ağın inanılmaz gelişti.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 12,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 650,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sahaf_ciragi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kısa süre çalışıp sadece harçlığını al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Cep harçlığın çıktı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 350,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_23_sosyal_medya_linci_veya_viral",
	    "title": "Sosyal Medyada Bir Gecede Viral Olmak",
	    "category": "kriz",
	    "vignette": "tech",
	    "context_note": "Dijital çağda şöhret ve linç kültürünün iki keskin yüzü.",
	    "text": "Çektiğin eleştirel/mizahi bir kısa video bir gecede milyonlarca kez izlendi! Yorumların yarısı seni göklere çıkarırken diğer yarısı hakaret yağdırıyor.",
	    "min_age": 14,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Soğukkanlılığını koru; kaliteli içerik üretmeye devam edip sponsorluk anlaşması imzala",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dijital dünyadaki ilk ciddi gelirini ve sadık takipçi kitleni oluşturdun!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 2400,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "icerik_ureticisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kötü yorumları kafana takıp sabaha kadar kavga et ve hesabını kapat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dijital zorbalık sinirlerini fena halde yıprattı.",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_24_otel_staji_ve_turizm",
	    "title": "Sahil Kasabasında Yaz Stajı ve Yabancı Konuklar",
	    "category": "kariyer",
	    "vignette": "migration",
	    "context_note": "Turizm ve hizmet sektöründe yabancı dil pratiği.",
	    "text": "Yaz aylarında turistik bir otelde veya rehberlik acentesinde çalışma fırsatı yakaladın.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yabancı konuklarla sürekli pratik yapıp organizasyon becerini kanıtla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem iyi bahşiş kazandın hem de yurtdışından referans mektupları topladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 8,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece mesai saatini doldurup denizde yüz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Keyifli bir yaz geçirdin.",
	        "effects": {
	          "health": 6,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_25_laboratuvar_kazasi_veya_kesif",
	    "title": "Kimya/Fizik Laboratuvarında Beklenmedik Reaksiyon",
	    "category": "egitim",
	    "vignette": "science",
	    "context_note": "Deneysel bilimde dikkat ve güvenlik.",
	    "text": "Laboratuvar dersinde deney tüpündeki karışım beklenenden hızlı ısınmaya ve renk değiştirmeye başladı.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Koruyucu gözlüğünü takıp çeker ocakta reaksiyonu güvenle kontrol altına al ve sonucu raporla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hatanın içindeki ilginç kimyasal davranışı belgeleyerek tam not aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 10,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Panikle tüpü düşürüp laboratuvarı duman altında bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kimse yaralanmadı ama dönem boyu laboratuvar şakalarının konusu oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_26_kardesin_basini_beladan_kurtarmak",
	    "title": "Kardeşin/Kuzenin Gece Yarısı Yardım Çağrısı",
	    "category": "aile",
	    "vignette": "crisis",
	    "context_note": "Aile bağları ve kriz çözme.",
	    "text": "Gece saat 01:30'da telefonun çaldı. Kardeşin/yakın kuzenin yanlış arkadaşlara uyup tekinsiz bir semtte mahsur kalmış ve senden yardım istiyor.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Soğukkanlılıkla konumu al, güvenli bir şekilde gidip onu oradan çekip çıkar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kardeşin boynuna sarılıp ağladı; aranızdaki güven ömür boyu sarsılmaz hale geldi.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 4,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Durumu hemen anne-babana haber verip birlikte müdahale edin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Biraz azar işitse de güvenli şekilde eve döndü.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_27_tiyatro_veya_sinema_kulubu",
	    "title": "Kısa Film Çekimi ve Kamera Arkası",
	    "category": "egitim",
	    "vignette": "art",
	    "context_note": "Görsel anlatım ve ekip yönetimi.",
	    "text": "Elinizdeki kısıtlı bütçeyle ve ödünç kamerayla ulusal kısa film yarışması için mahallede bir senaryo çekmeye karar verdiniz.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Senaryoyu yaz ve kurguyu sabahlara kadar uğraşıp tamamla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kısa filminiz festivalde Jüri Özel Ödülü kazandı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 8,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sinema_tutkunu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çekimler yarıda kalsa da ekip arkadaşlarınla harika anılar biriktir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Deneyim kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_28_ehliyet_sinavi_heyecani",
	    "title": "Direksiyon Sınavında Yokuş Kalkışı",
	    "category": "egitim",
	    "vignette": "work",
	    "context_note": "Yetişkinliğe geçişin sembolik adımlarından sürücü belgesi.",
	    "text": "Ehliyet sınavında müfettiş yan koltukta kaşlarını çatmış oturuyor. Dik bir yokuşta kırmızı ışıkta durdun ve arkandaki kamyon tamponuna kadar yanaştı!",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Debriyaj/gaz dengesini kusursuz kurup aracı bir santim bile kaydırmadan kaldır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Müfettiş takdirle başını salladı; ilk denemede ehliyetini aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ehliyet_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Heyecandan aracı stop ettirip bir sonraki sınava kal",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Moralin biraz bozulsa da ikinci sınavda daha çok çalışıp geçtin.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": -250,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ehliyet_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_29_felsefi_vejetaryenlik_ve_etik",
	    "title": "Tüketim Etiği ve Doğa Bilinci",
	    "category": "felsefe",
	    "vignette": "nature",
	    "context_note": "Gençlikte beslenme, çevre ve yaşam etiği üzerine sorgulamalar.",
	    "text": "Okuduğun ekoloji makaleleri ve izlediğin belgeseller sonrasında kendi yaşam biçiminin doğaya etkisini sorgulamaya başladın.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sağlıklı, doğal ve sürdürülebilir bir beslenme/yaşam disiplini benimse",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem bedenin hafifledi hem de vicdani tutarlılığın arttı.",
	        "effects": {
	          "health": 12,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kampüste geri dönüşüm ve sıfır atık topluluğu kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çevre bilincini yayarak liderlik deneyimi kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_30_ilk_politik_oy_pusulasi",
	    "title": "Sandık Başında İlk Oy ve Yurttaşlık Bilinci",
	    "category": "felsefe",
	    "vignette": "politics",
	    "context_note": "18 yaşında ilk kez seçim sandığına gitmenin ağırlığı.",
	    "text": "On sekiz yaşına bastın ve elinde mühürle ilk kez seçim kabinine girdin. Ailenin desteklediği parti ile senin gelecek vizyonun birbirinden farklı.",
	    "min_age": 18,
	    "max_age": 21,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Parti programlarını ve ekonomik verileri inceleyip kendi hür iradenle oyunu kullan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Birey olmanın ve yurttaşlık sorumluluğunun bilincine vardın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sandık müşahidi olup oyların adil sayılmasını sabaha kadar takip et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Demokratik sürece bizzat katkı sundun.",
	        "effects": {
	          "health": -3,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_31_platonik_ask_ve_siir",
	    "title": "Defter Kenarlarına Yazılan Gizli Satırlar",
	    "category": "ask",
	    "vignette": "art",
	    "context_note": "Karşılıksız veya söze dökülemeyen gençlik duyguları.",
	    "text": "Aylardır uzaktan hayranlık duyduğun kişinin başka biriyle el ele yürüdüğünü gördün.",
	    "min_age": 14,
	    "max_age": 21,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hüznünü olgunlukla karşıla ve duygularını edebi bir öyküye dönüştür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kalp sızısından unutulmaz bir sanat eseri doğdu.",
	        "effects": {
	          "health": 0,
	          "happiness": -3,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Takıntı yapıp sosyal medyadan gizlice takip etmeye devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kendini boş yere yıprattın.",
	        "effects": {
	          "health": 0,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_32_burs_mulakati_terlemesi",
	    "title": "Vakıf Bursu Mülakatında Zor Soru",
	    "category": "ekonomi",
	    "vignette": "academy",
	    "context_note": "Eğitim masraflarını karşılamak için girilen burs sınavı.",
	    "text": "Ülkenin önde gelen eğitim vakfının mülakatındasın. Jüri başkanı soruyor: 'Bu bursu sana verirsek, 10 yıl sonra topluma nasıl bir borç ödeyeceksin?'",
	    "min_age": 17,
	    "max_age": 21,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "extreme_poor",
	        "low",
	        "middle"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gözlerinin içine bakarak kendi mahallendeki gençlere ışık olma projeni anlat",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 56
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Samimiyetin ve vizyonun jüriyi etkiledi; karşılıksız eğitim bursunu kazandın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bursiyer"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Heyecandan basmakalıp cümleler kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Asil listeye giremedin ama yedek listeden kısmi kitap desteği aldın.",
	        "effects": {
	          "health": 0,
	          "happiness": 2,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_33_rock_veya_kultur_festivali",
	    "title": "Çadırlı Müzik Festivalinde Yağmur ve Dostluk",
	    "category": "aile",
	    "vignette": "music",
	    "context_note": "Gençlik festivallerinin unutulmaz enerjisi.",
	    "text": "Üç günlük açık hava müzik festivalinin ikinci gecesinde sağanak yağmur başladı, çadırlar çamura battı ama sahnede en sevdiğin grup çalıyor!",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yağmura aldırmadan binlerce gençle birlikte şarkılara eşlik et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gençliğin verdiği o saf özgürlük hissini iliklerine kadar yaşadın!",
	        "effects": {
	          "health": -3,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çadırı sağlamlaştırıp üşüyen kamp komşularına sıcak çay/kahve ikram et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Festivalde yeni ve sıkı dostlar edindin.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_34_stajda_angarya_mi_ogrenme_mi",
	    "title": "İlk Staj Günü: Fotokopi mi, Gerçek Proje mi?",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "İş dünyasıyla ilk temasta inisiyatif alma.",
	    "text": "Yaz stajına başladığın şirkette kıdemli çalışanlar sana sadece çay söyleyip binlerce sayfa evrak fotokopisi çektiriyor.",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Fotokopileri hızla bitirip evraklardaki veri hatalarını düzelten bir otomasyon tablosu hazırla",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Departman müdürü tabloyu görünce şaşkınlıkla seni ana proje ekibine dahil etti!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 10,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "staj_yildizi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Söyleneni yapıp staj defterini imzalatarak günü kurtar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sorunsuz ama sıradan bir staj dönemi geçirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 2,
	          "smart": 0,
	          "reputation": 2,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_35_uykusuz_final_haftasi",
	    "title": "Final Haftasında Üç Gün Sıfır Uyku",
	    "category": "saglik",
	    "vignette": "exam",
	    "context_note": "Akademik baskı ve fiziksel tükeniş sınırı.",
	    "text": "Üst üste gelen ağır sınavlar yüzünden 60 saattir neredeyse hiç uyumadın ve litrelerce kahve/enerji içeceği tükettin. Son sınav sabahı ellerin titriyor.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Enerji içeceklerini bırak, 3 saat derin uyu ve berrak zihinle sınava gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bedenini dinlemek doğru karardı; bildiğin soruları hatasız yaptın.",
	        "effects": {
	          "health": 4,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kafein yüklemesine devam edip sınava gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sınavın ortasında tansiyonun düştü ve revire kaldırıldın!",
	        "effects": {
	          "health": -16,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_36_ikinci_el_motosiklet_tutkusu",
	    "title": "Kuryelik ve Özgürlük Arasında: İlk Motosiklet",
	    "category": "ekonomi",
	    "vignette": "sports",
	    "context_note": "Gençlikte mobilite, ek gelir ve trafik riski.",
	    "text": "Biriktirdiğin harçlıkla ikinci el küçük bir motosiklet/scooter alma fırsatın doğdu. Hem okula gidebilir hem de akşamları paket servisi yapabilirsin.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tam korumalı kask ve mont alıp kurallara uyarak part-time kuryelik yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 400,
	        "req_tags": [],
	        "outcome_text": "Hem ulaşımın kolaylaştı hem de kendi cep harçlığını fazlasıyla çıkardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kasksız ve dikkatsiz kullanarak yağmurlu havada kayıp düş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Motor hasar gördü, dizlerin ve dirseklerin soyuldu.",
	        "effects": {
	          "health": -15,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": -500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_37_huzurevi_ve_kusaklar_bulusmasi",
	    "title": "Yaşlılar Bakımevinde Hikaye Dinleme Günü",
	    "category": "felsefe",
	    "vignette": "family",
	    "context_note": "Gençlik enerjisi ile yaşlılık bilgeliğinin kesişimi.",
	    "text": "Sosyal sorumluluk projesi kapsamında ziyaret ettiğin huzurevinde, eski bir diplomat/öğretmen sana gençlik yıllarında yaptığı en büyük hatayı anlatıyor.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Saatlerce onu dinle ve anılarını daktiloya/bilgisayara geçir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir ömrün tecrübesini dinlemek sana paha biçilmez bir hayat vizyonu kazandırdı.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kısa bir ziyaret yapıp arkadaşlarınla kafeye geç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Görevini tamamladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 4,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_38_sanat_galerisi_veya_sokak_sergisi",
	    "title": "İlk Gençlik Sergisi ve Eleştirmenler",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Üretilen ilk eserlerin kamuoyuyla buluşması.",
	    "text": "Çektiğin fotoğraflar veya yaptığın illüstrasyonlar belediyenin gençlik galerisinde sergilenmeye seçildi.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sergi açılışında sanatseverlerle tanış ve ilk eser satışını gerçekleştir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sanatının para ve takdir kazanabileceğini görmek özgüvenini uçurdu!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1100,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eleştirmenlerin sert yorumlarına alınganlık gösterip tartış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sanat dünyasının dikenli yüzüyle tanıştın.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": 4,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_39_arkadasin_borc_istegi",
	    "title": "Yakın Arkadaşın Şüpheli Borç Talebi",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Dostluk ile finansal sınırlar arasındaki denge.",
	    "text": "Liseden beri tanıdığın bir arkadaşın telaşla yanına gelip 'Çok acil paraya ihtiyacım var, haftaya iki katıyla ödeyeceğim' diyerek tüm birikimini istiyor; ancak yasadışı bahis oynadığı dedikodusu var.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Nakit para vermeyi reddet ama bağımlılıktan kurtulması için danışmanlık merkezine birlikte gitmeyi teklif et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gerçek dostluğun ne olduğunu gösterdin; hem paranı korudun hem de onu uçurumdan çektin.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kıyamayıp tüm birikimini ona borç ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Parayı bahiste kaybetti ve telefonlarını açmamaya başladı; hem paran hem dostun gitti!",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": -1000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_40_kampus_radyosu_programi",
	    "title": "Gece Yarısı Kampüs Radyosu Mikrofonu",
	    "category": "kariyer",
	    "vignette": "music",
	    "context_note": "Ses, iletişim ve medya deneyimi.",
	    "text": "Üniversite/okul radyosunda gece 23:00-01:00 kuşağını sunacak gönüllü bir yayıncı aranıyor.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Mikrofonun başına geç; edebiyat, müzik ve dinleyici telefonlarıyla efsane bir program yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sesin ve sohbetin kampüste fenomen oldu; medya dünyasından teklifler gelmeye başladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Teknik masada ses kurgusu ve yayın akışını yönet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Medya teknolojilerine hakimiyet kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_41_sahte_is_ilani_tuzagi",
	    "title": "'Evden Günde 2 Saat Çalışarak Yüksek Gelir' Tuzağı",
	    "category": "kriz",
	    "vignette": "crime",
	    "context_note": "Gençlerin ve öğrencilerin hedef alındığı saadet zinciri / dolandırıcılık ağları.",
	    "text": "Sosyal medyada gördüğün bir ilanda, önce 'eğitim ve giriş paketi' için para yatırman, sonra alt üye bularak zengin olacağın vaat ediliyor.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bunun bir piramit/saadet zinciri (Ponzi) olduğunu fark et ve arkadaşlarını da uyar",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 50
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Analitik zekan sayesinde dolandırıcıların tuzağına düşmedin.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 10,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kolay para hayaliyle giriş ücretini yatır ve akrabalarını sisteme sokmaya çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Şirket bir ay sonra kapandı; hem paran yandı hem de çevrene karşı mahcup oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": -16,
	          "smart": 0,
	          "reputation": -16,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": -900,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_42_yabanci_turistle_rehberlik",
	    "title": "Tarihi Çarşıda Yolu Kaybeden Gezginler",
	    "category": "egitim",
	    "vignette": "migration",
	    "context_note": "Kültürlerarası iletişim ve misafirperverlik.",
	    "text": "Şehrin tarihi meydanında haritaya bakıp tartışan yabancı bir belgesel ekibi/gezgin grubu gördün.",
	    "min_age": 14,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yanlarına gidip şehrin gizli kalmış tarihi noktalarını ve hikayelerini anlat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ekip bilgine hayran kaldı; belgesel jeneriğinde yerel danışman olarak adına yer verdiler!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 6,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kısaca yön tarif edip yoluna devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Nazikçe yardımcı oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 4,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_43_satranc_veya_espor_turnuvasi",
	    "title": "Ulusal Gençlik Strateji ve E-Spor Finali",
	    "category": "kariyer",
	    "vignette": "tech",
	    "context_note": "Dijital çağın rekabetçi turnuvaları.",
	    "text": "Aylardır hazırlandığın strateji/e-spor turnuvasında büyük finale yükseldin. Canlı yayında on binlerce kişi ekran başında.",
	    "min_age": 14,
	    "max_age": 22,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Soğukkanlı bir takım oyunuyla kupayı ve para ödülünü kazan",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Şampiyonluk ödülüyle kendi donanımını yeniledin ve büyük ün kazandın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Heyecana yenik düşüp ikinci ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yine de teselli ödülü ve harika bir turnuva deneyimi kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_44_ilk_evden_ayrilis_bavulu",
	    "title": "Tekerlekli Bavul ve Anne Eliyle Konulan Kavanoz",
	    "category": "aile",
	    "vignette": "migration",
	    "context_note": "Baba ocağından ilk kez ayrılışın duygusal eşiği.",
	    "text": "Okul veya iş için başka bir semte/şehre taşınma günü geldi. Annen bavulunun köşesine kışlık salça/reçel kavanozu ve el örgüsü kazak sıkıştırırken gözleri doluyor.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ailene sıkıca sarıl, hayır dualarını al ve kendi ayakların üzerinde durmaya söz ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aile sıcaklığını kalbinde taşıyarak bağımsız hayata güçlü bir adım attın.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Duygusallığı belli etmemek için aceleyle vedalaşıp otobüse/trene bin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yol boyu camdan dışarı bakarken boğazın düğümlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_45_kitap_kulubu_ve_tartisma",
	    "title": "Yasaklı veya Tartışmalı Kitaplar Kulübü",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Eleştirel düşünce ve sansüre karşı entelektüel merak.",
	    "text": "Okulda bir grup öğrenciyle birlikte tarihte tartışma yaratmış felsefi ve edebi eserleri okuyup tartıştığınız bağımsız bir okuma halkası kurdunuz.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Farklı görüşleri bir araya getirip hoşgörülü ve derinlikli bir tartışma kültürü yarat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Analitik ve empatik düşünme kapasiten zirveye ulaştı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 12,
	          "reputation": 10,
	          "sanity": 10,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece popüler özetleri okuyup toplantılara katıl",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Genel kültürün biraz arttı.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_46_firtinali_denizde_kurtarma",
	    "title": "Sahilde Boğulma Tehlikesi Geçiren Çocuk",
	    "category": "kriz",
	    "vignette": "crisis",
	    "context_note": "Cesaret ve ilk yardım bilgisi.",
	    "text": "Yaz günü sahilde yürürken rip akıntısına kapılıp çırpınan bir gencin imdat çığlığını duydun.",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Cankurtaran simidini alıp akıntıya paralel yüzerek genci kıyıya çıkar",
	        "lock_reason": "Sağlık/Kondisyon En Az 60 Olmalı",
	        "req_stats": {
	          "health": 60
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hayat kurtardın! Sahildeki herkes seni alkışlarla karşıladı.",
	        "effects": {
	          "health": 4,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 22,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hayat_kurtardi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hemen cankurtaranı ve sahil güvenliği çağırıp kıyıdan halat uzat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Doğru koordinasyonla gencin kurtulmasını sağladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_47_mezuniyet_balosu_ve_yol_ayrimi",
	    "title": "Gençliğe Veda Gecesi ve Gelecek Yemini",
	    "category": "egitim",
	    "vignette": "trophy",
	    "context_note": "22 yaşında gençlik döneminin kapanıp gerçek yetişkinlik dünyasına adım atılması.",
	    "text": "Yirmi iki yaşına ulaştın. Gençlik yıllarının kahkahaları ve sınav stresleri geride kalırken, önünde kariyer, evlilik, ekonomik krizler ve büyük hayat kararları uzanıyor.",
	    "min_age": 21,
	    "max_age": 22,
	    "weight": 90,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Geleceğe yüksek hedeflerle, dürüstlük ve azimle yürü",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yetişkinlik yıllarına tam motivasyonla adım attın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 6,
	          "reputation": 10,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Her şeye hazırlıklı, gerçekçi ve stratejik bir plan kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ekonomik ve sosyal fırtınalara karşı zırhını kuşandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 10,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_48_sadik_dost_vedasi",
	    "title": "Yağmurdan Kurtardığın Sadık Kedinin Yıllar Sonraki Vedası",
	    "category": "aile",
	    "vignette": "nature",
	    "context_note": "Çocukken sokaktan kurtardığın hayvan dostunun seninle büyüyüp hayatını güzelleştirmesi.",
	    "text": "Çocukluğunda yağmurlu bir günde hırkana sarıp eve getirdiğin o yaralı kedi, yıllar boyunca sınav gecelerinde dizinin dibinde uyudu, ağladığında patisini eline koydu. Bugün huzurla yaşlanarak sana veda ediyor.",
	    "min_age": 13,
	    "max_age": 22,
	    "weight": 5,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "hayvan_dostu"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bahçedeki ağacın altına defnedip onun öğrettiği karşılıksız sevgiyi kalbinde yaşat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gözlerin dolsa da bir canı yıllarca mutlu yaşatmış olmanın derin huzurunu duydun.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 6,
	          "sanity": 14,
	          "karma": 15,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Onun anısına mahalledeki sokak hayvanları için düzenli besleme noktası kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sevgiyi çoğaltarak acını şifaya dönüştürdün.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_49_erken_kodlama_meyvesi",
	    "title": "Çocukluk Kodlarının Meyvesi: Açık Kaynak Ödülü",
	    "category": "kariyer",
	    "vignette": "tech",
	    "context_note": "Çocukken eski bilgisayarda yazdığın kodların yıllar sonra küresel bir projeye dönüşmesi.",
	    "text": "İlkokul yıllarında o gürültülü bilgisayarda temelini attığın algoritma kütüphanesi, üniversite yıllarında geliştirdiğin sürümüyle uluslararası bir teknoloji vakfının dikkatini çekti!",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 5,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "erken_kodlama"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Uluslararası Genç Geliştirici Bursunu ve para ödülünü kabul et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocukluk merakın sana genç yaşta küresel bir kariyer kapısı ve sermaye kazandırdı!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 12,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 3800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yazilim_dehasi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Projeyi büyütüp arkadaşlarınla ilk teknoloji kolektifini kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Liderlik ettiğin ekip sektörde hızla tanındı.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_50_universite_kulup_baskanligi",
	    "title": "Öğrenci Kulübü Seçimleri ve Bütçe Yönetimi",
	    "category": "kariyer",
	    "vignette": "politics",
	    "context_note": "Kampüs içi organizasyon ve liderlik sınavı.",
	    "text": "Okulun en aktif kültür ve kariyer kulübünde başkanlık seçimleri var. Kulüp bütçesini şeffaf yönetme sözüyle aday oldun.",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Büyük bir sektör zirvesi düzenleyip sponsorluk rekoru kır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İş dünyasının dev isimlerini okula getirdin; mezun olmadan iş teklifleri aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 900,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kulüp içi sanatsal atölyelere ağırlık ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Samimi ve üretken bir topluluk ortamı kurdun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_51_gece_vardiyasi_benzinlik",
	    "title": "Gece Vardiyasında Issız İstasyon ve Tuhaf Müşteri",
	    "category": "ekonomi",
	    "vignette": "crime",
	    "context_note": "Gençlikte gece çalışmasının riskleri ve soğukkanlılık.",
	    "text": "Harçlığını çıkarmak için çalıştığın nöbetçi market/istasyonda saat gece 03:30. Yüzünü kapüşonla gizlemiş tekinsiz biri kasaya yaklaşıp elini beline götürüyor!",
	    "min_age": 18,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Panik yapmadan sessiz alarm butonuna bas ve konuşarak adamı oyala",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Polis 2 dakika içinde yetişti; hem canını hem kasayı kurtardın, patron sana ikramiye verdi!",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 14,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 1100,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kasayı bırakıp arka depoya kilitlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Canını kurtardın ama o gecenin gerginliği bir süre uykularını kaçırdı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_52_ilk_evcil_hayvan_sorumlulugu",
	    "title": "Öğrenci Evinde Sahiplenilen Sokak Köpeği",
	    "category": "aile",
	    "vignette": "nature",
	    "context_note": "Gençlikte sorumluluk ve sadakat.",
	    "text": "Kış günü kampüs kapısında titreyen sevimli bir sokak köpeği peşine takılıp apartman kapısına kadar geldi.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Aşılarını yaptırıp sahiplen ve her sabah birlikte koşuya çık",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem sağlığın hem de ruh halin sadık dostunla birlikte çiçek açtı!",
	        "effects": {
	          "health": 10,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Bahçeli evi olan güvenilir bir aileye sahiplendirilmesine aracılık et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Doğru bir yuva bularak iyilik yaptın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_53_amator_astronomi_ve_kamp",
	    "title": "Yaylada Teleskopla Perseid Meteor Yağmuru",
	    "category": "egitim",
	    "vignette": "science",
	    "context_note": "Bilim, doğa ve gençlik romantizmi.",
	    "text": "Ağustos ayında ışık kirliliğinden uzak yüksek bir yaylada kurulan astronomi kampına katıldın. Gökyüzünden saatte onlarca yıldız kayıyor.",
	    "min_age": 15,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Astrofotoğrafçılık tekniğiyle Samanyolu'nu fotoğrafla ve yarışmaya gönder",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Fotoğrafın bilim dergisinde kapak oldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ateş başında dostlarınla gitar dinleyip evrenin sonsuzluğunu konuş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ruhunu dinlendiren unutulmaz bir yaz gecesi oldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_54_kutuphanede_unutulan_defter",
	    "title": "Kütüphane Masasında Bulunan Gizemli Not Defteri",
	    "category": "ask",
	    "vignette": "academy",
	    "context_note": "Entelektüel merakla başlayan sıra dışı bir tanışma.",
	    "text": "Kütüphanede her gün oturduğun masada, kenarlarına harika felsefi notlar ve çizimler düşülmüş isimsiz bir defter buldun.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sayfanın altına kendi cevabını yazıp masaya bırak ve sahibini bekle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ertesi gün defterin sahibiyle tanıştın; zihinlerinizin uyumu muhteşem bir dostluğa/aşka dönüştü!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Defteri kütüphane danışmasına teslim et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dürüstçe sahibine ulaşmasını sağladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_55_ilk_maraton_ve_irade",
	    "title": "Şehir Yarı Maratonunda 21 Kilometre Sınavı",
	    "category": "saglik",
	    "vignette": "sports",
	    "context_note": "Fiziksel ve zihinsel dayanıklılık.",
	    "text": "Aylardır sabah erken kalkıp hazırlandığın 21 kilometrelik şehir yarı maratonunda 16. kilometrede 'duvara çarptın'; bacakların kurşun gibi ağırlaştı.",
	    "min_age": 17,
	    "max_age": 22,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Zihnini odakla, adımlarını ritme sok ve bitiş çizgisini geç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Madalyayı boynuna taktığında hayatta hiçbir zorluğun seni kolayca yıkamayacağını anladın!",
	        "effects": {
	          "health": 14,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yürüyerek de olsa parkuru tamamla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Pes etmedin ve yarışı bitirdin.",
	        "effects": {
	          "health": 8,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "yth_56_yurtdisi_online_freelance",
	    "title": "Küresel Platformda İlk Dövizli Freelance İş",
	    "category": "ekonomi",
	    "vignette": "tech",
	    "context_note": "Dijital ekonomide sınır ötesi emek ihracatı.",
	    "text": "İnternet üzerinden yabancı bir müşterinin tasarım/yazılım/çeviri projesine teklif verdin ve işi aldın!",
	    "min_age": 16,
	    "max_age": 22,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Projeyi teslim tarihinden önce kusursuz teslim edip 5 yıldızlı referans al",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 56
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İlk döviz gelirin hesabına yattı; küresel serbest çalışma (Freelance) kapısını açtın!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 8,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "freelancer"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İşi aceleye getirip revizyonlarda müşteriyi bunalt",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ücretin yarısını alabildin ama piyasa dersini öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  }
	]
