extends RefCounted

# 23-59 Yaş Arası Detaylı Yetişkinlik Olayları (72 Olay)
static func get_events() -> Array:
	return [
	  {
	    "id": "adt_01_ilk_maas_zarfi",
	    "title": "İlk Gerçek Maaş ve Hayatın Faturası",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Yetişkin dünyasında kazanılan ilk tam maaşın kullanım kararı.",
	    "text": "Ay sonu geldi ve hayatının ilk tam zamanlı maaşı hesabına yattı. Kira, faturalar ve aileye küçük bir hediye çıktıktan sonra kalan parayla nasıl bir alışkanlık başlatacaksın?",
	    "min_age": 23,
	    "max_age": 28,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her ay maaşın %20'sini dokunulmaz yatırım ve acil durum fonuna ayır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Erken yaşta kurduğun finansal disiplin seni gelecekteki krizlere karşı zırhlandırdı!",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "finansal_disiplin"
	        ],
	        "remove_tags": [],
	        "add_trait": "Tedbirli",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ailene mükellef bir akşam yemeği ısmarlayıp hayır dualarını al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sofradaki gurur dolu bakışlar paranın satın alamayacağı bir mutluluk verdi.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": -300,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kredi kartı limitini sonuna kadar kullanıp lüks alışverişe çık",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kısa süreli bir haz yaşadın ama gelecek ayın ekstresi şimdiden gözünü korkutuyor.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": -1400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_02_is_yerinde_mobbing",
	    "title": "Üst Yöneticinin Sistemli Baskısı (Mobbing)",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "İş hayatında emeğin gasp edilmesi ve psikolojik yıldırma.",
	    "text": "Yeni atanan departman müdürü, senin hazırladığın başarılı raporları kendi eseriymiş gibi üst yönetime sunuyor ve toplantılarda seni küçük düşürmeye çalışıyor.",
	    "min_age": 24,
	    "max_age": 48,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tüm e-posta ve sürüm kayıtlarını belgeleyip doğrudan Yönetim Kurulu'na kanıtlarıyla sun",
	        "lock_reason": "Kanıt Analizi İçin Zeka 64+ Gerekli",
	        "req_stats": {
	          "smart": 64
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Belgeler karşısında müdür görevden alındı ve yerine sen vekalet etmeye başladın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 22,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 3200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kurumsal_zafer"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İstifa edip rakip firmaya veya kendi işine geç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Toksik ortamdan kurtulup kendi değerini bilen bir yere geçtin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İşsiz kalma korkusuyla sineye çek ve sus",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Maaşın devam etti ama mide ağrıları ve uykusuzluk başladı.",
	        "effects": {
	          "health": -10,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -15,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_03_sirket_yolsuzlugu_ihbar",
	    "title": "Gizli Klasördeki Çifte Muhasebe: İhbar mı, Sus Payı mı?",
	    "category": "kriz",
	    "vignette": "secret",
	    "context_note": "Kurumsal yolsuzluk karşısında vicdan (Whistleblowing) ile karanlık servet ikilemi.",
	    "text": "Gece mesaisinde şirketin vergi kaçırdığını ve halk sağlığını tehdit eden atıkları gizlice nehre/toprağa bıraktığını kanıtlayan imzalı belgeler buldun. Patron durumu fark edip odasına çağırdı ve önüne kalın bir zarf sürdü.",
	    "min_age": 25,
	    "max_age": 55,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Zarfı reddet; belgelerin kopyasını savcılığa ve bağımsız basına teslim et (Whistleblower)",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ülke gündemi sarsıldı! İşini kaybettin ama halk kahramanı ilan edildin ve dürüst kuruluşlardan üst düzey teklif aldın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 28,
	          "sanity": 10,
	          "karma": 26,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "durust_ihbarci"
	        ],
	        "remove_tags": [],
	        "add_trait": "Cesur",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sus payını al ve hiçbir şey görmemiş gibi davran",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Banka hesabına servet yattı! Ancak yıllar sonra patlayacak çevre skandalında senin de imzan araştırılacak.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": -25,
	          "money_flat": 12000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kirli_para"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {
	          "delay_years": 5,
	          "event_id": "sn_36_gecmisin_karanlik_dosyasi",
	          "origin_note": "Gençliğinde aldığın sus payı ve gizlenen çevre yolsuzluğunun yıllar sonraki soruşturması"
	        }
	      }
	    ]
	  },
	  {
	    "id": "adt_04_evlilik_ve_dugun_krizi",
	    "title": "Düğün Salonu mu, Sade Nikah ve Dünya Turu mu?",
	    "category": "ask",
	    "vignette": "love",
	    "context_note": "Evlilik arifesinde aile gelenekleri ile çiftin kendi hayalleri arasındaki bütçe savaşı.",
	    "text": "Hayatını birleştireceğin insanla nikah günü yaklaşıyor. Akrabalar 500 kişilik gösterişli bir düğün beklerken, müstakbel eşin 'O parayla borca girmeyelim, sade bir nikah yapıp geleceğimize yatıralım' diyor.",
	    "min_age": 23,
	    "max_age": 42,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sade ve zarif bir nikah kıyıp kalan birikimi ev peşinatı ve balayına ayır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Akrabalar biraz homurdansa da borçsuz ve huzurlu bir yuva kurdunuz!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "evli"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Herkesin diline düşmemek için kredi çekip 500 kişilik lüks düğün yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Düğün gecesi muhteşemdi ama ertesi sabah önünüzde 36 aylık kredi taksiti duruyordu.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": -4500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "evli",
	          "dugun_borcu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_05_kendi_girisimini_kurmak",
	    "title": "İstifa Dilekçesi ve Kendi Dükkanın/Şirketin Kepengi",
	    "category": "kariyer",
	    "vignette": "finance",
	    "context_note": "Maaşlı güvenceden çıkıp kendi işinin patronu olma cesareti.",
	    "text": "Yıllardır başkalarının hayalleri için çalışmaktan yoruldun. Elindeki birikimle kendi atölyeni, kafenin ya da danışmanlık/teknoloji girişimini kurma fırsatı doğdu.",
	    "min_age": 25,
	    "max_age": 52,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Pazar araştırmasını yapıp birikiminle kendi işini kur",
	        "lock_reason": "Sermaye ve Zeka 60+ Gerekli",
	        "req_stats": {
	          "smart": 60
	        },
	        "req_money": 2000,
	        "req_tags": [],
	        "outcome_text": "İlk altı ay gece gündüz ter döktün ama işin tuttu; artık kendi kararlarının efendisisin!",
	        "effects": {
	          "health": -4,
	          "happiness": 20,
	          "smart": 10,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 6500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kendi_isinin_patronu"
	        ],
	        "remove_tags": [],
	        "add_trait": "Girişimci",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Güvenli maaşını bırakmayıp hafta sonları yan gelir projesi olarak başlat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Düşük riskle ek bir gelir kapısı oluşturdun.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_06_ortak_ihaneti_ve_imza",
	    "title": "Ticari Ortağın Gece Yarısı Boşalttığı Kasa",
	    "category": "kriz",
	    "vignette": "court",
	    "context_note": "İş ortaklıklarında güven ve hukuki sözleşme boşluğu.",
	    "text": "Birlikte yola çıktığın iş ortağın, senin dalgınlığından faydalanıp şirket hesabındaki nakdi kendi paravan şirketine aktararak sırra kadem bastı!",
	    "min_age": 26,
	    "max_age": 56,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İyi bir ticaret avukatı tutup mal varlığına ihtiyati tedbir koydur",
	        "lock_reason": "Avukat Masrafı ve Zeka 62+ Gerekli",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 1000,
	        "req_tags": [],
	        "outcome_text": "Hukuki zekan ve hızlı hamlen sayesinde paranın büyük kısmını kurtardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 8,
	          "reputation": 12,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sözleşmedeki boşluk yüzünden zararı sineye çekip sıfırdan başla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Büyük bir maddi darbe aldın ama insanlara körü körüne güvenmemeyi öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": -18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": -4200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_07_ilk_cocuk_dogumu_gecesi",
	    "title": "Doğumhane Kapısında Bekleyiş ve İlk Ağlama Sesi",
	    "category": "aile",
	    "vignette": "birth",
	    "context_note": "Ebeveyn olmanın getirdiği tarif edilmez dönüşüm.",
	    "text": "Hastane koridorunda saatlerdir bir aşağı bir yukarı yürüyorsun. İçeriden yükselen o ilk bebek ağlamasıyla birlikte hayatının merkezi sonsuza dek değişti.",
	    "min_age": 23,
	    "max_age": 48,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bebeğini kucağına al, iş saatlerini dengeleyip ilgili bir ebeveyn olmaya söz ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocuğunun her adımına tanık oldun; evin neşeyle doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 14,
	          "money_flat": -800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ebeveyn",
	          "ilgili_ebeveyn"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çocuğuna iyi bir gelecek sunmak için gece gündüz fazla mesaiye gömül",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Maddi olarak her şeyi sağladın ama ilk kelimelerini kaçırdın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 2800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ebeveyn"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_08_ev_sahibi_tahliye_kavgasi",
	    "title": "Ev Sahibinden 'Oğlum Almanya'dan Gelecek' İhtarnamesi",
	    "category": "ekonomi",
	    "vignette": "home",
	    "context_note": "Konut krizinde kiracı-ev sahibi çatışması.",
	    "text": "Oturduğun evin sahibi, piyasadaki kiralar ikiye katlanınca kapıya dayanıp 'Oğlum/kızım evlenecek, ya kirayı üç katına çıkar ya da ay sonunda evi boşalt!' dedi.",
	    "min_age": 23,
	    "max_age": 58,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [
	        "ev_sahibi"
	      ],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kira hukukunu devreye sok; yasal sınırın üzerinde artış yapamayacağını ihtar et",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yasalar yanındaydı; ev sahibi geri adım atmak zorunda kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Birikimini ve banka kredisini birleştirip kendi mütevazı evinin tapusunu al",
	        "lock_reason": "Peşinat İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 5500,
	        "req_tags": [],
	        "outcome_text": "Kira stresinden ömür boyu kurtuldun; kendi çatının altındasın!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": -5500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ev_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tartışmaktan bıkıp daha uzak ve ucuz bir mahalleye taşın",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Taşınma masrafı ve yol yorgunluğu canını sıktı.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_09_yasak_ask_ve_sadakat_sinavi",
	    "title": "İş Seyahatinde Tehlikeli Yakınlaşma: Sadakat Sınavı",
	    "category": "ask",
	    "vignette": "heartbreak",
	    "context_note": "Uzun süreli ilişkilerde veya evlilikte sadakat ile tutku arasındaki uçurum.",
	    "text": "Şehir dışındaki bir konferansta tanıştığın etkileyici biri, akşam yemeğinden sonra seni odasına davet ediyor. Evdeki ilişkin ise son dönemde oldukça monoton.",
	    "min_age": 25,
	    "max_age": 55,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "evli"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Daveti kibarca reddet, odana çekil ve eşini arayıp özlediğini söyle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Anlık bir heyecana kapılmayıp yuvanı ve özsaygını korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sadik_es"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gizli bir ilişkiye başla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Heyecan dolu birkaç ay geçti ama telefonundaki mesajlar yakalanınca evliliğin temelinden sarsıldı!",
	        "effects": {
	          "health": 0,
	          "happiness": -20,
	          "smart": 0,
	          "reputation": -18,
	          "sanity": -18,
	          "karma": -20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sadakatsizlik_krizi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {
	          "delay_years": 2,
	          "event_id": "adt_10_bosanma_ve_velayet_mahkemesi",
	          "origin_note": "İş seyahatinde başlayan gizli ilişkinin ortaya çıkması sonucu"
	        }
	      }
	    ]
	  },
	  {
	    "id": "adt_10_bosanma_ve_velayet_mahkemesi",
	    "title": "Aile Mahkemesi Koridoru: Boşanma ve Mal Paylaşımı",
	    "category": "kriz",
	    "vignette": "court",
	    "context_note": "Yıpranan bir evliliğin hukuki ve duygusal vedası.",
	    "text": "Yılların biriktirdiği kırgınlıklar sonunda Aile Mahkemesi kapısına dayandı. Avukatlar mal paylaşımı ve tazminat dosyalarını masaya koyuyor.",
	    "min_age": 26,
	    "max_age": 58,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "evli"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Çekişmeli kavgaya girmeden adil ve medeni bir protokolle anlaşmalı boşan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yıpranmadan, karşılıklı saygıyı koruyarak yeni bir hayata adım attın.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 10,
	          "money_flat": -1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bosanmis"
	        ],
	        "remove_tags": [
	          "evli"
	        ],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Her kuruş için sert bir hukuk savaşı başlat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Mahkeme yıllarca sürdü; malın yarısını kurtardın ama sinirlerin harap oldu.",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": -10,
	          "sanity": -16,
	          "karma": 0,
	          "money_flat": -800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bosanmis"
	        ],
	        "remove_tags": [
	          "evli"
	        ],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_11_borsa_cokusu_kara_pazartesi",
	    "title": "Kara Pazartesi: Piyasalarda %40 Çöküş!",
	    "category": "ekonomi",
	    "vignette": "crisis",
	    "context_note": "Küresel finansal krizlerde soğukkanlılık testi.",
	    "text": "Küresel bir bankacılık ve jeopolitik kriz patlak verdi! Ekranlar kıpkırmızı, herkes panikle elindeki hisseleri ve fonları zararına satıyor.",
	    "min_age": 24,
	    "max_age": 59,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Panik satışı yapma; nakit rezervinle dipten sağlam sanayi ve teknoloji hisseleri topla",
	        "lock_reason": "Nakit Rezerv ve Zeka 65+ Gerekli",
	        "req_stats": {
	          "smart": 65
	        },
	        "req_money": 2500,
	        "req_tags": [],
	        "outcome_text": "Kriz geçtiğinde dipten aldığın varlıklar servetini ikiye katladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 10,
	          "reputation": 14,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 7500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kriz_yatirimcisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Korkuya kapılıp tüm yatırımlarını en dipten zararına sat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Büyük bir maddi kayıp yaşadın; piyasalar iki yıl sonra toparlandığında sadece izledin.",
	        "effects": {
	          "health": 0,
	          "happiness": -16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": 0,
	          "money_flat": -3800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_12_orta_yas_bunalimi",
	    "title": "Kırklı Yaşların Eşiğinde: 'Hayatım Bu mu?' Sorgusu",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "Orta yaşta kaçırılan fırsatlar ve anlam arayışı.",
	    "text": "Sabah işe giderken trafikte/metroda camdaki yansımana baktın. Saçlarına düşen ilk aklar ve her gün tekrarlanan mesai döngüsü ruhunu daraltıyor.",
	    "min_age": 36,
	    "max_age": 52,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yarım bıraktığın sanatsal/akademik tutkuna geri dön ve yeni bir dil/zanaat öğren",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ruhun yeniden gençleşti; orta yaşı hayatının en verimli dönemine çevirdin!",
	        "effects": {
	          "health": 8,
	          "happiness": 18,
	          "smart": 10,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ikinci_bahar"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Düşüncesizce tüm birikimini lüks ve gereksiz harcamalara yatır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kısa süreli bir heyecan yaşadın ama boşluk hissi geçmedi.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": -4500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_13_yaslanan_anne_baba_bakimi",
	    "title": "Yaşlanan Anne-Babanın Bakım İkilemi",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Evlatlık vefası ile modern hayatın koşturmacası arasındaki zor karar.",
	    "text": "Hayatta kalan yaşlı ebeveyninin sağlık durumu artık tek başına yaşamasına elvermiyor. Bakımevi seçeneği ile kendi evinde bakım arasında karar vermelisin.",
	    "min_age": 34,
	    "max_age": 58,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Evinde bir oda hazırla ve yardımcı hemşire desteğiyle başucunda ilgilen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zor ve yorucu olsa da dualarını aldın; çocuklarına da vefanın ne olduğunu öğrettin.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 6,
	          "karma": 24,
	          "money_flat": -1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "vefali_evlat"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tam donanımlı profesyonel bir yaşlı bakım merkezine yerleştir ve her hafta ziyaret et",
	        "lock_reason": "Bakım Merkezi Ücreti Gerekli",
	        "req_stats": {},
	        "req_money": 2600,
	        "req_tags": [],
	        "outcome_text": "Tıbbi bakımı kusursuz yapıldı ama ilk haftalarda vicdanın biraz sızladı.",
	        "effects": {
	          "health": 0,
	          "happiness": 2,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 4,
	          "money_flat": -2600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sorumluluğu diğer akrabalara yıkıp ilgilenme",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Paran cebinde kaldı ama aile içinde adın vefasıza çıktı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": -18,
	          "sanity": -8,
	          "karma": -22,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_14_cocugun_okulda_kavgasi_veya_basarisi",
	    "title": "Okul Müdüründen Gelen Acil Telefon",
	    "category": "aile",
	    "vignette": "academy",
	    "context_note": "Ebeveynlikte disiplin ve rehberlik.",
	    "text": "İşin en yoğun saatinde okul müdürü aradı: Çocuğun ya büyük bir disiplin olayına karıştı ya da sıra dışı bir proje için özel yönlendirme bekliyor.",
	    "min_age": 28,
	    "max_age": 55,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "ebeveyn"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İşini bırakıp okula git; çocuğunu dinleyerek adil ve yapıcı bir rehberlik sun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocuğun senin desteğinle doğru yolu buldu ve okulda parlamaya başladı.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Telefonda bağırıp çağırarak sert cezalar ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocuğun korkudan sustu ama aranızdaki iletişim duvarı yükseldi.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_15_kronik_bel_ve_kalp_uyarisi",
	    "title": "Doktorun Masasındaki Tahlil Sonuçları: İlk Ciddi Uyarı",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Hareketsiz yaşam, stres ve sağlıksız beslenmenin bedeli.",
	    "text": "Yıllardır süren masa başı stres ve düzensiz uyku sonunda tahlillerde yüksek kolesterol, tansiyon ve disk fıtığı başlangıcı olarak karşısına çıktı.",
	    "min_age": 32,
	    "max_age": 58,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sigarayı/şekeri tamamen kes, Akdeniz tipi beslenmeye ve sabah yürüyüşlerine başla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Altı ay içinde değerlerin normale döndü; 10 yaş gençleşmiş hissediyorsun!",
	        "effects": {
	          "health": 20,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "saglikli_yasam"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Doktorun uyarılarını kulak arkası edip eski düzene devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hastalık kronikleşti ve enerjin kalıcı olarak düştü.",
	        "effects": {
	          "health": -18,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kronik_rahatsizlik"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_16_uluslararasi_konferans_daveti",
	    "title": "Yurtdışı Zirvesinde Kürsü Konuşması",
	    "category": "kariyer",
	    "vignette": "migration",
	    "context_note": "Mesleki uzmanlığın uluslararası alanda tanınması.",
	    "text": "Alanında yaptığın çalışmalar nedeniyle Cenevre/Viyana'da düzenlenen uluslararası sektör zirvesine ana konuşmacı olarak davet edildin.",
	    "min_age": 28,
	    "max_age": 58,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 62
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Titizlikle hazırlanıp İngilizce/küresel sunumunla salonu etkile",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Uluslararası danışmanlık teklifleri ve döviz bazlı projeler akmaya başladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kuresel_uzman"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Heyecanlanıp sunumu kısa tut ama kokteylde iyi bağlantılar kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yeni iş ortaklıkları geliştirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_17_vergi_affi_veya_denetimi",
	    "title": "Maliye Müfettişinin Hesap İncelemesi",
	    "category": "ekonomi",
	    "vignette": "court",
	    "context_note": "Gelir ve varlıkların vergisel denetimi.",
	    "text": "Maliye bakanlığı son 5 yıllık banka hareketlerini ve beyannamelerini incelemeye aldı.",
	    "min_age": 26,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Şeffaf muhasebe kayıtlarını sunup eksiksiz ibra al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kayıtlarının temizliği müfettişten tam not aldı; itibarın güçlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eksik beyanlar nedeniyle gecikme cezası ödeyerek uzlaşmaya git",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Cebin biraz yandı ama mahkeme sürecinden kurtuldun.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": -2400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_18_kitap_yazma_ve_yayinevi",
	    "title": "Çekmecedeki Taslak: İlk Kitabını Yayımlamak",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Mesleki veya edebi birikimi kalıcı bir esere dönüştürme.",
	    "text": "Yıllardır geceleri not aldığın roman veya mesleki inceleme dosyan nihayet tamamlandı. Saygın bir yayınevi editörü dosyayı basmak istiyor.",
	    "min_age": 27,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 58
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Editörle çalışıp kitabı yayımla ve imza günlerine çık",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kitabın vitrinlerde yerini aldı! Telif geliri ve entelektüel saygınlık kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 8,
	          "reputation": 22,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 3200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yazar_unvani"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Dijital ortamda bağımsız (Self-publish) olarak tüm dünyaya aç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aracı olmadan doğrudan okurlara ulaştın.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_19_mahalle_kentsel_donusum",
	    "title": "Apartmanda Kentsel Dönüşüm ve Müteahhit Pazarlığı",
	    "category": "ekonomi",
	    "vignette": "home",
	    "context_note": "Mülk sahipleri ve müteahhitler arasındaki metrekare mücadelesi.",
	    "text": "Yaşadığın bina/mahalle kentsel dönüşüm kapsamına alındı. Müteahhit firma daire sahiplerine sözleşme uzatıyor ama maddelerde bazı belirsizlikler var.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Apartman yönetimini topla, banka teminat mektubu şartı koydurup sözleşmeyi sağlama al",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 60
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İnşaat zamanında bitti ve dairenin değeri iki katına çıktı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 8,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 5200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sözleşmeyi okumadan imzala",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Müteahhit inşaatı yarım bırakıp konkordato ilan etti; aylarca kira mağduru oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": -18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": -2800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_20_trafik_kazasi_ve_sigorta",
	    "title": "Yağmurlu Kavşakta Zincirleme Kaza",
	    "category": "kriz",
	    "vignette": "crisis",
	    "context_note": "Şehir trafiğinde anlık tehlike ve hukuki/tıbbi süreç.",
	    "text": "Akşam iş çıkışında kırmızı ışıkta beklerken arkadan hızla gelen bir araç fren tutturamayıp sana çarptı.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Emniyet kemerin sayesinde hafif sıyrıkla kurtul, tutanak tutup sigorta tazminatını al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kemer hayat kurtardı; aracının değer kaybını da yasal yoldan tahsil ettin.",
	        "effects": {
	          "health": -3,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Boyunlukla hastaneye kaldırıl ve karşı tarafla karakolluk ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yorucu ve ağrılı bir hafta geçirdin.",
	        "effects": {
	          "health": -14,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_21_eski_dostun_cenazesi_ve_hatirlatma",
	    "title": "Gençlik Arkadaşının Erken Vedası",
	    "category": "felsefe",
	    "vignette": "death",
	    "context_note": "Yaşıt birinin kaybıyla hayatın kısalığını idrak etme.",
	    "text": "Okul yıllarından tanıdığın neşeli bir arkadaşının ani bir kalp kriziyle vefat ettiği haberini aldın. Cenazede eski dostlarla bir araya geldiniz.",
	    "min_age": 30,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ertelediğin hayallerini ve sevdiklerinle vakit geçirmeyi öne al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hayatın yarınlara ertelenemeyecek kadar kıymetli olduğunu anladın; kırgınlıkları bitirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Derin bir ölüm kaygısına kapılıp içine kapan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir süre karanlık düşüncelerle boğuştun.",
	        "effects": {
	          "health": 0,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_22_sirket_devralma_veya_isten_cikarma",
	    "title": "Küresel Küçülme Dalgası ve Tazminat Paketi",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "Kurumsal dünyada yapay zeka ve ekonomik daralma kaynaklı işten çıkarmalar.",
	    "text": "Çalıştığın sektörde büyük bir küçülme dalgası başladı. İnsan Kaynakları gönüllü ayrılanlara 12 maaş kıdem ve ihbar tazminatı verileceğini duyurdu.",
	    "min_age": 26,
	    "max_age": 58,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gönüllü tazminat paketini alıp yüksek maaşla başka bir kuruma/danışmanlığa geç",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem toplu tazminatı cebine koydun hem de kariyerinde sıçrama yaptın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 6000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Şirkette kalıp yeniden yapılanan departmanın sorumluluğunu üstlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İş yükün arttı ama şirketteki yerin vazgeçilmez oldu.",
	        "effects": {
	          "health": -4,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_23_miras_kavgasi_akrabalar",
	    "title": "Taşradaki Dededen Kalan Tarla ve Akraba Davası",
	    "category": "aile",
	    "vignette": "court",
	    "context_note": "Miras paylaşımında ortaya çıkan aile içi anlaşmazlıklar.",
	    "text": "Memleketteki eski aile arazisinin yanından yeni otoyol geçince arsanın değeri on katına çıktı. Yıllardır aramayan kuzenler izale-i şüyu (ortaklığın giderilmesi) davası açtı.",
	    "min_age": 25,
	    "max_age": 59,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hisseleri adil ekspertiz değeriyle uzlaştırıp satışı gerçekleştir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Mahkeme harçlarına para kaptırmadan hakkın olan mirası nakit olarak aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 10,
	          "money_flat": 4800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İnatlaşıp yıllarca sürecek mahkeme savaşına gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Avukat masrafları ve aile kavgaları seni yıprattı.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": 0,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_24_hayir_kurumu_veya_burs_fonu",
	    "title": "Mahallendeki Okula Laboratuvar / Kütüphane Kurmak",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Başarıya ulaştıktan sonra doğduğun topraklara vefa borcu.",
	    "text": "Çocukken okuduğun okulun müdürü, kütüphane ve bilgisayar sınıfının yenilenmesi için eski mezunlardan destek bekliyor.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Masrafları üstlenip kendi adını/ailenin adını taşıyan modern bir laboratuvar kur",
	        "lock_reason": "Bağış İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 2500,
	        "req_tags": [],
	        "outcome_text": "Açılış töreninde öğrencilerin gözlerindeki ışıltı sana ömürlük bir onur yaşattı!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 0,
	          "reputation": 26,
	          "sanity": 14,
	          "karma": 28,
	          "money_flat": -2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hayirsever_mezun"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gönüllü kariyer günü konuşmacısı olarak gidip gençlere mentorluk yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gençlere ilham verdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_25_yabanci_dil_ve_yuksek_lisans",
	    "title": "Gece Eğitiminde MBA / Yüksek Lisans",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Çalışırken akademik dereceyi yükseltme mücadelesi.",
	    "text": "Gündüz mesai yapıp akşamları yönetici yüksek lisans (MBA / Master) programına katılma şansı yakaladın.",
	    "min_age": 24,
	    "max_age": 45,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İki yıl uykundan feragat edip yüksek lisans diplomasını al",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 60
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Üst düzey yöneticilik (C-Level) kapılarını açan diplomayı ve güçlü bir iş ağını kazandın!",
	        "effects": {
	          "health": -4,
	          "happiness": 12,
	          "smart": 14,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yuksek_lisans"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İş-yaşam dengesini bozmamak için sertifika programlarıyla yetin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kendini yormadan güncel kaldın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_26_restoran_veya_kafe_yatirimi",
	    "title": "Arkadaşla Ortak Butik Kafe/Restoran Açma Hayali",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Beyaz yakalıların en büyük hayali ve en sık batan girişim türü.",
	    "text": "İşten sıkılan bir arkadaşın 'Harika bir köşe dükkan buldum, gel ortak butik kahveci/restoran açalım' diyerek kapını çaldı.",
	    "min_age": 25,
	    "max_age": 55,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Lokasyon ve maliyet analizini bizzat denetleyip kontrollü ortak ol",
	        "lock_reason": "Sermaye ve Analiz İçin Zeka 62+ Gerekli",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 1800,
	        "req_tags": [],
	        "outcome_text": "Özgün konseptiniz mahallede tuttu; hafta sonları dolup taşan kârlı bir mekanınız oldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "mekan_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hesap kitap yapmadan tüm birikimini dekorasyona göm",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Altı ay sonra yüksek kira ve tedarik maliyetleri yüzünden zararına devretmek zorunda kaldınız!",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": -3200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_27_politik_adaylik_teklifi",
	    "title": "Belediye Meclisi veya Milletvekilliği Adaylık Teklifi",
	    "category": "kariyer",
	    "vignette": "politics",
	    "context_note": "Sivil toplumdan aktif siyasete geçiş.",
	    "text": "Mesleğindeki başarın ve çevrendeki saygınlığın siyasi partilerin dikkatini çekti. Yaklaşan seçimlerde aday listesinde yer alman teklif ediliyor.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "reputation": 55
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bağımsız ilkelerini koruyarak aday ol ve şeffaf bir kampanya yürüt",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Seçmen samimiyetine güvendi; meclise girerek kentin/ülkenin kararlarında söz sahibi oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 26,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 3500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "siyasetci"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Aktif siyasetin kirli kavgalarından uzak durup sivil danışman kal",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Saygınlığını ve huzurunu korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_28_siber_dolandiricilik_oltalama",
	    "title": "Sahte Banka/Savcılık Araması: Dijital Tuzak",
	    "category": "kriz",
	    "vignette": "crime",
	    "context_note": "Yetişkinleri hedef alan sofistike oltalama (Phishing) ve ses taklidi dolandırıcılığı.",
	    "text": "Telefonun çaldı; kendisini banka güvenlik uzmanı/savcı olarak tanıtan biri, hesabının terör/suç örgütü tarafından ele geçirildiğini söyleyip doğrulama kodunu istiyor!",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Telefonu derhal yüzüne kapat ve bankanın resmi numarasını kendin arayarak ihbar et",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 50
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Soğukkanlılığın sayesinde tüm birikimini saniyeler içinde çaldırmaktan kurtuldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Panikleyip ekrana gelen onay kodunu söyle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hesabındaki nakdin önemli bir kısmı saniyeler içinde yabancı hesaplara aktarıldı!",
	        "effects": {
	          "health": 0,
	          "happiness": -22,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -18,
	          "karma": 0,
	          "money_flat": -3800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_29_dogaya_kacis_ve_hobi_bahcesi",
	    "title": "Şehir Gürültüsünden Kaçış: Hafta Sonu Toprakla Uğraşmak",
	    "category": "saglik",
	    "vignette": "nature",
	    "context_note": "Modern metropol stresine karşı topraklanma.",
	    "text": "Beton binalar ve ekran ışığı gözlerini yormaya başladı. Şehir çeperinde küçük bir hobi bahçesi kiralama veya balkon serası kurma fikri doğdu.",
	    "min_age": 26,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi domatesini, biberini ve lavantanı yetiştir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Toprağa dokunmak stres hormonlarını sıfırladı; sağlığın ve uykun düzene girdi.",
	        "effects": {
	          "health": 12,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Şehir kulüplerinde sosyal etkinliklere katılmayı tercih et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sosyal çevreni canlı tuttun.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_30_uluslararasi_patent_ve_inovasyon",
	    "title": "Geliştirdiğin Yönteme Küresel Lisans Teklifi",
	    "category": "kariyer",
	    "vignette": "science",
	    "context_note": "Mesleki uzmanlığın fikri mülkiyete dönüşmesi.",
	    "text": "İşinde yıllardır geliştirdiğin özgün teknik/tasarım modeli, uluslararası bir konsorsiyum tarafından lisanslanmak isteniyor.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 66
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Mülkiyet hakkını koruyarak yıllık telif (Royalty) sözleşmesi imzala",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Her yıl düzenli döviz geliri getiren kalıcı bir eserin sahibi oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 8,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 7000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "patent_geliri"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tek seferlik yüksek peşin bedelle tüm hakları devret",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Anında yüklü bir nakit sermaye elde ettin.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 5200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_31_evlilik_yildonumu_ve_yenilenme",
	    "title": "Evlilikte Yorgun Yıllar ve İkinci Balayı",
	    "category": "ask",
	    "vignette": "love",
	    "context_note": "Evlilikte rutini kırmak ve bağı tazelemek.",
	    "text": "İş, faturalar ve hayat telaşı yüzünden eşinle/partnerinle aynı evin içinde iki yabancı gibi konuşmaya başladığınızı fark ettin.",
	    "min_age": 28,
	    "max_age": 58,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "evli"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Telefonları kapatıp baş başa sakin bir kıyı kasabasına kaçamak düzenle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yıllar önceki ilk heyecanınızı yeniden hatırladınız; ilişkiniz tazelendi!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 8,
	          "money_flat": -600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sorunları halının altına süpürüp işe gömülmeye devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aranızdaki duygusal mesafe biraz daha açıldı.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_32_afet_gonullulugu_ve_yardim",
	    "title": "Deprem/Sel Bölgesinde Arama ve Yardım Seferberliği",
	    "category": "felsefe",
	    "vignette": "crisis",
	    "context_note": "Toplumsal felaket anında dayanışma.",
	    "text": "Komşu şehirde meydana gelen doğal afet sonrası yardım konvoyları ve gönüllü ekipler oluşturuluyor.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bizzat sahaya git veya lojistik koordinasyon merkezinde gece gündüz çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zor durumdaki onlarca ailenin yarasına merhem oldun; insanlığın onurunu yaşadın.",
	        "effects": {
	          "health": -4,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 8,
	          "karma": 26,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "toplum_gonullusu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Maddi yardımda bulunup erzak kolisi gönder",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gücün nispetinde destek oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": -500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_33_cocuk_universite_mezuniyeti",
	    "title": "Çocuğunun Kep Atma Töreni",
	    "category": "aile",
	    "vignette": "trophy",
	    "context_note": "Ebeveynliğin en gururlu anlarından biri.",
	    "text": "Yıllar su gibi aktı; uykusuz gecelerde büyüttüğün çocuğun bugün cübbesini giymiş sahnede mezuniyet diplomasını alıyor!",
	    "min_age": 42,
	    "max_age": 59,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "ebeveyn"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tribünde gözyaşları içinde alkışla ve ona ilk iş/hayat tavsiyeni ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir evlat yetiştirmenin eşsiz gururu tüm yorgunluğunu sildi.",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Mezuniyet hediyesi olarak ona küçük bir başlangıç fonu/araba hediye et",
	        "lock_reason": "Hediye İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 2500,
	        "req_tags": [],
	        "outcome_text": "Çocuğunun hayata güçlü başlamasını sağladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 26,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": -2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_34_karanlik_vergi_cenneti_teklifi",
	    "title": "Off-Shore Hesap ve Vergi Kaçırma Teklifi",
	    "category": "ekonomi",
	    "vignette": "secret",
	    "context_note": "Yüksek gelir diliminde dürüst vergi mükellefliği ile yasadışı fon aktarımı ikilemi.",
	    "text": "Mali bir danışman, gelirlerini denizaşırı bir ada ülkesindeki paravan şirket üzerinden göstererek vergiyi sıfırlayabileceğini fısıldıyor.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [
	        "high",
	        "elite"
	      ],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Teklifi reddet; kazandığın ülkenin yasalarına uygun, temiz vergi öde",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İncelemelerden alnın akıyla çıktın, itibarın sarsılmaz kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 10,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parayı gizli off-shore hesaplara aktar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Vergiden kaçtın ama uluslararası veri sızıntısında (Panama/Pandora benzeri) adın listeye girdi!",
	        "effects": {
	          "health": 0,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": -24,
	          "sanity": -14,
	          "karma": -20,
	          "money_flat": 6000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "vergi_skandali"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_35_sanat_koleksiyonu_ve_muzayede",
	    "title": "Müzayedede Keşfedilen İmzalı Tablo",
	    "category": "ekonomi",
	    "vignette": "art",
	    "context_note": "Kültürel sermaye ve sanat yatırımı.",
	    "text": "Eski bir eşya müzayedesinde, tozlu çerçevesinin arkasında usta bir ressamın eskizi olduğunu fark ettiğin bir tablo satışa çıktı.",
	    "min_age": 26,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sanat tarihi bilginle tabloyu uygun fiyata al ve restore ettir",
	        "lock_reason": "Zeka 62+ ve Birikim Gerekli",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 800,
	        "req_tags": [],
	        "outcome_text": "Uzmanlar eserin orijinal olduğunu doğruladı; tablonun değeri on katına çıktı!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sanat_koleksiyoneri"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece evinin duvarını süslemek için hoş bir baskı resim al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Salonuna estetik bir dokunuş kattın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_36_mesleki_tukenmislik_burnout",
	    "title": "Pazartesi Sabahı Yataktan Kalkamama: Tükenmişlik Sendromu",
	    "category": "saglik",
	    "vignette": "crisis",
	    "context_note": "Modern çalışma hayatının ruhsal çöküş noktası (Burnout).",
	    "text": "Alarm çaldı ama kolunu bile kıpırdatamıyorsun. Yıllardır tatil yapmadan süren performans baskısı zihnini ve bedenini kilitledi.",
	    "min_age": 26,
	    "max_age": 56,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ücretli/ücretsiz izin alıp 3 ay boyunca doğada ve terapide ruhunu onar",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zamanında frene bastığın için depresyon uçurumundan döndün.",
	        "effects": {
	          "health": 14,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 22,
	          "karma": 0,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sakinleştirici ilaçlarla kendisini zorlayarak işe gitmeye devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Verimin düştü ve kronik anksiyete geliştirdin.",
	        "effects": {
	          "health": -12,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -18,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_37_mahalle_kooperatifi_liderligi",
	    "title": "Üretici ve Tüketici Dayanışma Kooperatifi",
	    "category": "ekonomi",
	    "vignette": "family",
	    "context_note": "Gıda enflasyonuna ve aracılara karşı yerel örgütlenme.",
	    "text": "Semt sakinleriyle birlikte doğrudan çiftçiden sağlıklı gıda getiren bir kooperatif kurma fikri gündeme geldi.",
	    "min_age": 25,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kooperatifin kurucu yönetimini üstlen ve tedarik zincirini kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yüzlerce ailenin sofrasına ucuz ve temiz gıda ulaştırdın; mahallede büyük saygı kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 8,
	          "karma": 18,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece üye olup alışveriş yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sağlıklı gıdaya uygun fiyatla ulaştın.",
	        "effects": {
	          "health": 6,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_38_ikinci_kariyer_mutfak_sanatlari",
	    "title": "Kurumsal Hayatı Bırakıp Gastronomi/Zanaat Okuluna Gitmek",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "Yetişkinlikte radikal kariyer dönüşümü.",
	    "text": "Mutfak sanatlarına veya ahşap/seramik ustalığına olan tutkun her geçen gün büyüyor. Profesyonel eğitim alıp yeni bir sayfa açabilirsin.",
	    "min_age": 28,
	    "max_age": 55,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Eğitimi tamamlayıp kendi imza mutfağını/atölyeni aç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 1200,
	        "req_tags": [],
	        "outcome_text": "Elleriyle üreten mutlu bir insan oldun; müşterilerin kapıda kuyruk oluyor!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 3500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hafta sonu hobisi olarak sürdür ve dostlarına ziyafetler ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Stres atacağın harika bir uğraş edindin.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_39_miras_veya_piyango_ikramiyesi",
	    "title": "Beklenmedik Finansal Talih Kuşu",
	    "category": "ekonomi",
	    "vignette": "luck",
	    "context_note": "Ani gelen paranın karakteri bozup bozmayacağı testi.",
	    "text": "Yıllar önce unuttuğun bir yatırım fonu, telif hakkı veya çekilişten hesabına hiç beklemediğin toplu bir ikramiye yattı!",
	    "min_age": 24,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Parayı gelir getiren gayrimenkul ve temettü hisselerine bölüştür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ani gelen parayı kalıcı bir aile servetine dönüştürdün!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 8500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gösterişli partiler ve pahalı hediyelerle bir yılda erit",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Etrafın sahte dostlarla doldu, para bitince hepsi kayboldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": -4,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_40_hukuksuz_gozalti_veya_ifade",
	    "title": "İsim Benzerliği veya İftira: Adliye Koridoru",
	    "category": "kriz",
	    "vignette": "court",
	    "context_note": "Hukuk güvenliği ve soğukkanlı savunma.",
	    "text": "Bir dolandırıcılık/bilişim soruşturmasında kimlik bilgilerinin kopyalanması veya isim benzerliği nedeniyle ifadeye çağrıldın.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Dijital ayak izi ve konum kayıtlarını avukatınla sunarak masumiyetini kanıtla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Savcılık kovuşturmaya yer olmadığına karar verdi ve asıl suçlular yakalandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 8,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hazırlıksız gidip çelişkili ifadeler vererek süreci uzat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aклаnana kadar aylarca adliye koridorlarında stres yaşadın.",
	        "effects": {
	          "health": 0,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": -1000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_41_genc_ciraga_mentorluk",
	    "title": "Şirkete/Atölyeye Gelen Yetenekli Ama Yoksul Genç",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Bilgiyi ve fırsatları yeni kuşakla paylaşma.",
	    "text": "İşe yeni başlayan çok zeki ama maddi imkansızlıklar içinde çabalayan bir gencin kendi gençliğine ne kadar benzediğini fark ettin.",
	    "min_age": 30,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ona bildiğin tüm meslek sırlarını öğret ve eğitim bursuna kefil ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yetiştirdiğin genç yıllar sonra sektörün yıldızı oldu ve seni her yerde minnetle andı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 10,
	          "karma": 22,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "usta_mentor"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Rakip olmasın diye mesafeli dur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Konumunu korudun ama gönül zenginliğini kaçırdın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": -6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_42_salgin_hastalik_ve_karantina",
	    "title": "Küresel Salgın ve Karantina Günleri",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Evlere kapanılan pandemi/salgın dönemlerinde fiziksel ve ruhsal direnç.",
	    "text": "Dünyayı saran bulaşıcı bir solunum salgını nedeniyle sokağa çıkma kısıtlamaları ve uzaktan çalışma dönemi başladı.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Evde egzersiz ve okuma rutini kur, dijital iş modellerine hızla adapte ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kriz dönemini hem sağlığını koruyarak hem de gelirini artırarak atlattın!",
	        "effects": {
	          "health": 8,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 2400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Panik haberlerini gün boyu izleyip hareketsizliğe teslim ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem kilo aldın hem de kaygı bozukluğu yaşadın.",
	        "effects": {
	          "health": -10,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_43_evlat_edinme_veya_koruyucu_aile",
	    "title": "Kimsesiz Bir Çocuğa Koruyucu Aile Olmak",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Biyolojik bağın ötesinde şefkat ve aile kurma.",
	    "text": "Sosyal hizmetler kurumunda tanıştığın, gözleri umutla parlayan kimsesiz bir çocuğa koruyucu aile olma veya evlat edinme fırsatı doğdu.",
	    "min_age": 28,
	    "max_age": 54,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kalbinin ve evinin kapılarını aç; ona sıcak bir yuva ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir çocuğun kaderini değiştirdin; evine tarifsiz bir bereket ve sevgi doldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 14,
	          "karma": 30,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ebeveyn",
	          "koruyucu_aile"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Düzenli eğitim bağışçısı olarak dışarıdan destek ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocuğun eğitim masraflarını üstlenerek iyilik yaptın.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": -400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_44_komsuluk_ve_apartman_krizi",
	    "title": "Üst Komşunun Su Sızıntısı ve Gürültü Kavgası",
	    "category": "aile",
	    "vignette": "home",
	    "context_note": "Şehir apartman yaşamının sinir uçları.",
	    "text": "Üst kat komşunun banyosundan senin tavanına su sızıyor ve gece yarılarına kadar gürültü yapıyorlar; uyardığında ise kapıda sert çıktılar.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bilirkişi tespiti yaptırıp hukuki ihtarla masrafı kendilerine ödet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yasal kararlılığın karşısında geri adım atıp tadilatı yaptırdılar.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Apartman koridorunda yumruk yumruğa kavgaya tutuş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Karakolluk oldunuz; hem tavan akmaya devam etti hem de huzurun kaçtı.",
	        "effects": {
	          "health": -8,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": -10,
	          "sanity": -10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_45_belgesel_veya_gazetecilik_dosyasi",
	    "title": "Kaybolan Kent Belleği Araştırması",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Yaşadığın şehrin tarihini ve insan hikayelerini kayıt altına alma.",
	    "text": "Şehrin yıkılmaya yüz tutmuş tarihi zanaatkarlarını ve semt kültürünü belgeleyen bir kitap/belgesel projesi için fon buldun.",
	    "min_age": 25,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Projeyi tamamla ve ulusal kültür ödülüne aday ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Eserin şehrin hafızasına altın harflerle kazındı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 8,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Arşivi dijital müzeye bağışla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kültür mirasına kalıcı katkı sundun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_46_dag_tirmanisi_ve_firtina",
	    "title": "Zirve Yürüyüşünde Aniden Bastıran Tipi",
	    "category": "saglik",
	    "vignette": "sports",
	    "context_note": "Doğa karşısında insan iradesi ve ekip dayanışması.",
	    "text": "Hafta sonu katıldığın dağ yürüyüşünde 2.500 metrede aniden sis ve kar fırtınası bastırdı. Ekip arkadaşlarından biri hipotermi belirtisi gösteriyor.",
	    "min_age": 23,
	    "max_age": 55,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Termal battaniyeyi paylaş, kar mağarası kazıp fırtına dinene kadar ekibi hayatta tut",
	        "lock_reason": "",
	        "req_stats": {
	          "health": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Soğukkanlı liderliğinle herkesi sağ salim dağ evine ulaştırdın!",
	        "effects": {
	          "health": -4,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 22,
	          "sanity": 10,
	          "karma": 20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "GPS sinyaliyle yardım çağırıp güvenli kayalıkta bekle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kurtarma ekibi kısa sürede ulaştı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_47_yapay_zeka_otomasyon_donusumu",
	    "title": "Mesleğinde Yapay Zeka Devrimi: Direnmek mi, Yönetmek mi?",
	    "category": "kariyer",
	    "vignette": "tech",
	    "context_note": "Teknolojik dönüşüm karşısında mesleki adaptasyon.",
	    "text": "Yeni nesil yapay zeka araçları sektöründeki işlerin yarısını saniyeler içinde yapmaya başladı. Birçok meslektaşın işini kaybetme korkusu yaşıyor.",
	    "min_age": 23,
	    "max_age": 59,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yapay zeka araçlarını iş akışına entegre edip verimliliğini 5 katına çıkar",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Teknolojiyi yöneten uzman olarak şirketin en aranan ismi oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 12,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ai_lideri"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Değişime direnip eski usul çalışmakta ısrar et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hız çağında geride kaldın ve gelirin durakladı.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": -800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_48_kooperatif_yazlik_veya_arsa",
	    "title": "Kıyı Kasabasında Zeytinlik / Arsa Yatırımı",
	    "category": "ekonomi",
	    "vignette": "nature",
	    "context_note": "Uzun vadeli toprak ve doğa yatırımı.",
	    "text": "Henüz imara açılmamış sakin bir kıyı köyünde yaşlı bir köylü bakamadığı zeytinliğini/bahçesini satılığa çıkardı.",
	    "min_age": 26,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Birikiminle zeytinliği al, ağaçlara bak ve kendi zeytinyağını üret",
	        "lock_reason": "Zeytinlik İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 2200,
	        "req_tags": [],
	        "outcome_text": "Hem harika bir mülk edindin hem de emekliliğin için cennetten bir köşe hazırladın!",
	        "effects": {
	          "health": 8,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 3500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "zeytinlik_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Nakit kalmayı tercih edip fırsatı pas geç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Paran bankada kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 2,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_49_eski_suclunun_santaji",
	    "title": "Geçmişten Gelen Gölge: Şantaj Mektubu",
	    "category": "kriz",
	    "vignette": "secret",
	    "context_note": "Gençlik hatalarının yetişkinlikteki itibarı tehdit etmesi.",
	    "text": "Gençlik yıllarında yaptığın bir hatayı veya sırrı bilen eski bir tanıdık, iş yerine gelip sessiz kalmak için para talep ediyor.",
	    "min_age": 25,
	    "max_age": 58,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "genclik_hatasi"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Boyun eğme; şantajı ses kaydına alıp doğrudan savcılığa suç duyurusunda bulun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Şantajcı tutuklandı; korku duvarını yıkıp özgürleştin!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Korkup istediği parayı ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Parayı aldı ama birkaç ay sonra tekrar isteyeceğini biliyorsun.",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -16,
	          "karma": 0,
	          "money_flat": -2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_50_ulusal_basari_ve_onur_odulu",
	    "title": "Meslek Odasından 'Yılın İnsanı' Ödülü",
	    "category": "kariyer",
	    "vignette": "trophy",
	    "context_note": "Yılların emeğinin taçlandığı zirve gecesi.",
	    "text": "Yirmi yılı aşkın süredir mesleğinde ve toplumsal hayatta sergilediğin nitelikli duruş nedeniyle yılın onur ödülüne layık görüldün.",
	    "min_age": 38,
	    "max_age": 59,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "reputation": 60
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ödülü ailene ve genç meslektaşlarına ithaf ederek ilham verici bir konuşma yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ayakta alkışlandın; itibarın ve iç huzurun zirveye ulaştı!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 0,
	          "reputation": 24,
	          "sanity": 14,
	          "karma": 12,
	          "money_flat": 3000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "onur_odulu_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Mütevazı bir teşekkürle ödülü al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Saygınlığın perçinlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_51_yurtdisi_is_teklifi_dubai_singapur",
	    "title": "Küresel Merkezden Vergisiz Maaş Teklifi",
	    "category": "goc",
	    "vignette": "migration",
	    "context_note": "Yüksek kazançlı uluslararası sözleşme.",
	    "text": "Uluslararası bir proje kapsamında 3 yıllığına yüksek döviz maaşlı bir bölge direktörlüğü teklifi aldın.",
	    "min_age": 27,
	    "max_age": 55,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 64
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sözleşmeyi imzala ve küresel finans/mühendislik merkezinde deneyim kazan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Üç yılda servetini katladın ve dünya çapında bir çevre edindin!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 8200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ailenin ve çocuklarının düzenini bozmamak için kendi şehrinde kal",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Huzurunu paraya tercih ettin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_52_tiyatro_veya_filarmoni_aboneligi",
	    "title": "Şehir Kültür Sanat Sezonu ve Entelektüel Çevre",
	    "category": "felsefe",
	    "vignette": "music",
	    "context_note": "Sanatın yetişkin ruhunu beslemesi.",
	    "text": "Yoğun iş temposu arasında her cuma akşamını tiyatro, konser veya sergi açılışlarına ayırma kararı aldın.",
	    "min_age": 25,
	    "max_age": 59,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sanatçılarla ve düşünürlerle dostluk kurup kültür vakfına katıl",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ruhun inceldi, sosyal çevren nitelikli insanlarla doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 6,
	          "reputation": 14,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": -400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tek başına konserleri dinleyip zihnini dinlendir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Haftanın tüm stresini müzikle yıkadın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_53_kardesin_dugunu_veya_borcu",
	    "title": "Kardeşinin İş Kurma / Evlilik Desteği",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Kardeşlik hukuku ve dayanışma.",
	    "text": "Kardeşin yeni bir yuva veya dükkan kurarken eksiği kaldığını söyleyip senden destek istiyor.",
	    "min_age": 24,
	    "max_age": 55,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Geri ödeme şartı bile koşmadan gücün yettiğince destek ol",
	        "lock_reason": "Destek İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 1400,
	        "req_tags": [],
	        "outcome_text": "Kardeşin sevinçten boynuna sarıldı; aile bağlarınız kenetlendi!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 18,
	          "money_flat": -1400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Maddi durumunun sıkışık olduğunu söyleyip manevi destek ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kardeşin anlayışla karşıladı.",
	        "effects": {
	          "health": 0,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 4,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_54_checkup_ve_erken_teshis",
	    "title": "Rutin Check-Up'ta Yakalanan Erken Bulgular",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Koruyucu hekimlik ve erken teşhisin hayat kurtarması.",
	    "text": "Hiçbir şikayetin yokken yaptırdığın kapsamlı yıllık taramada, ileride tehlikeli olabilecek küçük bir polip/nodül erken evrede tespit edildi!",
	    "min_age": 30,
	    "max_age": 59,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hemen küçük cerrahi müdahaleyle aldır ve düzenli takibe gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Erken teşhis sayesinde 10 yıl sonra çıkabilecek ölümcül bir hastalıktan tamamen kurtuldun!",
	        "effects": {
	          "health": 18,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": -900,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "erken_teshis_kurtulus"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "'Bana bir şey olmaz' diyerek kontrolü ertele",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Risk içeride büyümeye devam etti.",
	        "effects": {
	          "health": -16,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_55_mahkeme_juri_veya_bilirkisi",
	    "title": "Ağır Ceza / Ticaret Davasında Bilirkişilik Görevi",
	    "category": "felsefe",
	    "vignette": "court",
	    "context_note": "Uzmanlığın adaletin tecellisinde kullanılması.",
	    "text": "Mahkeme heyeti, kamuoyunun yakından takip ettiği karmaşık bir davada teknik/mesleki bilirkişi olarak seni atadı. Taraflardan biri dolaylı yoldan sana baskı yapıyor.",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "smart": 60
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Baskılara boyun eğmeden tamamen bilimsel ve tarafsız bir rapor yaz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Raporun adaletin yerini bulmasını sağladı; yargı camiasında sarsılmaz bir itibar kazandın!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 22,
	          "sanity": 10,
	          "karma": 22,
	          "money_flat": 1400,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "adalet_bilirkisisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Dosyadan affını isteyip görevden çekil",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Risk almadın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_56_gizli_hayirsever_kis_komuru",
	    "title": "Kış Gecesi Veresiye Defterini Kapatmak",
	    "category": "felsefe",
	    "vignette": "luck",
	    "context_note": "Sağ elin verdiğini sol elin görmemesi geleneği (Zimem defteri).",
	    "text": "Soğuk bir kış akşamı kenar mahalledeki bir bakkala girdin. Tezgahın üzerinde dar gelirli ailelerin borçlarının yazılı olduğu kabarık veresiye defteri duruyor.",
	    "min_age": 26,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İsmini vermeden veresiye defterindeki en yüklü borçları kapat",
	        "lock_reason": "Veresiye Defteri İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 1200,
	        "req_tags": [],
	        "outcome_text": "Sabah borcunun silindiğini öğrenen ailelerin duası içini ısıttı; eşsiz bir manevi huzur yaşadın!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 18,
	          "karma": 28,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "gizli_hayirsever"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Birkaç aileye erzak paketi bıraktır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Güzel bir iyilik yaptın.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": -300,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_57_emlak_balonu_ve_faiz_karari",
	    "title": "Merkez Bankası Faiz Kararı ve Konut Balonu",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Makroekonomik döngüleri okuma becerisi.",
	    "text": "Konut fiyatları tarihi zirvesine ulaştı ancak Merkez Bankası'nın sert faiz artışına gideceği konuşuluyor.",
	    "min_age": 25,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Fiyatlar zirvedeyken yatırım amaçlı mülkünü/fonunu nakde çevirip yüksek faize geç",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 62
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zamanlaman kusursuzdu! Piyasa durgunlaştığında nakit kral oldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Mevcut portföyünü bozmadan uzun vadeli kira gelirine odaklan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İstikrarlı gelirin devam etti.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_58_cocukluk_evini_ziyaret",
	    "title": "Yıllar Sonra Çocukluk Sokağından Geçmek",
	    "category": "felsefe",
	    "vignette": "home",
	    "context_note": "Zamanın geçişi ve nostalji.",
	    "text": "Bir iş dönüşü yolunu değiştirip çocukluğunun geçtiği o eski sokağa girdin. Top oynadığın arsa küçülmüş, diktiğin ağaç ise gökyüzüne uzanmış.",
	    "min_age": 32,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Eski komşuların kapısını çalıp çay iç ve anıları yad et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Geçmişinle barıştın, nereden gelip nereye yürüdüğünü şükranla hatırladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sokakta sessizce yürüyüp çocukluk haline uzaktan gülümse",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Derin ve tatlı bir hüzünle evine döndün.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_59_altmis_yas_esigi_ve_bilgelik",
	    "title": "Altmış Yaşın Eşiğinde: Fırtınaların Dinmesi",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "59 yaşında yetişkinlik koşuşturmasının tamamlanıp bilgelik ve yaşlılık dönemine geçiş.",
	    "text": "Ellili yaşların sonuna geldin. Hayatın en sert fırtınalarını göğüsledin, kazandın, kaybettin, sevdin ve öğrendin. Artık önünde bilgelik, miras ve iç hesaplaşma yılları var.",
	    "min_age": 58,
	    "max_age": 59,
	    "weight": 90,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Birikimini ve tecrübeni genç kuşaklara aktaracağın huzurlu bir döneme adım at",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yaşlılık dönemine bilge, saygın ve dingin bir ruhla giriyorsun.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 16,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bilge_yetiskin"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sağlığına ve sevdiklerine sarılarak her yeni günü bir armağan gibi yaşa",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Huzur dolu bir emeklilik ve olgunluk dönemine merhaba dedin.",
	        "effects": {
	          "health": 10,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_60_sirket_ici_inovasyon_odulu",
	    "title": "Çalıştığın KurumdaMaliyet Düşüren Buluş",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "İş yerinde verimlilik devrimi.",
	    "text": "Yıllardır kimsenin sorgulamadığı hantal bir iş sürecini yeniden tasarlayarak kurumun yılda milyonlarca birim tasarruf etmesini sağladın.",
	    "min_age": 24,
	    "max_age": 56,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Projeyi kendi adınla sunup kârdan pay ve terfi talep et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Talebin kabul edildi; hem maaşın hem unvanın yükseldi!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 3800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Başarıyı tüm ekibinle paylaşarak sadık bir lider ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ekibin sana olan bağlılığı zirveye çıktı.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_61_uluslararasi_mutfak_veya_kultur_turu",
	    "title": "Farklı Bir Kıtada Kültür Keşfi",
	    "category": "felsefe",
	    "vignette": "migration",
	    "context_note": "Dünyayı gezerek perspektif genişletme.",
	    "text": "Yılların birikimiyle daha önce hiç ayak basmadığın uzak bir coğrafyaya 3 haftalık bir kültür yolculuğuna çıkma şansın var.",
	    "min_age": 26,
	    "max_age": 58,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Turistik oteller yerine yerel halkın arasına karışıp kültürlerini tanı",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 1100,
	        "req_tags": [],
	        "outcome_text": "Dünyaya bakışın genişledi; önyargıların silindi.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": -1100,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Konforlu bir dinlenme tatili yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 1100,
	        "req_tags": [],
	        "outcome_text": "Yorgunluğunu attın.",
	        "effects": {
	          "health": 8,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": -1100,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_62_ortak_apartman_bahcesi",
	    "title": "Beton Avluyu Yeşil Bahçeye Dönüştürmek",
	    "category": "aile",
	    "vignette": "nature",
	    "context_note": "Kentsel yaşam alanını güzelleştirme.",
	    "text": "Apartmanın arka bahçesi yıllardır hurda ve çöp yığını olarak duruyor.",
	    "min_age": 24,
	    "max_age": 58,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Komşuları ikna edip hafta sonu imece usulüyle meyve ağaçları ve çardak kurun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Apartmanın değeri arttığı gibi akşamları çay içilen neşeli bir komşuluk doğdu!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 10,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Belediyeye dilekçe verip temizlenmesini sağla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sorun çözüldü.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_63_doktora_veya_uzmanlik_tezi",
	    "title": "Uzmanlık / Doktora Savunması Jüri Önünde",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Akademik ve mesleki zirve.",
	    "text": "Yıllar süren araştırmaların sonunda 5 kişilik profesörler jürisinin karşısında tezini savunuyorsun.",
	    "min_age": 26,
	    "max_age": 50,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "yuksek_lisans"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Soruları çürüterek oybirliğiyle 'Doktor / Başuzman' unvanını al",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 68
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Alanındaki en üst akademik payeye ulaştın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 14,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 3200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "doktora"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Düzeltme alarak tezi başarıyla tamamla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zorlu süreci alnının akıyla bitirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 10,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "doktora"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_64_yerel_gazete_kose_yazarligi",
	    "title": "Haftalık Köşe Yazıları ve Kamuoyu Etkisi",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Toplumun sorunlarına kalemle ışık tutma.",
	    "text": "Bağımsız bir gazete/portal senden her hafta kendi uzmanlık alanında ve toplumsal konularda köşe yazısı yazmanı istedi.",
	    "min_age": 27,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kimseye boyun eğmeden gerçekleri ve çözüm önerilerini yaz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yazıların binlerce kişi tarafından paylaşıldı; kanaat önderi oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 6,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece teknik ve suya sabuna dokunmayan analizler yaz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Düzenli telif geliri ve mesleki tanınırlık kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_65_eski_borcun_geri_donusu",
	    "title": "Yıllar Önce Borç Verdiğin Dostun Kapıyı Çalması",
	    "category": "ekonomi",
	    "vignette": "luck",
	    "context_note": "Unutulan bir iyiliğin beklenmedik karşılığı.",
	    "text": "Yıllar önce en zor gününde karşılık beklemeden destek olduğun bir arkadaşın, işlerini büyütmüş olarak elinde bir zarf ve ortaklık teklifiyle kapını çaldı!",
	    "min_age": 28,
	    "max_age": 59,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Vefasını takdir et ve sunduğu kârlı projeye ortak ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İyiliğin sana katlanarak geri döndü!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 10,
	          "money_flat": 4500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece ana parayı kabul edip dostluğunuzu kutla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gönül zenginliğinle saygısını bir kez daha kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_66_is_kazasi_ve_guvenlik_onlemi",
	    "title": "Şantiyede / Tesiste Tehlikeli İhmal",
	    "category": "saglik",
	    "vignette": "work",
	    "context_note": "İş güvenliği ve insan hayatı.",
	    "text": "Sorumlu olduğun veya çalıştığın tesiste maliyet düşürmek için güvenlik halatlarının ve filtrelerin yenilenmediğini fark ettin.",
	    "min_age": 24,
	    "max_age": 58,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Üretimi durdurma pahasına güvenlik ekipmanlarını derhal yenilet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir hafta sonra yaşanan sarsıntıda/arıza anında aldığın önlem 20 işçinin hayatını kurtardı!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 22,
	          "sanity": 10,
	          "karma": 24,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İhmali görmezden gel",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Küçük bir kaza yaşandı; vicdan azabı ve soruşturma stresi çektin.",
	        "effects": {
	          "health": -6,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": -16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_67_aile_yadigari_saat_veya_taki",
	    "title": "Kuşaktan Kuşağa Geçen Aile Yadigarı",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Aile kökleri ve manevi miras.",
	    "text": "Ailenin en yaşlı üyesi, dedelerden kalan köstekli saati / el işlemeli yadigarı 'Ailemizin onurunu en iyi sen taşırsın' diyerek sana emanet etti.",
	    "min_age": 26,
	    "max_age": 58,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yadigarı özenle koru ve kendi çocuğuna/gelecek kuşağa aktarmak üzere sakla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kuşaklar arası zincirin onurlu bir halkası oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 10,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yadigar_koruyucusu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Antikacıda değerini ekspertiz ettirip sigortala",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Maddi ve manevi değerini güvenceye aldın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_68_uzmanlik_zirvesi_ve_mentorluk",
	    "title": "Meslekte 20. Yıl Plaketi",
	    "category": "kariyer",
	    "vignette": "trophy",
	    "context_note": "Çeyrek asırlık mesleki birikim.",
	    "text": "Meslek hayatında 20 yılı geride bıraktın. Gençler senin tecrübelerine danışmak için sıraya giriyor.",
	    "min_age": 40,
	    "max_age": 59,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Deneyimlerini bir el kitabına ve eğitim serisine dönüştür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sektörde kalıcı bir okul haline geldin.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 8,
	          "reputation": 20,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çalışma saatlerini azaltıp kendine ve ailene daha çok vakit ayır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Emekliliğe yumuşak ve huzurlu bir geçiş hazırladın.",
	        "effects": {
	          "health": 10,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_69_ilk_askin_yillar_sonra_mesaji",
	    "title": "Lise Yıllarındaki İlk Aşkından Gelen Beklenmedik Mektup",
	    "category": "ask",
	    "vignette": "love",
	    "context_note": "Gençlikte çınar ağacı altında başlayan ilk aşkın yıllar sonraki karşılaşması.",
	    "text": "Yıllar önce okul bahçesindeki çınar ağacının altında kalbin küt küt atarak konuştuğun ilk aşkınla bir sergi/havalimanı salonunda göz göze geldiniz! Sana o yıllardan sakladığı kurutulmuş çınar yaprağını gösterdi.",
	    "min_age": 25,
	    "max_age": 45,
	    "weight": 5,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "ilk_ask_hatirasi"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bir kahve içip gençlik yıllarınızın masumiyetini şükranla yad edin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zamanın silemediği o temiz hatıra ruhuna sıcacık bir huzur verdi.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eğer ikiniz de bekarsanız yarım kalan hikayeye ikinci bir şans verin",
	        "lock_reason": "Evli Olmamak Gerekir",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [
	          "evli"
	        ],
	        "outcome_text": "Yıllar sonra kader ağlarını yeniden ördü; olgunluk çağında muhteşem bir sevgi başladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 26,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 18,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_70_akademik_atif_odulu",
	    "title": "Üniversitedeki Makalenin Küresel Bilim Ödülü Getirmesi",
	    "category": "kariyer",
	    "vignette": "science",
	    "context_note": "Gençlikte profesörle yazdığın makalenin yıllar içinde binlerce atıf alması.",
	    "text": "Üniversite öğrencisiyken yaz tatilini feda ederek yayımladığın o bilimsel makale, aradan geçen yıllarda alanında temel referans haline geldi ve sana Uluslararası Bilim Teşvik Ödülü kazandırdı!",
	    "min_age": 24,
	    "max_age": 42,
	    "weight": 5,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "akademik_yayin"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ödül kürsüsüne çık ve araştırma fonunu yeni laboratuvarına yatır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gençlikteki alın terin seni bilim dünyasının zirvesine taşıdı!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 10,
	          "reputation": 26,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 6500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bilim_odulu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Uluslararası enstitüden gelen konuk profesörlük davetini kabul et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dünya çapında saygın bir akademisyen oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 24,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 4800,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_71_iflas_veya_borc_yapilandirma",
	    "title": "Alacaklılarla Yuvarlak Masa: Borç Yapılandırma",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Finansal darboğazdan çıkış stratejisi.",
	    "text": "Ekonomik durgunluk nedeniyle nakit akışın sıkıştı. Banka ve tedarikçilerle masaya oturup yeni bir ödeme planı sunman gerekiyor.",
	    "min_age": 25,
	    "max_age": 58,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "agir_borclu"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gerçekçi bir bilanço sunup faizleri sildirerek 36 ay vadeye yay",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dürüst ve rasyonel sunumun kabul edildi; iflastan dönüp nefes aldın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [
	          "agir_borclu"
	        ],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gereksiz varlıkları satıp borcu tek kalemde temizle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Küçülerek de olsa borç yükünden tamamen kurtuldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [
	          "agir_borclu"
	        ],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "adt_72_mahallede_gece_yangini_kahramanlik",
	    "title": "Gece Yarısı Karşı Apartmanda Yükselen Alevler",
	    "category": "kriz",
	    "vignette": "crisis",
	    "context_note": "Komşuluk ve hayati tehlike anında cesaret.",
	    "text": "Gece saat 04:00'te sokağındaki ahşap/eski apartmanın giriş katından alevler yükseldiğini gördün. İtfaiye henüz yolda ve içeride uyuyan aileler var!",
	    "min_age": 23,
	    "max_age": 55,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yangın tüpünü kapıp girişteki alevi bastırarak üst kattakilerin tahliyesini sağla",
	        "lock_reason": "",
	        "req_stats": {
	          "health": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İtfaiye gelene kadar koridoru açık tutarak bir faciayı önledin; mahallenin kahramanı oldun!",
	        "effects": {
	          "health": -8,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 26,
	          "sanity": 0,
	          "karma": 28,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "mahalle_kahramani"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hemen itfaiyeyi arayıp dışarıdan zillere basarak herkesi uyandır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kimseye zarar gelmeden bina tahliye edildi.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  }
	]
