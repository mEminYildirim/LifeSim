extends RefCounted

# 64 Meslek Ağacı, 4 Gayrimenkul/Varlık Sınıfı ve 106 Hayat Sonu Arketipi
static func get_data() -> Dictionary:
	return {
	  "careers": [
	    {
	      "id": "c_street_vendor",
	      "title": "Seyyar Sokak Satıcısı",
	      "category": "ticaret",
	      "min_age": 16,
	      "min_smart": 20,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 4800,
	      "clean_record": false,
	      "grant_tag": "esnaf"
	    },
	    {
	      "id": "c_courier",
	      "title": "Motosikletli Kurye",
	      "category": "hizmet",
	      "min_age": 18,
	      "min_smart": 25,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 7200,
	      "clean_record": false,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_barista",
	      "title": "Üçüncü Nesil Kahve Baristası",
	      "category": "hizmet",
	      "min_age": 17,
	      "min_smart": 35,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 8400,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_waiter_chef",
	      "title": "Restoran Şef Yardımcısı",
	      "category": "hizmet",
	      "min_age": 18,
	      "min_smart": 40,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 9800,
	      "clean_record": false,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_factory_worker",
	      "title": "Sanayi Fabrika Operatörü",
	      "category": "sanayi",
	      "min_age": 18,
	      "min_smart": 35,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 11000,
	      "clean_record": false,
	      "grant_tag": "emekci"
	    },
	    {
	      "id": "c_carpenter",
	      "title": "Ahşap ve Mobilya Ustası",
	      "category": "zanaat",
	      "min_age": 18,
	      "min_smart": 42,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 13500,
	      "clean_record": false,
	      "grant_tag": "zanaat_ustasi"
	    },
	    {
	      "id": "c_electrician",
	      "title": "Endüstriyel Elektrik Teknisyeni",
	      "category": "zanaat",
	      "min_age": 18,
	      "min_smart": 48,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 15200,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_auto_mechanic",
	      "title": "Baş Mekanik ve Motor Ustası",
	      "category": "zanaat",
	      "min_age": 18,
	      "min_smart": 45,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 14800,
	      "clean_record": false,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_tailor_designer",
	      "title": "Terzi ve Moda Tasarım Ustası",
	      "category": "sanat",
	      "min_age": 18,
	      "min_smart": 45,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 13000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_baker",
	      "title": "Taş Fırın ve Pastane Ustası",
	      "category": "zanaat",
	      "min_age": 18,
	      "min_smart": 38,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 12400,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_farmer",
	      "title": "Ekolojik Tarım ve Çiftlik Yöneticisi",
	      "category": "doga",
	      "min_age": 18,
	      "min_smart": 40,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 14000,
	      "clean_record": false,
	      "grant_tag": "toprak_insani"
	    },
	    {
	      "id": "c_fisherman",
	      "title": "Açık Deniz Balıkçı Reisi",
	      "category": "doga",
	      "min_age": 18,
	      "min_smart": 38,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 13800,
	      "clean_record": false,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_firefighter",
	      "title": "İtfaiye ve Arama-Kurtarma Çavuşu",
	      "category": "kamu",
	      "min_age": 19,
	      "min_smart": 50,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 16500,
	      "clean_record": true,
	      "grant_tag": "kahraman_gorevli"
	    },
	    {
	      "id": "c_police_officer",
	      "title": "Emniyet Teşkilatı Komiser Yardımcısı",
	      "category": "kamu",
	      "min_age": 20,
	      "min_smart": 55,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 17200,
	      "clean_record": true,
	      "grant_tag": "kanun_adami"
	    },
	    {
	      "id": "c_paramedic",
	      "title": "Acil Tıp Teknisyeni (Paramedik)",
	      "category": "saglik",
	      "min_age": 19,
	      "min_smart": 55,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 16000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_real_estate_agent",
	      "title": "Gayrimenkul ve Yatırım Danışmanı",
	      "category": "ticaret",
	      "min_age": 19,
	      "min_smart": 50,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 18500,
	      "clean_record": true,
	      "grant_tag": "emlak_uzmani"
	    },
	    {
	      "id": "c_freelance_coder",
	      "title": "Bağımsız (Freelance) Web Geliştirici",
	      "category": "tech",
	      "min_age": 17,
	      "min_smart": 60,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 21000,
	      "clean_record": false,
	      "grant_tag": "yazilimci"
	    },
	    {
	      "id": "c_pro_athlete",
	      "title": "Profesyonel Kulüp Sporcusu / Futbolcu",
	      "category": "spor",
	      "min_age": 16,
	      "min_smart": 40,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 38000,
	      "clean_record": true,
	      "grant_tag": "profesyonel_sporcu"
	    },
	    {
	      "id": "c_indie_musician",
	      "title": "Sahne Müzisyeni ve Besteci",
	      "category": "sanat",
	      "min_age": 17,
	      "min_smart": 45,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 15500,
	      "clean_record": false,
	      "grant_tag": "muzisyen_ruhu"
	    },
	    {
	      "id": "c_underground_fixer",
	      "title": "Yeraltı Kuryesi ve Gece Kulübü Sorumlusu",
	      "category": "suc",
	      "min_age": 18,
	      "min_smart": 40,
	      "req_education": "none",
	      "req_tag": "",
	      "base_salary_usd": 24000,
	      "clean_record": false,
	      "grant_tag": "sabikali"
	    },
	    {
	      "id": "c_primary_teacher",
	      "title": "İlkokul ve Edebiyat Öğretmeni",
	      "category": "egitim",
	      "min_age": 22,
	      "min_smart": 60,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 16800,
	      "clean_record": true,
	      "grant_tag": "egitimci"
	    },
	    {
	      "id": "c_highschool_prof",
	      "title": "Lise Fen ve Matematik Başöğretmeni",
	      "category": "egitim",
	      "min_age": 22,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 18500,
	      "clean_record": true,
	      "grant_tag": "egitimci"
	    },
	    {
	      "id": "c_nurse_specialist",
	      "title": "Yoğun Bakım Başhemşiresi",
	      "category": "saglik",
	      "min_age": 21,
	      "min_smart": 60,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 19500,
	      "clean_record": true,
	      "grant_tag": "saglik_neferi"
	    },
	    {
	      "id": "c_pharmacist",
	      "title": "Klinik Eczacı ve Laboratuvar Sorumlusu",
	      "category": "saglik",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 26000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_psychologist",
	      "title": "Klinik Psikolog ve Psikoterapist",
	      "category": "saglik",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 25000,
	      "clean_record": true,
	      "grant_tag": "ruh_sifacisi"
	    },
	    {
	      "id": "c_general_physician",
	      "title": "Uzman Dahiliye Hekimi",
	      "category": "saglik",
	      "min_age": 24,
	      "min_smart": 75,
	      "req_education": "universite",
	      "req_tag": "tag_tip_diplomasi",
	      "base_salary_usd": 42000,
	      "clean_record": true,
	      "grant_tag": "hekim"
	    },
	    {
	      "id": "c_neurosurgeon",
	      "title": "Beyin ve Kalp Damar Cerrahı",
	      "category": "saglik",
	      "min_age": 26,
	      "min_smart": 84,
	      "req_education": "universite",
	      "req_tag": "tag_tip_diplomasi",
	      "base_salary_usd": 68000,
	      "clean_record": true,
	      "grant_tag": "bascerrah"
	    },
	    {
	      "id": "c_civil_engineer",
	      "title": "İnşaat ve Deprem İzolasyon Mühendisi",
	      "category": "muhendislik",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 27500,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_mechanical_eng",
	      "title": "Robotik ve Makine Tasarım Mühendisi",
	      "category": "muhendislik",
	      "min_age": 22,
	      "min_smart": 70,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 29500,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_software_architect",
	      "title": "Kıdemli Yazılım Mimarı (Cloud/Backend)",
	      "category": "tech",
	      "min_age": 22,
	      "min_smart": 74,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 44000,
	      "clean_record": true,
	      "grant_tag": "yazilim_mimari"
	    },
	    {
	      "id": "c_ai_researcher",
	      "title": "Yapay Zeka ve Derin Öğrenme Bilimcisi",
	      "category": "tech",
	      "min_age": 23,
	      "min_smart": 82,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 58000,
	      "clean_record": true,
	      "grant_tag": "ai_bilimcisi"
	    },
	    {
	      "id": "c_cybersec_director",
	      "title": "Siber Güvenlik ve Kriptografi Direktörü",
	      "category": "tech",
	      "min_age": 22,
	      "min_smart": 76,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 46000,
	      "clean_record": true,
	      "grant_tag": "siber_uzman"
	    },
	    {
	      "id": "c_architect",
	      "title": "Kentsel Tasarım ve Restorasyon Mimarı",
	      "category": "sanat",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 28000,
	      "clean_record": true,
	      "grant_tag": "mimar"
	    },
	    {
	      "id": "c_defense_lawyer",
	      "title": "Ceza ve İnsan Hakları Avukatı",
	      "category": "hukuk",
	      "min_age": 22,
	      "min_smart": 72,
	      "req_education": "universite",
	      "req_tag": "tag_hukuk_diplomasi",
	      "base_salary_usd": 34000,
	      "clean_record": true,
	      "grant_tag": "hukukcu"
	    },
	    {
	      "id": "c_corporate_counsel",
	      "title": "Uluslararası Ticaret ve Şirketler Hukukçusu",
	      "category": "hukuk",
	      "min_age": 23,
	      "min_smart": 76,
	      "req_education": "universite",
	      "req_tag": "tag_hukuk_diplomasi",
	      "base_salary_usd": 48000,
	      "clean_record": true,
	      "grant_tag": "hukukcu"
	    },
	    {
	      "id": "c_prosecutor_judge",
	      "title": "Cumhuriyet Savcısı / Ağır Ceza Hakimi",
	      "category": "hukuk",
	      "min_age": 25,
	      "min_smart": 80,
	      "req_education": "universite",
	      "req_tag": "tag_hukuk_diplomasi",
	      "base_salary_usd": 42000,
	      "clean_record": true,
	      "grant_tag": "adalet_koruyucusu"
	    },
	    {
	      "id": "c_chartered_accountant",
	      "title": "Yeminli Mali Müşavir ve Denetçi",
	      "category": "ekonomi",
	      "min_age": 22,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 26500,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_investment_banker",
	      "title": "Yatırım Bankası Portföy Direktörü",
	      "category": "ekonomi",
	      "min_age": 23,
	      "min_smart": 75,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 52000,
	      "clean_record": true,
	      "grant_tag": "finans_kurdu"
	    },
	    {
	      "id": "c_economist",
	      "title": "Makroekonomist ve Merkez Bankası Analisti",
	      "category": "ekonomi",
	      "min_age": 23,
	      "min_smart": 76,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 38000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_investigative_jour",
	      "title": "Araştırmacı Gazeteci ve Belgeselci",
	      "category": "medya",
	      "min_age": 21,
	      "min_smart": 64,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 21500,
	      "clean_record": true,
	      "grant_tag": "gazeteci"
	    },
	    {
	      "id": "c_novelist_screenwriter",
	      "title": "Edebiyat Yazarı ve Başsenarist",
	      "category": "sanat",
	      "min_age": 21,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 24000,
	      "clean_record": false,
	      "grant_tag": "edebiyat_yazari"
	    },
	    {
	      "id": "c_film_director",
	      "title": "Sinema Yönetmeni ve Yapımcı",
	      "category": "sanat",
	      "min_age": 23,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 35000,
	      "clean_record": false,
	      "grant_tag": "sinema_yonetmeni"
	    },
	    {
	      "id": "c_symphony_conductor",
	      "title": "Filarmoni Orkestra Şefi / Virtüöz",
	      "category": "sanat",
	      "min_age": 24,
	      "min_smart": 72,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 32000,
	      "clean_record": true,
	      "grant_tag": "virtuoz"
	    },
	    {
	      "id": "c_diplomat",
	      "title": "Dışişleri Bakanlığı Diplomatı / Konsolos",
	      "category": "kamu",
	      "min_age": 23,
	      "min_smart": 76,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 36000,
	      "clean_record": true,
	      "grant_tag": "diplomat"
	    },
	    {
	      "id": "c_university_professor",
	      "title": "Üniversite Kürsü Profesörü ve Dekan",
	      "category": "egitim",
	      "min_age": 28,
	      "min_smart": 82,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 39000,
	      "clean_record": true,
	      "grant_tag": "profesor"
	    },
	    {
	      "id": "c_astrophysicist",
	      "title": "Astrofizikçi ve Uzay Araştırmacısı",
	      "category": "bilim",
	      "min_age": 24,
	      "min_smart": 84,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 41000,
	      "clean_record": true,
	      "grant_tag": "bilim_insani"
	    },
	    {
	      "id": "c_biotech_geneticist",
	      "title": "Moleküler Biyoloji ve Genetik Uzmanı",
	      "category": "bilim",
	      "min_age": 23,
	      "min_smart": 80,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 40000,
	      "clean_record": true,
	      "grant_tag": "bilim_insani"
	    },
	    {
	      "id": "c_archaeologist",
	      "title": "Arkeolog ve Müze Küratörü",
	      "category": "bilim",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 23000,
	      "clean_record": true,
	      "grant_tag": "arkeolog"
	    },
	    {
	      "id": "c_airline_captain",
	      "title": "Sivil Havacılık Kaptan Pilotu",
	      "category": "ulastirma",
	      "min_age": 23,
	      "min_smart": 74,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 62000,
	      "clean_record": true,
	      "grant_tag": "kaptan_pilot"
	    },
	    {
	      "id": "c_ship_captain",
	      "title": "Uzak Yol Gemi Süvarisi (Kaptan)",
	      "category": "ulastirma",
	      "min_age": 23,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 45000,
	      "clean_record": true,
	      "grant_tag": "deniz_kaptani"
	    },
	    {
	      "id": "c_mayor_mp",
	      "title": "Belediye Başkanı / Parlamento Üyesi",
	      "category": "siyaset",
	      "min_age": 28,
	      "min_smart": 65,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 44000,
	      "clean_record": true,
	      "grant_tag": "siyasetci"
	    },
	    {
	      "id": "c_ngo_director",
	      "title": "Uluslararası İnsani Yardım Vakfı Başkanı",
	      "category": "kamu",
	      "min_age": 25,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 28000,
	      "clean_record": true,
	      "grant_tag": "insani_yardim"
	    },
	    {
	      "id": "c_venture_ceo",
	      "title": "Holding / Teknoloji Şirketi CEO'su",
	      "category": "ekonomi",
	      "min_age": 28,
	      "min_smart": 80,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 85000,
	      "clean_record": true,
	      "grant_tag": "ceo_lider"
	    },
	    {
	      "id": "c_green_energy_eng",
	      "title": "Yenilenebilir Enerji Sistemleri Başmühendisi",
	      "category": "muhendislik",
	      "min_age": 22,
	      "min_smart": 72,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 36000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_veterinarian",
	      "title": "Uzman Veteriner Hekim ve Yaban Hayatı Koruyucusu",
	      "category": "saglik",
	      "min_age": 22,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 24500,
	      "clean_record": true,
	      "grant_tag": "hayvan_dostu"
	    },
	    {
	      "id": "c_dentist",
	      "title": "Ağız ve Diş Sağlığı Cerrahı",
	      "category": "saglik",
	      "min_age": 23,
	      "min_smart": 72,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 38000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_industrial_designer",
	      "title": "Endüstriyel Ürün ve Otomotiv Tasarımcısı",
	      "category": "sanat",
	      "min_age": 22,
	      "min_smart": 68,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 31000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_game_director",
	      "title": "Bağımsız Oyun Stüdyosu Kreatif Direktörü",
	      "category": "tech",
	      "min_age": 21,
	      "min_smart": 70,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 37000,
	      "clean_record": false,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_data_scientist",
	      "title": "Büyük Veri ve Ekonometri Uzmanı",
	      "category": "tech",
	      "min_age": 22,
	      "min_smart": 75,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 42000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_sommelier_gastronome",
	      "title": "Uluslararası Gastronomi Şefi & İşletmeci",
	      "category": "hizmet",
	      "min_age": 23,
	      "min_smart": 60,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 33000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_urban_planner",
	      "title": "Şehir ve Bölge Planlama Uzmanı",
	      "category": "kamu",
	      "min_age": 22,
	      "min_smart": 65,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 25500,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_sociologist_author",
	      "title": "Sosyolog ve Toplum Araştırmacısı",
	      "category": "bilim",
	      "min_age": 22,
	      "min_smart": 66,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 22500,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_intelligence_analyst",
	      "title": "Stratejik İstihbarat ve Güvenlik Analisti",
	      "category": "kamu",
	      "min_age": 24,
	      "min_smart": 78,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 39000,
	      "clean_record": true,
	      "grant_tag": ""
	    },
	    {
	      "id": "c_art_gallery_owner",
	      "title": "Sanat Galerisi ve Müzayede Evi Direktörü",
	      "category": "sanat",
	      "min_age": 25,
	      "min_smart": 64,
	      "req_education": "universite",
	      "req_tag": "",
	      "base_salary_usd": 34000,
	      "clean_record": true,
	      "grant_tag": ""
	    }
	  ],
	  "assets": [
	    {
	      "id": "ast_studio",
	      "name": "Şehir Merkezinde Stüdyo Daire",
	      "category": "konut",
	      "value_usd": 45000,
	      "yield_usd": 2800,
	      "upkeep_usd": 600
	    },
	    {
	      "id": "ast_family_apt",
	      "name": "Ağaçlıklı Sokakta 3+1 Aile Apartman Dairesi",
	      "category": "konut",
	      "value_usd": 110000,
	      "yield_usd": 6500,
	      "upkeep_usd": 1400
	    },
	    {
	      "id": "ast_olive_grove",
	      "name": "Kıyı Kasabasında Taş Ev ve Zeytinlik",
	      "category": "toprak",
	      "value_usd": 165000,
	      "yield_usd": 9500,
	      "upkeep_usd": 1800
	    },
	    {
	      "id": "ast_historic_mansion",
	      "name": "Tarihi Yarımadada Restore Edilmiş Konak / Rezidans",
	      "category": "konut",
	      "value_usd": 480000,
	      "yield_usd": 28000,
	      "upkeep_usd": 6500
	    }
	  ],
	  "endings": [
	    {
	      "id": "end_001",
	      "title": "Silikon Vadisi'nin Sıfırdan Milyarderi",
	      "epitaph": "Bir garaj odasında yazdığı kodlarla dünyayı değiştirdi; teknoloji tarihine adını altın harflerle kazıdı.",
	      "req_tags": [
	        "unicorn_kurucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 95
	    },
	    {
	      "id": "end_002",
	      "title": "Gölgelerdeki Demir Baron",
	      "epitaph": "Yasal dünyanın sınırlarını aşıp yeraltı labirentlerinde hüküm sürdü; ardında korku, sırlar ve karanlık bir servet bıraktı.",
	      "req_tags": [
	        "yeralti_baronu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 94
	    },
	    {
	      "id": "end_003",
	      "title": "İki Kıtanın Kültür Köprüsü",
	      "epitaph": "Tek bir bavulla adım attığı yabancı topraklarda önyargıları yıktı; iki vatanı birbirine bağlayan bir bilge oldu.",
	      "req_tags": [
	        "gocmen_basarisi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 93
	    },
	    {
	      "id": "end_004",
	      "title": "İnsanlığın Işığı: Nobel Bilim Efsanesi",
	      "epitaph": "Laboratuvarda sabahladığı gecelerin meyvesini tüm insanlığa armağan etti; buluşu yüzyıllar boyu hayat kurtaracak.",
	      "req_tags": [
	        "nobel_bilim_odulu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 98
	    },
	    {
	      "id": "end_005",
	      "title": "Cumhuriyetin Tertemiz Devlet İnsanı",
	      "epitaph": "Siyasetin en kirli fırtınalarında bile kalemini ve vicdanını satmadı; halkın kalbinde ölümsüz bir lider olarak uğurlandı.",
	      "req_tags": [
	        "devlet_insani"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 94
	    },
	    {
	      "id": "end_006",
	      "title": "Demir Yumruk Makyavelist",
	      "epitaph": "Gücü ele geçirmek ve korumak için her yolu mübah gördü; adı tarihe muktedir ama yalnız bir siyasetçi olarak geçti.",
	      "req_tags": [
	        "demir_siyasetci"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 88
	    },
	    {
	      "id": "end_007",
	      "title": "Çağları Aşan Ölümsüz Sanatçı",
	      "epitaph": "Ruhundaki sancıları tuvale, notalara ve satırlara döktü; bedeni toprağa karışsa da eserleri müzelerde ve dillerde yaşayacak.",
	      "req_tags": [
	        "sanat_efsanesi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 93
	    },
	    {
	      "id": "end_008",
	      "title": "Atalarının Onurunu Kurtaran Varis",
	      "epitaph": "Yıllarca süren hukuk savaşıyla ailesinin çalınmış mirasını geri aldı ve köklerini yeniden yeşertti.",
	      "req_tags": [
	        "tarihi_miras_kazandi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 89
	    },
	    {
	      "id": "end_009",
	      "title": "Tıbbın Sınırlarını Aşan Şifa Elçisi",
	      "epitaph": "Ölümcül denilen hastalıktan bilime güvenerek sağ çıktı ve kendi mücadelesini binlerce hastaya umut vakfına dönüştürdü.",
	      "req_tags": [
	        "tibbi_mucize"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 91
	    },
	    {
	      "id": "end_010",
	      "title": "Stadyumların Ölümsüz Efsanesi",
	      "epitaph": "Tozlu mahalle sahalarından dünya kupalarına uzanan yolculuğunda milyonları ayağa kaldırdı; forması hiç unutulmayacak.",
	      "req_tags": [
	        "spor_efsanesi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 92
	    },
	    {
	      "id": "end_011",
	      "title": "Borsa Kulelerinin Bilge Kahini",
	      "epitaph": "Finansal fırtınaları önceden okudu; krizleri servete dönüştürürken dürüst piyasa ilkelerinden ödün vermedi.",
	      "req_tags": [
	        "finans_efsanesi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 90
	    },
	    {
	      "id": "end_012",
	      "title": "Hakikatin Korkusuz Kalemi",
	      "epitaph": "Tehditlere ve sansüre boyun eğmeden karanlık yolsuzluk dosyalarını aydınlattı; özgür basının sembolü oldu.",
	      "req_tags": [
	        "onurlu_gazeteci"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 92
	    },
	    {
	      "id": "end_013",
	      "title": "Çorak Toprakları Yeşerten Doğa Bilgesi",
	      "epitaph": "Kuruyan göllere nefes, çıplak tepelere milyonlarca fidan oldu; ardında kuşların cıvıldadığı koca bir orman bıraktı.",
	      "req_tags": [
	        "doga_kahramani"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 93
	    },
	    {
	      "id": "end_014",
	      "title": "Ateş ve Lezzetin Michelin Yıldızlı Ustası",
	      "epitaph": "Anneannesinin tarifini dünya gastronomisinin zirvesine taşıdı; sofrasında oturan herkes onun sanatına hayran kaldı.",
	      "req_tags": [
	        "michelin_sefi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 90
	    },
	    {
	      "id": "end_015",
	      "title": "Barış Masalarının Gölge Diplomatı",
	      "epitaph": "Savaşın eşiğindeki krizleri gece yarısı müzakereleriyle çözdü; kimse adını bilmese de binlerce hayatı kurtardı.",
	      "req_tags": [
	        "buyukelci"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 91
	    },
	    {
	      "id": "end_016",
	      "title": "Dağ Kulübesinin Aydınlanmış Bilgesi",
	      "epitaph": "Modern dünyanın sahte gürültüsünü elinin tersiyle itti; sadelik ve iç huzur içinde hakikate ulaştı.",
	      "req_tags": [
	        "yasayan_bilge"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 92
	    },
	    {
	      "id": "end_017",
	      "title": "Alın Terinin ve Emekçinin Sesi",
	      "epitaph": "Grev çadırlarından toplu sözleşme masalarına kadar ömrünü çalışanların hakkına ve onuruna adadı.",
	      "req_tags": [
	        "emek_kahramani"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 91
	    },
	    {
	      "id": "end_018",
	      "title": "Kayıp Uygarlıkların Kaşifi",
	      "epitaph": "Kumların altında binlerce yıl uyuyan tarihi gün yüzüne çıkardı; insanlığın hafızasını zenginleştirdi.",
	      "req_tags": [
	        "arkeoloji_efsanesi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 91
	    },
	    {
	      "id": "end_019",
	      "title": "Asırlık Ticaret Hanedanının Kurucusu",
	      "epitaph": "İflas eşiğindeki küçük aile atölyesini dünya başkentlerinde bayrağı dalgalanan bir sanayi devine dönüştürdü.",
	      "req_tags": [
	        "hanedan_kurucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 92
	    },
	    {
	      "id": "end_020",
	      "title": "Beyaz Önlüğün Kutsal Başcerrahı",
	      "epitaph": "Neşteriyle binlerce kalbe ve beyne yeniden hayat verdi; hastalarının hayır duasıyla uğurlandı.",
	      "req_tags": [
	        "bascerrah"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 86
	    },
	    {
	      "id": "end_021",
	      "title": "Adalet Terazisinin Sarsılmaz Muhafızı",
	      "epitaph": "Cübbesinde tek bir leke olmadan mazlumun hakkını savundu; hukuk fakültelerinde örnek gösterildi.",
	      "req_tags": [
	        "adalet_koruyucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 86
	    },
	    {
	      "id": "end_022",
	      "title": "Yapay Zeka Çağının Öncü Mimarı",
	      "epitaph": "Algoritmaları ve sinir ağlarını insanlığın geleceği için kodladı; dijital devrimin kurucu babalarından/annelerinden oldu.",
	      "req_tags": [
	        "ai_bilimcisi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 85
	    },
	    {
	      "id": "end_023",
	      "title": "Gökyüzünün Kıdemli Kaptanı",
	      "epitaph": "Bulutların üzerinde kıtaları birbirine bağlayarak binlerce saat uçtu; son inişini huzurla tamamladı.",
	      "req_tags": [
	        "kaptan_pilot"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 84
	    },
	    {
	      "id": "end_024",
	      "title": "Yedi Denizlerin Efsanevi Süvarisi",
	      "epitaph": "Okyanus fırtınalarına göğüs gerdi; limandan limana ömür sürdükten sonra demirini sonsuzluğa bıraktı.",
	      "req_tags": [
	        "deniz_kaptani"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 84
	    },
	    {
	      "id": "end_025",
	      "title": "Kürsülerin Unutulmaz Profesörü",
	      "epitaph": "Yetiştirdiği binlerce öğrenciyle bilimin meşalesini kuşaktan kuşağa devretti.",
	      "req_tags": [
	        "profesor"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 84
	    },
	    {
	      "id": "end_026",
	      "title": "Ruhların Şifacısı Terapist",
	      "epitaph": "Binlerce insanın çocukluk yaralarını ve karanlık korkularını dinleyip onlara yeniden yaşama sevinci aşıladı.",
	      "req_tags": [
	        "ruh_sifacisi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 83
	    },
	    {
	      "id": "end_027",
	      "title": "Siber Dünyanın Beyaz Şapkalı Kalkanı",
	      "epitaph": "Görünmez dijital savaşlarda milyonlarca insanın verisini ve altyapısını korudu.",
	      "req_tags": [
	        "siber_uzman"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_028",
	      "title": "Şehirlerin Silüetini Çizen Mimar",
	      "epitaph": "Taş, ahşap ve ışığı birleştirerek depreme dayanıklı ve estetik yapılar bıraktı.",
	      "req_tags": [
	        "mimar"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_029",
	      "title": "Sahne Işıklarının Virtüözü",
	      "epitaph": "Enstrümanından yükselen her nota dinleyenlerin kalbine dokundu; alkışlarla yaşadı, alkışlarla uğurlandı.",
	      "req_tags": [
	        "virtuoz"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_030",
	      "title": "Beyaz Perdenin Usta Yönetmeni",
	      "epitaph": "Kamerasını insan ruhunun derinliklerine çevirdi; çektiği filmler kuşaklar boyu unutulmadı.",
	      "req_tags": [
	        "sinema_yonetmeni"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_031",
	      "title": "Anadolu'nun Vefalı Çınarı",
	      "epitaph": "Ekonomik fırtınalara, sınav streslerine ve hayat gailelerine rağmen ailesini ve mahallesini hiç terk etmedi.",
	      "req_tags": [
	        "yerli_ureticiler"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_032",
	      "title": "Kırık Pusulalı Beyin Göçmeni",
	      "epitaph": "Bilgisiyle yabancı ülkelerde zirveye çıktı ama kalbinin bir yarısı hep doğduğu sokaklarda kaldı.",
	      "req_tags": [
	        "beyin_gocu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_033",
	      "title": "Tokyo'nun Yorgun Kurumsal Savaşçısı (Salaryman)",
	      "epitaph": "Ömrünü şirketin başarısına ve son trenlere yetişmeye adadı; sadakatinin bedelini yorgun bedeniyle ödedi.",
	      "req_tags": [
	        "salaryman"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_034",
	      "title": "Kiraz Çiçekleri Altında Zen Ustası",
	      "epitaph": "Hız çağının ortasında geleneksel zanaat ve içsel sükuneti seçerek kusursuz bir denge kurdu.",
	      "req_tags": [
	        "zen_ustasi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_035",
	      "title": "Kapalı Odanın Yalnız Gezgini (Hikikomori)",
	      "epitaph": "Toplumun acımasız beklentilerinden kendi iç dünyasına sığındı; sessiz ve görünmez bir ömür sürdü.",
	      "req_tags": [
	        "hikikomori"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_036",
	      "title": "Kuzey Işıklarının Doğa Dostu (Friluftsliv)",
	      "epitaph": "Fiyortların rüzgarında, kutup gecelerinin sessizliğinde doğayla barışık ve özgür yaşadı.",
	      "req_tags": [
	        "friluftsliv"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_037",
	      "title": "Amerikan Rüyasının Garaj Fatihi",
	      "epitaph": "Risk almaktan hiç korkmadı; düşe kalka kendi finansal imparatorluğunu kurdu.",
	      "req_tags": [
	        "vc_yatirimi_aldi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_038",
	      "title": "Vahşi Kapitalizmin Borç Mağduru",
	      "epitaph": "Tek bir hastane faturası ve ağır öğrenci kredileri arasında ezilse de insanlığını kaybetmedi.",
	      "req_tags": [
	        "tibbi_borc"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 74
	    },
	    {
	      "id": "end_039",
	      "title": "Lagos'un Enerjik Teknoloji Öncüsü",
	      "epitaph": "Elektrik kesintilerine ve imkansızlıklara rağmen güneş enerjisi ve yazılımla Afrika'nın yükselen yıldızı oldu.",
	      "req_tags": [
	        "fintech_kurucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_040",
	      "title": "Nollywood'un Parlayan Yıldızı",
	      "epitaph": "Sahne enerjisi ve anlatım gücüyle milyonlarca insanın yüzünü güldürdü.",
	      "req_tags": [
	        "nollywood_yildizi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_041",
	      "title": "Seul Gökdelenlerinin Zirve Yöneticisi",
	      "epitaph": "Suneung cehenneminden ve Chaebol rekabetinden zaferle çıkıp iş dünyasının tepesine yerleşti.",
	      "req_tags": [
	        "chaebol_yoneticisi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_042",
	      "title": "Favela'dan Doğup Toplumu Aydınlatan Lider",
	      "epitaph": "Suç çetelerinin kuşattığı sokaklardan müzik, spor ve eğitimle çıkarak binlerce gence umut oldu.",
	      "req_tags": [
	        "toplum_lideri"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_043",
	      "title": "Amazonların Korkusuz Muhafızı",
	      "epitaph": "Yağmur ormanlarını yağmacılara karşı canı pahasına savundu.",
	      "req_tags": [
	        "amazon_koruyucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_044",
	      "title": "Alman Endüstrisinin Kusursuz Ustası (Meister)",
	      "epitaph": "Disiplini, mühendislik zekası ve patentleriyle sanayi tarihine iz bıraktı.",
	      "req_tags": [
	        "patent_sahibi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_045",
	      "title": "Bengaluru'nun Küresel Bilişim Mimarı",
	      "epitaph": "1.4 milyarlık rekabetin içinden sıyrılıp dünya teknoloji devlerine yön veren bir deha oldu.",
	      "req_tags": [
	        "iit_mezunu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 81
	    },
	    {
	      "id": "end_046",
	      "title": "Nil Kıyısının Tarih ve Onur Muhafızı",
	      "epitaph": "Binlerce yıllık medeniyet mirasını kaçakçılara karşı koruyarak adını tarihe yazdırdı.",
	      "req_tags": [
	        "miras_koruyucusu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_047",
	      "title": "And Dağlarının Adil Kahve İhracatçısı",
	      "epitaph": "Alın teriyle yetişen kahve çekirdeklerini aracılardan kurtarıp bütün vadiyi kalkındırdı.",
	      "req_tags": [
	        "kahve_ihracatcisi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_048",
	      "title": "Bozkır ve Kışın Satranç Büyükustası",
	      "epitaph": "Sert iklimde çelikleşen analitik zekasıyla hayatı bir satranç tahtası gibi ustalıkla yönetti.",
	      "req_tags": [
	        "olimpiyat_sampiyonu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_049",
	      "title": "Shenzhen'den Dünyaya Açılan Üretim Devi",
	      "epitaph": "Gece gündüz çalışan fabrikalardan küresel bir teknoloji markası çıkardı.",
	      "req_tags": [
	        "ihracat_devi"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_050",
	      "title": "Huzurlu Sade Yaşam Filozofu (Tang Ping)",
	      "epitaph": "996 çalışma köleliğini reddedip kendi zamanının ve ruhunun efendisi oldu.",
	      "req_tags": [
	        "tang_ping"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_051",
	      "title": "Oxbridge ve Londra Finans Eliti",
	      "epitaph": "Asırlık kolej avlularından City kulelerine uzanan parlak bir entelektüel ve finansal ömür sürdü.",
	      "req_tags": [
	        "oxbridge_mezunu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_052",
	      "title": "Hiperenflasyon Fırtınasının Hayatta Kalan Kaptanı",
	      "epitaph": "Paranın her gün eridiği kriz yıllarında hem ailesinin birikimini hem de yaşama sevincini korudu.",
	      "req_tags": [
	        "kur_korumali"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_053",
	      "title": "Meydanların Dayanışma Önderi",
	      "epitaph": "Ekonomik çöküş günlerinde komşularını açlıktan ve umutsuzluktan koruyan halk kahramanı oldu.",
	      "req_tags": [
	        "dayanisma_lideri"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 80
	    },
	    {
	      "id": "end_054",
	      "title": "Kayıtsız Göçmenlikten Zirveye Tırmanan Savaşçı",
	      "epitaph": "Fırtınalı denizleri ve sınırları aşıp sıfırdan onurlu bir hayat inşa etti.",
	      "req_tags": [
	        "kayitsiz_gocmen"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": 55,
	      "max_karma": 101,
	      "priority": 79
	    },
	    {
	      "id": "end_055",
	      "title": "Yيمinli İhbarcı (Whistleblower)",
	      "epitaph": "Şirketlerin karanlık yolsuzluklarını kendi kariyerini yakma pahasına ifşa etti.",
	      "req_tags": [
	        "durust_ihbarci"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 85
	    },
	    {
	      "id": "end_056",
	      "title": "Veresiye Defterlerini Kapatan Gizli Hayırsever",
	      "epitaph": "Yaptığı iyilikleri kimselere söylemedi; kış gecelerinde yüzlerce hanenin duasını aldı.",
	      "req_tags": [
	        "gizli_hayirsever"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": 75,
	      "max_karma": 101,
	      "priority": 86
	    },
	    {
	      "id": "end_057",
	      "title": "Kimsesizlerin Yuvası Koruyucu Ebeveyn",
	      "epitaph": "Kan bağının ötesine geçip yetim bir çocuğa dünyaları verdi; en yüce sevgiyi yaşadı.",
	      "req_tags": [
	        "koruyucu_aile"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": 75,
	      "max_karma": 101,
	      "priority": 87
	    },
	    {
	      "id": "end_058",
	      "title": "Alevlerin Arasından Hayat Kurtaran Kahraman",
	      "epitaph": "Kendi canını hiçe sayarak komşularını ve masumları ölümden çekip aldı.",
	      "req_tags": [
	        "mahalle_kahramani"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 86
	    },
	    {
	      "id": "end_059",
	      "title": "Dört Kuşağı Kucaklayan Asırlık Çınar",
	      "epitaph": "Doksan yılı aşan ömründe torunlarının çocuklarını bile kucağına alma mucizesine erişti.",
	      "req_tags": [
	        "dort_kusak_gordu"
	      ],
	      "min_age": 88,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 89
	    },
	    {
	      "id": "end_060",
	      "title": "Altmışından Sonra Üniversite Bitiren Bilge",
	      "epitaph": "Öğrenmenin yaşı olmadığını kanıtlayarak gençlere unutulmaz bir ders verdi.",
	      "req_tags": [
	        "yasam_boyu_ogrenci"
	      ],
	      "min_age": 60,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 84
	    },
	    {
	      "id": "end_061",
	      "title": "Eğitim Vakfı Kurucusu Hayırsever",
	      "epitaph": "Kazandığı serveti mezara götürmedi; binlerce gencin okuyacağı kalıcı bir vakıf bıraktı.",
	      "req_tags": [
	        "vakif_kurucusu"
	      ],
	      "min_age": 60,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 85
	    },
	    {
	      "id": "end_062",
	      "title": "Kendi İşinin Efendisi Cesur Girişimci",
	      "epitaph": "Başkalarının emrinde çalışmayı reddedip sıfırdan kendi ticari kalesini inşa etti.",
	      "req_tags": [
	        "kendi_isinin_patronu"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_063",
	      "title": "Zeytin Ağaçları Altında Huzurlu Emekli",
	      "epitaph": "Şehrin kaosundan sıyrılıp kendi diktiği zeytin ağaçlarının gölgesinde dingin bir sonbahar yaşadı.",
	      "req_tags": [
	        "zeytinlik_sahibi"
	      ],
	      "min_age": 55,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 77
	    },
	    {
	      "id": "end_064",
	      "title": "Kuşaklararası Mirasın İkinci Halkası",
	      "epitaph": "Ebeveyninden devraldığı meşaleyi daha da yükseğe taşıyarak aile soyadını yüceltti.",
	      "req_tags": [
	        "mirasci_kusak"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_065",
	      "title": "Bir Ömrün Tanığı Hatırat Yazarı",
	      "epitaph": "Yaşadığı çağın tüm acılarını ve sevinçlerini satırlara dökerek gelecek kuşaklara ışık bıraktı.",
	      "req_tags": [
	        "hatirat_yazari"
	      ],
	      "min_age": 60,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 78
	    },
	    {
	      "id": "end_066",
	      "title": "Mahallenin Bilge Hakemi",
	      "epitaph": "Sokağında kimse mahkemeye gitmezdi; onun adil sözü her kavgayı barışla çözerdi.",
	      "req_tags": [
	        "mahalle_bilgesi"
	      ],
	      "min_age": 60,
	      "social_class": "",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 79
	    },
	    {
	      "id": "end_067",
	      "title": "Yaralı Ama Yenilmez Savaşçı",
	      "epitaph": "Bedeninde hayatın bıraktığı derin yara izleriyle yaşadı ama hiçbir fırtınada diz çökmedi.",
	      "req_tags": [
	        "tag_yarali"
	      ],
	      "min_age": 40,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 70
	    },
	    {
	      "id": "end_068",
	      "title": "Demir Parmaklıklar Ardında Kaybolan Gençlik",
	      "epitaph": "Kolay para uğruna girdiği karanlık sokaklar özgürlüğünü çaldı; pişmanlık dolu bir ömür sürdü.",
	      "req_tags": [
	        "hapis_yatti"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 45,
	      "priority": 76
	    },
	    {
	      "id": "end_069",
	      "title": "İtibarını Kaybetmiş Yalnız Milyoner",
	      "epitaph": "Altın varaklı salonlarda yaşadı ama geçmişteki kirli imzaları yüzünden yapayalnız öldü.",
	      "req_tags": [
	        "itibarsiz_yaslilik"
	      ],
	      "min_age": 60,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 40,
	      "priority": 78
	    },
	    {
	      "id": "end_070",
	      "title": "Vergi Cennetlerinin Gölge Zengini",
	      "epitaph": "Servetini denizaşırı adalarda sakladı ama kendi ülkesinde saygısını yitirdi.",
	      "req_tags": [
	        "vergi_skandali"
	      ],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 45,
	      "priority": 75
	    },
	    {
	      "id": "end_071",
	      "title": "Dar Gelirden Zirveye Tırmanan Azim Abidesi",
	      "epitaph": "Yamalı paltoyla başladığı hayat yolculuğunu en üst refah diliminde tamamladı!",
	      "req_tags": [
	        "dar_gelirli_cocukluk"
	      ],
	      "min_age": 45,
	      "social_class": "elite",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 88
	    },
	    {
	      "id": "end_072",
	      "title": "Yoksulluktan Orta Sınıfa Onurlu Yükseliş",
	      "epitaph": "Hiçbir harama el uzatmadan, alın teriyle ailesini yoksulluk döngüsünden kurtardı.",
	      "req_tags": [
	        "dar_gelirli_cocukluk"
	      ],
	      "min_age": 40,
	      "social_class": "middle",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 77
	    },
	    {
	      "id": "end_073",
	      "title": "Altın Kaşıkla Doğup Serveti Eriten Mirasyedi",
	      "epitaph": "Varlıklı bir ailede dünyaya geldi ama savruk kararlarıyla elindekileri rüzgara savurdu.",
	      "req_tags": [
	        "varlikli_cocukluk"
	      ],
	      "min_age": 30,
	      "social_class": "low",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_074",
	      "title": "Elit Kulelerin Soylu Hayırseveri",
	      "epitaph": "Doğuştan gelen ayrıcalığını kibir için değil, topluma hizmet ve adalet için kullandı.",
	      "req_tags": [
	        "varlikli_cocukluk"
	      ],
	      "min_age": 50,
	      "social_class": "elite",
	      "min_karma": 75,
	      "max_karma": 101,
	      "priority": 82
	    },
	    {
	      "id": "end_075",
	      "title": "Çocuk İşçilikten Ustalığa Uzanan Hayat",
	      "epitaph": "Okul çağında çıraklıkla başlayan nasırlı elleri, ömrünün sonunda saygın bir ustanın elleriydi.",
	      "req_tags": [
	        "cocuk_cirak"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": 60,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_076",
	      "title": "Kitapların Arasında Yaşayan Entelektüel",
	      "epitaph": "Çocukken aldığı ilk kütüphane kartından son nefesine kadar okumaktan hiç vazgeçmedi.",
	      "req_tags": [
	        "kitap_kurdu"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 72
	    },
	    {
	      "id": "end_077",
	      "title": "Sadık Hayvan Dostlarının Koruyucu Meleği",
	      "epitaph": "Sokaktaki dilsiz canlara ömür boyu kol kanat gerdi; merhametiyle hatırlandı.",
	      "req_tags": [
	        "hayvan_dostu"
	      ],
	      "min_age": 45,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 74
	    },
	    {
	      "id": "end_078",
	      "title": "Zorbalığa Boyun Eğmeyen Yürekli İnsan",
	      "epitaph": "İlkokul bahçesinden iş hayatına kadar hiçbir haksızlığın karşısında susmadı.",
	      "req_tags": [
	        "zorba_karsiti"
	      ],
	      "min_age": 40,
	      "social_class": "",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 73
	    },
	    {
	      "id": "end_079",
	      "title": "Yarım Kalan Senfoni: Erken Veda",
	      "epitaph": "Henüz gerçekleştireceği pek çok hayali varken hayata beklenmedik bir yaşta veda etti.",
	      "req_tags": [],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 15
	    },
	    {
	      "id": "end_080",
	      "title": "Dürüst ve Onurlu Emekçi",
	      "epitaph": "Sarayları veya milyonları olmadı ama boğazından tek bir haram lokma geçmeden alnı açık yaşadı.",
	      "req_tags": [],
	      "min_age": 55,
	      "social_class": "low",
	      "min_karma": 75,
	      "max_karma": 101,
	      "priority": 68
	    },
	    {
	      "id": "end_081",
	      "title": "Sessiz Direnişçi: Derin Yoksulluğun Tanığı",
	      "epitaph": "Dünyanın en adaletsiz gelir diliminde doğmasına rağmen insanlık onurunu sonuna kadar korudu.",
	      "req_tags": [],
	      "min_age": 45,
	      "social_class": "extreme_poor",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 67
	    },
	    {
	      "id": "end_082",
	      "title": "Orta Sınıfın Huzurlu Aile Direği",
	      "epitaph": "Fırtınalı dünyada ailesine güvenli bir liman oldu; çocuklarının başarısıyla gurur duydu.",
	      "req_tags": [
	        "ebeveyn"
	      ],
	      "min_age": 60,
	      "social_class": "middle",
	      "min_karma": 60,
	      "max_karma": 101,
	      "priority": 66
	    },
	    {
	      "id": "end_083",
	      "title": "Yarım Asırlık Sadık Hayat Arkadaşı",
	      "epitaph": "Sevdiği insanın elini gençlikten saçları ağarana dek bir gün bile bırakmadı.",
	      "req_tags": [
	        "sadik_es"
	      ],
	      "min_age": 65,
	      "social_class": "",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_084",
	      "title": "Yalnız Ama Özgür Gezgin",
	      "epitaph": "Hiçbir yere ve kimseye kök salmadan rüzgarın götürdüğü kıtalarda özgürce yaşadı.",
	      "req_tags": [
	        "uluslararasi_vizyon"
	      ],
	      "min_age": 45,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 71
	    },
	    {
	      "id": "end_085",
	      "title": "Borç Batağında Yıpranan Ruh",
	      "epitaph": "Enflasyon, krediler ve ekonomik krizler arasında ömür boyu çıkış yolu aradı.",
	      "req_tags": [
	        "agir_borclu"
	      ],
	      "min_age": 40,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 64
	    },
	    {
	      "id": "end_086",
	      "title": "Bilim ve Akıl Yolunun Takipçisi",
	      "epitaph": "Hurafelere ve karanlığa karşı her zaman bilimin ve rasyonel düşüncenin ışığında yürüdü.",
	      "req_tags": [
	        "bilim_meraklisi"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 70
	    },
	    {
	      "id": "end_087",
	      "title": "Gençlerin Usta Mentoru",
	      "epitaph": "Kendi başarısıyla yetinmeyip elinden tuttuğu onlarca gence meslek ve ahlak kazandırdı.",
	      "req_tags": [
	        "usta_mentor"
	      ],
	      "min_age": 55,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 77
	    },
	    {
	      "id": "end_088",
	      "title": "Emlak ve Toprak Yatırımcısı",
	      "epitaph": "Dişinden tırnağından artırarak aldığı mülklerle ailesine sarsılmaz bir güvence bıraktı.",
	      "req_tags": [
	        "ev_sahibi"
	      ],
	      "min_age": 55,
	      "social_class": "high",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 69
	    },
	    {
	      "id": "end_089",
	      "title": "Krizleri Fırsata Çeviren Stratejist",
	      "epitaph": "Herkesin paniklediği çöküş günlerinde soğukkanlılığını koruyarak servetini büyüttü.",
	      "req_tags": [
	        "kriz_yatirimcisi"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 74
	    },
	    {
	      "id": "end_090",
	      "title": "İkinci Baharın Mutlu İnsanı",
	      "epitaph": "Orta yaşta hayatını cesurca sıfırladı ve ömrünün ikinci yarısını tutkularıyla yaşadı.",
	      "req_tags": [
	        "ikinci_bahar"
	      ],
	      "min_age": 55,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 72
	    },
	    {
	      "id": "end_091",
	      "title": "Anne-Baba Duası Almış Vefalı Evlat",
	      "epitaph": "Yaşlanan ebeveynlerini yalnız bırakmadı; aldığı hayır duaları ömrünü aydınlattı.",
	      "req_tags": [
	        "vefali_evlat"
	      ],
	      "min_age": 55,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_092",
	      "title": "Kalem ve Kelam Ustası Yazar",
	      "epitaph": "Yazdığı kitaplar raflarda, kurduğu cümleler okurların zihninde yaşamaya devam edecek.",
	      "req_tags": [
	        "yazar_unvani"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_093",
	      "title": "Fikirleriyle Yaşayan Mucit",
	      "epitaph": "Tescillediği patentler ve pratik çözümler günlük hayatı kolaylaştırmaya devam ediyor.",
	      "req_tags": [
	        "patent_geliri"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 76
	    },
	    {
	      "id": "end_094",
	      "title": "Sanat Koleksiyoneri ve Kültür Hamisi",
	      "epitaph": "Estetik gözüyle topladığı eserlerle kültür mirasının korunmasına hizmet etti.",
	      "req_tags": [
	        "sanat_koleksiyoneri"
	      ],
	      "min_age": 55,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 73
	    },
	    {
	      "id": "end_095",
	      "title": "Dijital Göçebe ve Küresel Freelancer",
	      "epitaph": "Ofis duvarlarına hapsolmadan dünyanın her yerinden üreterek özgürce yaşadı.",
	      "req_tags": [
	        "freelancer"
	      ],
	      "min_age": 40,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 70
	    },
	    {
	      "id": "end_096",
	      "title": "Kürsülerin Hitabet Şampiyonu",
	      "epitaph": "Sözün gücünü çocuk yaşta keşfetti; konuştuğunda salonları nefessiz bıraktı.",
	      "req_tags": [
	        "munazara_sampiyonu"
	      ],
	      "min_age": 45,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 71
	    },
	    {
	      "id": "end_097",
	      "title": "Fırtınalı Denizlerin Cankurtaranı",
	      "epitaph": "Başkası boğulurken kıyıdan izlemedi; suya atlayıp bir insanın nefesini geri verdi.",
	      "req_tags": [
	        "hayat_kurtardi"
	      ],
	      "min_age": 40,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 77
	    },
	    {
	      "id": "end_098",
	      "title": "Bozkırın Bilgeliğini Taşıyan Torun Dedesi/Ninesi",
	      "epitaph": "Dizinin dibinde büyüyen torunlarına anlattığı masallar ve öğütlerle ölümsüzleşti.",
	      "req_tags": [
	        "torun_sahibi"
	      ],
	      "min_age": 70,
	      "social_class": "",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 74
	    },
	    {
	      "id": "end_099",
	      "title": "Adil Vasiyet Bırakan Aile Büyüğü",
	      "epitaph": "Arkasında kavga değil, adalet ve helalleşme bırakarak gözlerini huzurla kapattı.",
	      "req_tags": [
	        "adil_vasiyet"
	      ],
	      "min_age": 70,
	      "social_class": "",
	      "min_karma": 65,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_100",
	      "title": "Zihnini Son Nefesine Dek Keskin Tutan Bilge",
	      "epitaph": "İleri yaşına rağmen satrançtan, bulmacadan ve düşünceden hiç kopmadı.",
	      "req_tags": [
	        "keskin_hafiza"
	      ],
	      "min_age": 75,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 74
	    },
	    {
	      "id": "end_101",
	      "title": "Kutsal Yolların Arınmış Yolcusu",
	      "epitaph": "Ömrünün sonbaharında çıktığı büyük yolculukla ruhunu yıkadı ve tertemiz göçtü.",
	      "req_tags": [
	        "kutsal_gezi"
	      ],
	      "min_age": 65,
	      "social_class": "",
	      "min_karma": 70,
	      "max_karma": 101,
	      "priority": 75
	    },
	    {
	      "id": "end_102",
	      "title": "Herkesle Helalleşmiş Huzurlu Ruh",
	      "epitaph": "Kalbinde hiç kimseye kin tutmadan, herkesin hakkını ödeyerek bu dünyadan ayrıldı.",
	      "req_tags": [
	        "helallesmis"
	      ],
	      "min_age": 72,
	      "social_class": "",
	      "min_karma": 75,
	      "max_karma": 101,
	      "priority": 79
	    },
	    {
	      "id": "end_103",
	      "title": "Karanlık Sırların ve Pişmanlıkların Gölgesi",
	      "epitaph": "Vicdanını susturarak kazandığı başarılar, son gecesinde başucunda sessiz birer hayalet gibi durdu.",
	      "req_tags": [
	        "kirli_para"
	      ],
	      "min_age": 50,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 45,
	      "priority": 72
	    },
	    {
	      "id": "end_104",
	      "title": "Servet Kulelerinin Yalnız İmparatoru",
	      "epitaph": "Dünya nüfusunun en zengin %1'lik dilimine ulaştı; maddi olarak her şeye sahip oldu.",
	      "req_tags": [],
	      "min_age": 50,
	      "social_class": "elite",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 65
	    },
	    {
	      "id": "end_105",
	      "title": "Refah ve Denge İnsanı",
	      "epitaph": "Hem maddi refahı hem de ruhsal huzuru bir arada tutmayı başaran nadir insanlardan oldu.",
	      "req_tags": [],
	      "min_age": 60,
	      "social_class": "high",
	      "min_karma": 60,
	      "max_karma": 101,
	      "priority": 64
	    },
	    {
	      "id": "end_106",
	      "title": "8 Milyarda Bir: Kendi Hikayesinin Kahramanı",
	      "epitaph": "Milyarlarca insanın arasında kendi payına düşen sevinçleri, kederleri ve seçimleri cesurca yaşadı.",
	      "req_tags": [],
	      "min_age": 0,
	      "social_class": "",
	      "min_karma": -1,
	      "max_karma": 101,
	      "priority": 10
	    }
	  ]
	}
