extends RefCounted

# 15 Ülkenin Demografik, Ekonomik, Yasal ve Kültürel Verisi + 90 Yerel Olay (1in8b Çekirdeği)
static func get_countries() -> Dictionary:
	return {
	  "TR": {
	    "code": "TR",
	    "name": "Türkiye",
	    "flag": "🇹🇷",
	    "currency_symbol": "₺",
	    "exchange_rate_to_usd": 34.0,
	    "global_pop_pct": 1.1,
	    "spawn_weight": 9.0,
	    "life_expectancy": 78,
	    "gdp_per_capita_usd": 13100,
	    "inflation_rate": 0.42,
	    "tax_rate": 0.24,
	    "annual_living_cost_usd": 5200,
	    "uni_tuition_usd": 450,
	    "base_health_index": 80,
	    "cities": [
	      "İstanbul",
	      "Ankara",
	      "İzmir",
	      "Bursa",
	      "Antalya",
	      "Eskişehir",
	      "Gaziantep",
	      "Trabzon"
	    ],
	    "female_names": [
	      "Zeynep",
	      "Elif",
	      "Defne",
	      "Asya",
	      "Nehir",
	      "Selin",
	      "Duru",
	      "Merve",
	      "Ayşe",
	      "Gökçe",
	      "Eylül",
	      "Bahar"
	    ],
	    "male_names": [
	      "Mehmet",
	      "Kerem",
	      "Alparslan",
	      "Göktuğ",
	      "Emir",
	      "Can",
	      "Barış",
	      "Mert",
	      "Yusuf",
	      "Arda",
	      "Kaan",
	      "Deniz"
	    ],
	    "surnames": [
	      "Yılmaz",
	      "Kaya",
	      "Demir",
	      "Çelik",
	      "Şahin",
	      "Yıldız",
	      "Aydın",
	      "Öztürk",
	      "Arslan",
	      "Doğan",
	      "Kılıç",
	      "Soylu"
	    ],
	    "class_distribution": {
	      "extreme_poor": 10,
	      "low": 34,
	      "middle": 40,
	      "high": 12,
	      "elite": 4
	    },
	    "birth_report_text": "Dünya nüfusunun yalnızca %1.1'i bu kıtalararası ülkede doğuyor. Sıcak mahalle dayanışması ve çay buharı arasında büyürken, yüksek enflasyon, zorlu YKS sınav maratonu ve gelecek kaygısıyla erken yaşta tanışacaksın.",
	    "local_events": [
	      {
	        "id": "tr_yks_sinav_sabahi",
	        "title": "YKS Sınav Sabahı Düğümü",
	        "category": "egitim",
	        "vignette": "exam",
	        "context_note": "Türkiye'de milyonlarca gencin kaderini belirleyen Yükseköğretim Kurumları Sınavı sabahı.",
	        "text": "Haziran sabahı okul bahçesinde yüzlerce gencin nefesi tutulmuş durumda. Ailen kapıda dualarla gözlerinin içine bakıyor; elindeki kurşun kalem ve silgi sanki bütün geleceğinin ağırlığını taşıyor.",
	        "min_age": 18,
	        "max_age": 19,
	        "weight": 95,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [
	            "lise_mezunu"
	          ],
	          "blocked_tags": [
	            "universite_ogrencisi"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Tüm odağını topla ve bildiğin her şeyi optik forma dök",
	            "lock_reason": "Zeka En Az 62 Olmalı",
	            "req_stats": {
	              "smart": 62
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Saatler süren terin ardından sınavdan alnının akıyla çıktın ve köklü bir devlet üniversitesine yerleştin.",
	            "effects": {
	              "health": -3,
	              "happiness": 14,
	              "smart": 8,
	              "reputation": 15,
	              "sanity": -6,
	              "karma": 2,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "akademik_basari"
	            ],
	            "remove_tags": [],
	            "add_trait": "Azimli",
	            "schedule_consequence": {
	              "delay_years": 4,
	              "event_id": "tr_kyk_kredi_geri_odeme",
	              "origin_note": "18 yaşındaki YKS başarısı ve üniversite yıllarının ardından"
	            }
	          },
	          {
	            "text": "Orta sıralarda bir puanla taşra üniversitesine ve KYK yurduna yerleş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ailenden uzakta, 6 kişilik bir yurt odasında kendi ayakların üzerinde durmayı öğreneceğin yıllar başladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 5,
	              "reputation": 0,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "kyk_borclu"
	            ],
	            "remove_tags": [],
	            "add_trait": "Uyumlu",
	            "schedule_consequence": {
	              "delay_years": 4,
	              "event_id": "tr_kyk_kredi_geri_odeme",
	              "origin_note": "Üniversite yıllarında aldığın öğrenim kredisinin vadesi geldiğinde"
	            }
	          },
	          {
	            "text": "Sınav stresine yenik düşüp mezuna kal ve dershaneye kapan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bir yıl boyunca test kitapları arasında boğuldun ama iradeni çelikleştirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": -12,
	              "smart": 10,
	              "reputation": 0,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "mezuna_kaldi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Sabırlı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Üniversite dayatmasını reddet, doğrudan çıraklık ve ticarete atıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Akrabaların burun kıvırsa da piyasanın tozunu erken yutarak nakit kazanmaya başladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 3,
	              "smart": 0,
	              "reputation": -5,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "erken_ticaret"
	            ],
	            "remove_tags": [],
	            "add_trait": "Pratik",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "tr_askerlik_celbi",
	        "title": "Yoklama Kaçağı ve Askerlik Celbi",
	        "category": "askerlik",
	        "vignette": "military",
	        "context_note": "Türkiye'de 20 yaşına gelen her erkek vatandaş için zorunlu askerlik yol ayrımı.",
	        "text": "E-Devlet bildiriminde 'Askerlik Yoklama İşleminiz Yaklaşmaktadır' uyarısı belirdi. Döviz kuru ve bedelli askerlik ücreti her altı ayda bir zamlanırken karar vermelisin.",
	        "min_age": 20,
	        "max_age": 26,
	        "weight": 92,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [
	            "askerlik_yapti"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Altı ay boyunca sınır karakolunda kışla hizmetini tamamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Soğuk nöbet geceleri, içtima meydanı ve memleketin dört bir yanından gelen tertiplerle unutulmaz bir disiplin kazandın.",
	            "effects": {
	              "health": 4,
	              "happiness": -6,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": -5,
	              "karma": 5,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti"
	            ],
	            "remove_tags": [],
	            "add_trait": "Disiplinli",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Birikimini veya banka kredisini kullanarak Bedelli Askerlik yap",
	            "lock_reason": "Bedelli Ücreti İçin Birikim Gerekli",
	            "req_stats": {},
	            "req_money": 4500,
	            "req_tags": [],
	            "outcome_text": "Yüksek bedeli ödeyip 28 günlük temel eğitimi tamamladın; iş ve kariyer düzenin kesintiye uğramadı.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 4,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti",
	              "bedelli_asker"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Yüksek lisans / doktora kaydıyla askerliği ertele",
	            "lock_reason": "Üniversite Diploması ve Zeka 65+ Gerekli",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [
	              "universite_mezunu"
	            ],
	            "outcome_text": "Akademik koridorlara sığınarak celp tarihini yıllarca ileriye attın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 7,
	              "reputation": 0,
	              "sanity": -3,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "akademik_tecil"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "tr_kyk_kredi_geri_odeme",
	        "title": "KYK Öğrenim Kredisi Borç Tebligatı",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Üniversite yıllarında alınan burs/kredi ödemelerinin mezuniyet sonrası vergi dairesi takibi.",
	        "text": "Mezuniyetinin üzerinden iki yıl geçti. Vergi dairesinden gelen zarfta, öğrencilik yıllarında aldığın KYK kredisinin enflasyon farkıyla birlikte geri ödeme takvimi duruyor.",
	        "min_age": 22,
	        "max_age": 28,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yapılandırma fırsatını yakala ve borcu peşin kapat",
	            "lock_reason": "Borcu Kapatacak Birikim Gerekli",
	            "req_stats": {},
	            "req_money": 1800,
	            "req_tags": [],
	            "outcome_text": "Ana para üzerinden borcu kapatıp üzerindeki büyük bir kamburu attın.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 4,
	              "money_flat": -1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "borcsuz_mezun"
	            ],
	            "remove_tags": [
	              "kyk_borclu"
	            ],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Maaşından aylık taksitlerle kesilmesini kabul et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bütçen birkaç yıl sıkışacak olsa da yasal takibe düşmeden ödemeyi sürdürüyorsun.",
	            "effects": {
	              "health": 0,
	              "happiness": -5,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -750,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [
	              "kyk_borclu"
	            ],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ödemeyi ertele ve e-haciz riskini göze al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Banka hesaplarına bloke konma korkusuyla nakit çalışmaya başladın.",
	            "effects": {
	              "health": 0,
	              "happiness": -10,
	              "smart": 0,
	              "reputation": -8,
	              "sanity": -9,
	              "karma": -5,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "agir_borclu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "tr_altin_gunu_ve_kur_soku",
	        "title": "Kur Şoku ve Mahallede Altın Günü",
	        "category": "ekonomi",
	        "vignette": "family",
	        "context_note": "Türk aile yapısında yastık altı çeyrek altın geleneği ve ani döviz dalgalanması.",
	        "text": "Merkez Bankası kararları sonrası döviz kuru bir gecede %25 fırladı. Annengil mahalledeki altın gününden gelen çeyrek altınları bozdurup eve ortak bir yatırım yapmayı öneriyor.",
	        "min_age": 23,
	        "max_age": 55,
	        "weight": 78,
	        "repeatable": true,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Aile birikimini birleştirip gelişmekte olan bölgeden arsa/konut peşinatına gir",
	            "lock_reason": "Peşinat Birikimi ve Zeka 55+ Gerekli",
	            "req_stats": {
	              "smart": 55
	            },
	            "req_money": 1500,
	            "req_tags": [],
	            "outcome_text": "Enflasyonist ortamda gayrimenkul değeri katlanarak ailenin sınıf atlamasını sağladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "emlak_yatirimcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Öngörülü",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Çeyrek altınları yastık altında tutmaya devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Paranın alım gücünü enflasyona karşı korudun, güvenli limandan şaşmadın.",
	            "effects": {
	              "health": 0,
	              "happiness": 5,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 900,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kısa yoldan zengin olmak için kaldıraçlı kripto borsasına yatır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Gece yarısı gelen tasfiye (liquidation) bildirimiyle altınların buharlaştı, aile içinde büyük tartışma çıktı.",
	            "effects": {
	              "health": 0,
	              "happiness": -18,
	              "smart": 0,
	              "reputation": -12,
	              "sanity": -15,
	              "karma": 0,
	              "money_flat": -1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "tr_bayram_sofrasi_baskisi",
	        "title": "Bayram Sofrasında Akraba Sorgusu",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "Geleneksel bayram ziyaretlerinde kuşaklar arası beklenti ve statü çatışması.",
	        "text": "Kurban Bayramı'nda salon tıklım tıklım. Büyük amcan çayını karıştırırken herkesin içinde sesini yükseltti: 'Ee, yaşın geçiyor; ne zaman memur oluyorsun, ne zaman mürüvvetini görüyoruz?'",
	        "min_age": 21,
	        "max_age": 38,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Nezaketini bozmadan kendi hayat planını ve ilkelerini anlat",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 50
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sofradaki genç kuzenlerin sana hayranlıkla baktı; kendi sınırlarını çizdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 8,
	              "sanity": 7,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "Özsaygılı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sert çıkıp masadaki ikiyüzlülükleri yüzlerine vur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Salon buz kesti! İçinin yağları eridi ama aile büyükleriyle köprüleri yaktın.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": -14,
	              "sanity": 5,
	              "karma": -4,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "asi_ruh"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Başını eğip geçiştir, içindeki öfkeyi bastır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bayram harçlığı ve huzur bozulmadı ama gece boyu dişlerini sıktın.",
	            "effects": {
	              "health": 0,
	              "happiness": -8,
	              "smart": 0,
	              "reputation": 4,
	              "sanity": -7,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "tr_beyin_gocu_ikilemi",
	        "title": "Avrupa'dan Gelen İş Teklifi ve Vatan Özlemi",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Nitelikli gençlerin ekonomik darboğaz ile memleket sevgisi arasındaki tarihsel ikilemi.",
	        "text": "Uzun süredir yürüttüğün projeler Münih ve Amsterdam merkezli iki şirketin dikkatini çekti. Döviz bazında maaş ve oturum izni teklif ediyorlar; ancak yaşlanan anne-baban gözlerinin içine bakıyor.",
	        "min_age": 24,
	        "max_age": 42,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "TR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 68
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Teklifi kabul et, bavulunu toplayıp Avrupa'ya uzanan yeni bir sayfa aç",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Havalimanında gözyaşlarıyla vedalaştın; kariyerin ve maddi refahın hızla yükseldi.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 6,
	              "reputation": 14,
	              "sanity": -6,
	              "karma": 0,
	              "money_flat": 5500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "beyin_gocu",
	              "gocmen"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Türkiye'de kalıp uzaktan (remote) dövizle çalışarak iki dünyayı birleştir",
	            "lock_reason": "Uzaktan Dövizli İş İçin Zeka 78+ Gerekli",
	            "req_stats": {
	              "smart": 78
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem sevdiklerinin dizinin dibinde kaldın hem de döviz gelirinle ülkede üst sınıfa yükseldin.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 15,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 4800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "uzaktan_calisan"
	            ],
	            "remove_tags": [],
	            "add_trait": "Stratejist",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Teklifi reddet, memlekette kendi ekibinle direnmeyi seç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zorlu ekonomik şartlara rağmen ülkende üreterek saygın bir isim oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 5,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 10,
	              "money_flat": 1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "yerli_ureticiler"
	            ],
	            "remove_tags": [],
	            "add_trait": "Vefalı",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "JP": {
	    "code": "JP",
	    "name": "Japonya",
	    "flag": "🇯🇵",
	    "currency_symbol": "¥",
	    "exchange_rate_to_usd": 152.0,
	    "global_pop_pct": 1.5,
	    "spawn_weight": 8.0,
	    "life_expectancy": 85,
	    "gdp_per_capita_usd": 34000,
	    "inflation_rate": 0.02,
	    "tax_rate": 0.3,
	    "annual_living_cost_usd": 14500,
	    "uni_tuition_usd": 5200,
	    "base_health_index": 88,
	    "cities": [
	      "Tokyo",
	      "Osaka",
	      "Kyoto",
	      "Yokohama",
	      "Sapporo",
	      "Fukuoka",
	      "Nagoya"
	    ],
	    "female_names": [
	      "Sakura",
	      "Hina",
	      "Yui",
	      "Aoi",
	      "Rin",
	      "Mio",
	      "Haruka",
	      "Akari",
	      "Kaede",
	      "Mei"
	    ],
	    "male_names": [
	      "Haruto",
	      "Ren",
	      "Sota",
	      "Yuto",
	      "Kaito",
	      "Daiki",
	      "Takumi",
	      "Kenji",
	      "Hiroshi",
	      "Akira"
	    ],
	    "surnames": [
	      "Sato",
	      "Suzuki",
	      "Takahashi",
	      "Tanaka",
	      "Watanabe",
	      "Ito",
	      "Yamamoto",
	      "Nakamura",
	      "Kobayashi",
	      "Kato"
	    ],
	    "class_distribution": {
	      "extreme_poor": 4,
	      "low": 22,
	      "middle": 56,
	      "high": 14,
	      "elite": 4
	    },
	    "birth_report_text": "Dünyanın en güvenli ve en uzun ömürlü toplumlarından birinde (%1.5) doğdun. Kusursuz tren hatları ve yüksek teknoloji seni bekliyor; ancak 'Karoshi' (aşırı çalışmadan tükeniş) ve toplumsal uyum baskısı ruhunu sınayacak.",
	    "local_events": [
	      {
	        "id": "jp_shukatsu_mezuniyet_avi",
	        "title": "Shukatsu: Siyah Takım Elbiseli İş Avı",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Japonya'da üniversite son sınıfta tüm öğrencilerin aynı siyah takım elbiseyle katıldığı toplu işe alım ritüeli.",
	        "text": "Tokyo metrosu senin gibi jilet gibi siyah takım elbise giymiş binlerce yeni mezunla dolu. Dev bir kurumsal şirketin (Kaisha) ömür boyu istihdam mülakatındasın.",
	        "min_age": 21,
	        "max_age": 24,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kusursuz 'Keigo' (saygı dili) ve tam sadakat sözüyle kurumsal kadroya gir",
	            "lock_reason": "Zeka En Az 60 Olmalı",
	            "req_stats": {
	              "smart": 60
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Şirket ailesine kabul edildin; düzenli maaşın garanti ama mesai saatlerin gece yarısına uzanıyor.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "salaryman"
	            ],
	            "remove_tags": [],
	            "add_trait": "Kurumsal",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Geleneksel hiyerarşiyi reddet ve bağımsız oyun/manga stüdyosuna katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Gelirin ilk yıllarda düşük kalsa da yaratıcı özgürlüğün ruhunu besledi.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 6,
	              "reputation": -4,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "bagimsiz_sanatci"
	            ],
	            "remove_tags": [],
	            "add_trait": "Yaratıcı",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "jp_karoshi_son_tren",
	        "title": "Son Treni Kaçırmak ve Karoshi Sınırı",
	        "category": "saglik",
	        "vignette": "crisis",
	        "context_note": "Japon çalışma kültüründe müdür ofisten çıkmadan masadan kalkamama geleneği.",
	        "text": "Saat gece 23:55. Shinjuku istasyonundan kalkan son banliyö trenini yine kaçırdın. Kalbinde garip bir çarpıntı ve gözlerinde kararma var; müdürün ise hâlâ masasında rapor bekliyor.",
	        "min_age": 25,
	        "max_age": 52,
	        "weight": 85,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Derhal istifa dilekçeni ver ve kırsalda (Inaka) geleneksel bir ahşap ev kirala",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Gelirin yarıya düştü ama kiraz çiçeklerinin altında sağlığını ve akıl sağlığını geri kazandın.",
	            "effects": {
	              "health": 16,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": -10,
	              "sanity": 20,
	              "karma": 0,
	              "money_flat": -1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "inaka_yasami"
	            ],
	            "remove_tags": [
	              "salaryman"
	            ],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Dişini sıkıp sabaha kadar raporu bitir, terfi basamağını zorla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yönetim kurulu azmini takdir etti ve maaşını artırdı ama hastanede serum yemek zorunda kaldın.",
	            "effects": {
	              "health": -22,
	              "happiness": -10,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": -16,
	              "karma": 0,
	              "money_flat": 6500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "karoshi_riski"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "İşçi sendikasına ve çalışma bakanlığına fazla mesai kayıtlarını sızdır",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Şirket ceza aldı, sana yüklü tazminat ödediler ancak sektörde adın 'uyumsuz'a çıktı.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": -8,
	              "sanity": 8,
	              "karma": 12,
	              "money_flat": 5000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "jp_hikikomori_odasi",
	        "title": "Kapalı Kapılar Ardında: Hikikomori Çekimi",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "Japonya'da yüz binlerce gencin toplumsal beklenti ağırlığından kaçarak yıllarca odasından çıkmaması.",
	        "text": "Okul ve toplum beklentileri omuzlarına kurşun gibi çöküyor. Odanın sürgülü kapısını kapatıp dış dünyayla tüm iletişimi kesme isteği her geçen gün güçleniyor.",
	        "min_age": 15,
	        "max_age": 32,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Belediyenin sosyal destek danışmanıyla görüşüp adım adım sokağa çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zorlu bir terapi sürecinin ardından yeniden güneş ışığına ve insan içine karıştın.",
	            "effects": {
	              "health": 6,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "Dirençli",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Odaya kapan ama içeride yazılım ve dijital sanat üreterek dünyaya bağlan",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Fiziksel olarak yalnızlaşsan da internette anonim bir deha olarak gelir elde etmeye başladın.",
	            "effects": {
	              "health": -8,
	              "happiness": 2,
	              "smart": 14,
	              "reputation": 0,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "dijital_inziva"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tamamen içe çekil ve yıllarca odandan çıkma",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zaman kavramı eridi; ailen kapının önüne yemek tepsisi bırakırken gençlik yılların sessizce akıp gitti.",
	            "effects": {
	              "health": -15,
	              "happiness": -18,
	              "smart": 0,
	              "reputation": -20,
	              "sanity": -22,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "hikikomori"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "jp_buyuk_deprem_sarsintisi",
	        "title": "Büyük Pasifik Depremi ve Tsunami Уyarısı",
	        "category": "kriz",
	        "vignette": "crisis",
	        "context_note": "Pasifik Ateş Çemberi üzerindeki Japonya'da her an çalan erken uyarı sirenleri.",
	        "text": "Telefonundan tiz 'J-Alert' deprem alarmı yükseldi ve saniyeler sonra binalar beşik gibi sallanmaya başladı. Mahalledeki yaşlı komşunuzun merdivenlerde mahsur kaldığını duydun.",
	        "min_age": 12,
	        "max_age": 85,
	        "weight": 75,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Artçı sarsıntılara rağmen içeri dalıp yaşlı komşuyu sırtında çıkar",
	            "lock_reason": "Sağlık En Az 55 Olmalı",
	            "req_stats": {
	              "health": 55
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahalle komitesi cesaretini ayakta alkışladı; belediye başkanı sana onur madalyası takdim etti.",
	            "effects": {
	              "health": -8,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 20,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "afet_kahramani"
	            ],
	            "remove_tags": [],
	            "add_trait": "Cesur",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Acil durum çantanı alıp doğrudan güvenli toplanma alanına koş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hazırlıklı olman sayesinde sarsıntıyı burnun bile kanamadan atlattın.",
	            "effects": {
	              "health": 0,
	              "happiness": 2,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 5,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "jp_kiraz_cicegi_hanami",
	        "title": "Ueno Parkı'nda Hanami ve Geçicilik (Mono no Awake)",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "Baharda sadece bir hafta açıp dökülen Sakura çiçeklerinin altında hayatın anlamını düşünmek.",
	        "text": "Nisan rüzgarı pembe kiraz çiçeği yapraklarını çay bardağının içine savuruyor. Yanındaki emekli bir hattat sana hayatın tıpkı bu yapraklar gibi kısa ve kırılgan olduğunu söylüyor.",
	        "min_age": 18,
	        "max_age": 90,
	        "weight": 70,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hattat ustadan geleneksel kaligrafi (Shodo) ve Zen meditasyonu öğren",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Fırça darbeleriyle zihnini terbiye ettin; içsel huzurun derinleşti.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 16,
	              "karma": 8,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "zen_ustasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Dingin",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Arkadaşlarınla sake kadehlerini kaldırıp anın tadını çıkar",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kahkahalarla dolu sıcak bir bahar akşamı geçirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": -150,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "jp_miras_zanaat_atolyeleri",
	        "title": "Yüz Yıllık Aile Atölyesinin (Shinise) Geleceği",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "Japonya'da kuşaktan kuşağa geçen asırlık zanaat dükkanlarının varis krizi.",
	        "text": "Kyoto'nun arka sokaklarında 140 yıldır bıçak ve seramik üreten yaşlı bir usta, kendi çocuklarının Tokyo'ya gittiğini söyleyerek atölyesini sana devretmeyi teklif ediyor.",
	        "min_age": 24,
	        "max_age": 58,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "JP"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Çıraklığa başla ve asırlık geleneği e-ticaretle dünyaya aç",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 60
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "El yapımı ürünlerin Avrupa ve Amerika'da koleksiyoncular tarafından kapışıldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 5800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "zanaat_ustasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Modern şehir hayatını bırakmak istemediğin için teklifi kibarca geri çevir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Usta anlayışla başını salladı; şehirdeki tempona geri döndün.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 2,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "NO": {
	    "code": "NO",
	    "name": "Norveç",
	    "flag": "🇳🇴",
	    "currency_symbol": "kr",
	    "exchange_rate_to_usd": 10.8,
	    "global_pop_pct": 0.07,
	    "spawn_weight": 3.0,
	    "life_expectancy": 84,
	    "gdp_per_capita_usd": 87000,
	    "inflation_rate": 0.03,
	    "tax_rate": 0.38,
	    "annual_living_cost_usd": 24000,
	    "uni_tuition_usd": 0,
	    "base_health_index": 92,
	    "cities": [
	      "Oslo",
	      "Bergen",
	      "Trondheim",
	      "Stavanger",
	      "Tromsø",
	      "Ålesund"
	    ],
	    "female_names": [
	      "Nora",
	      "Emma",
	      "Sofie",
	      "Olivia",
	      "Astrid",
	      "Ingrid",
	      "Freja",
	      "Sigrid",
	      "Linnea",
	      "Maja"
	    ],
	    "male_names": [
	      "Jakob",
	      "Emil",
	      "Noah",
	      "Oliver",
	      "Filip",
	      "Henrik",
	      "Lukas",
	      "Magnus",
	      "Sander",
	      "Haakon"
	    ],
	    "surnames": [
	      "Hansen",
	      "Johansen",
	      "Olsen",
	      "Larsen",
	      "Andersen",
	      "Pedersen",
	      "Nilsen",
	      "Kristiansen",
	      "Jensen",
	      "Karlsen"
	    ],
	    "class_distribution": {
	      "extreme_poor": 1,
	      "low": 12,
	      "middle": 68,
	      "high": 16,
	      "elite": 3
	    },
	    "birth_report_text": "Dünya nüfusunun yalnızca %0.07'sinin paylaştığı kuzey refah cennetinde doğdun! Eğitim ve sağlık tamamen ücretsiz, devlet fonu arkanızda; ancak aylar süren kutup geceleri (Mørketid) ve yalnızlık zihnini zorlayabilir.",
	    "local_events": [
	      {
	        "id": "no_morketid_kutup_gecesi",
	        "title": "Mørketid: Güneşin Doğmadığı Kış Ayları",
	        "category": "saglik",
	        "vignette": "philosophy",
	        "context_note": "Kuzey Kutup Dairesi yakınlarında kış aylarında haftalarca güneşin ufuktan hiç yükselmemesi.",
	        "text": "Kasım ayından beri gökyüzü alacakaranlık. Pencerenden fiyortlara düşen karı izlerken derin bir D vitamini eksikliği ve kuzey melankolisi ruhunu sarıyor.",
	        "min_age": 14,
	        "max_age": 75,
	        "weight": 84,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "'Friluftsliv' (açık hava yaşamı) felsefesine sarıl; kayak yapıp fiyort saunasına gir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Buzlu suya girip odun ateşinde ısınmak bedenini ve zihnini çelik gibi tazeledi.",
	            "effects": {
	              "health": 12,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 15,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "friluftsliv"
	            ],
	            "remove_tags": [],
	            "add_trait": "Doğa Dostu",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Evde mum ışığında ('Koselig') kitap yazmaya ve müzik bestelemeye odaklan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Karanlık kış aylarını derin bir entelektüel üretime dönüştürdün.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 12,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Karanlığa teslim olup yalnızlığa ve alkole sığın",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kuzey kışı ruhunda derin yaralar açtı.",
	            "effects": {
	              "health": -12,
	              "happiness": -15,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -18,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "no_russefeiring_mezuniyet",
	        "title": "Russefeiring: Kırmızı Tulumlu Lise Mezuniyeti",
	        "category": "egitim",
	        "vignette": "luck",
	        "context_note": "Norveç'te lise son sınıf öğrencilerinin sınavlardan hemen önce haftalarca otobüslerle kutlama yapması.",
	        "text": "Mayıs ayı geldi ve bütün arkadaşların kırmızı 'Russ' tulumlarını giyip ses sistemiyle donatılmış parti otobüsüne binmeye hazırlanıyor; ancak final sınavların hemen ertesi hafta!",
	        "min_age": 18,
	        "max_age": 19,
	        "weight": 88,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gündüz kütüphanede çalış, akşamları dozunda kutlamaya katıl",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 55
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem ömürlük dostluklar kurdun hem de Oslo Üniversitesi'ne yüksek puanla girdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -600,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Üç hafta boyunca çılgınca eğlen, sınavları şansa bırak",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Harika anılar biriktirdin ama sabaha karşı fiyort kıyısında üşütüp sınavları düşük notla geçtin.",
	            "effects": {
	              "health": -8,
	              "happiness": 20,
	              "smart": -5,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -1400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "no_petrol_fonu_etik_ikilem",
	        "title": "Kuzey Denizi Petrol Platformu mu, Yeşil Enerji mi?",
	        "category": "kariyer",
	        "vignette": "science",
	        "context_note": "Norveç'in devasa petrol zenginliği ile iklim koruma vicdanı arasındaki ulusal tartışma.",
	        "text": "Stavanger'deki açık deniz petrol platformundan çok yüksek maaşlı bir mühendislik teklifi aldın; aynı anda Kuzey Kutbu rüzgar enerjisi enstitüsü seni araştırmacı olarak çağırıyor.",
	        "min_age": 23,
	        "max_age": 48,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kuzey Denizi petrol platformunda çalışıp kısa sürede servet biriktir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Fırtınalı denizde zorlu vardiyalarla çalıştın ama banka hesabın hızla doldu.",
	            "effects": {
	              "health": -6,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": -8,
	              "money_flat": 9500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "offshore_uzmani"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Yeşil enerji ve buzul koruma enstitüsünü seç",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 62
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Maaşın daha mütevazı kalsa da uluslararası bilim camiasında büyük saygı kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 10,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 16,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "iklim_arastirmacisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "İdealist",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "no_janteloven_mutevazilik",
	        "title": "Janteloven: Gösterişten Kaçınma Yasası",
	        "category": "felsefe",
	        "vignette": "family",
	        "context_note": "İskandinav kültüründe 'kendini kimseden üstün görme' yazısız kuralı.",
	        "text": "Yaptığın yatırımlardan ciddi bir kazanç elde ettin. Komşuların mütevazı elektrikli araçlarla gezerken senin lüks bir spor araba alma fikrin kasabada tuhaf karşılanabilir.",
	        "min_age": 26,
	        "max_age": 65,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "İskandinav sadeliğini koru; parayı fiyort kıyısında ahşap bir kulübeye (Hytte) yatır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 2500,
	            "req_tags": [],
	            "outcome_text": "Hem toplumun saygısını kazandın hem de hafta sonları doğada huzur buldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": -2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "hytte_sahibi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kuralları boşver, lüks içinde gösterişli bir hayat yaşa",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 4000,
	            "req_tags": [],
	            "outcome_text": "Keyfin yerinde ama komşuların seninle mesafeli konuşmaya başladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": -15,
	              "sanity": 0,
	              "karma": -4,
	              "money_flat": -4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "no_aurora_borealis_kesfi",
	        "title": "Tromsø Gökyüzünde Kuzey Işıkları (Aurora)",
	        "category": "felsefe",
	        "vignette": "art",
	        "context_note": "Kutup gecesinde gökyüzünü boyayan yeşil ve mor ışık perdeleri.",
	        "text": "Dondurucu bir Şubat gecesi gökyüzü aniden zümrüt yeşili ve mürdüm ışık dalgalarıyla dans etmeye başladı. Yanında fotoğraf makinen ve not defterin var.",
	        "min_age": 16,
	        "max_age": 85,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kuzey ışıklarını belgeleyip uluslararası doğa sergisine gönder",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Eserlerin Avrupa dergilerinde yayımlandı, sanatsal duyarlılığın arttı.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 6,
	              "reputation": 12,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kamerayı bırak, sessizce karların üzerine uzanıp evreni izle",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Varoluşsal kaygıların eridi; tarifsiz bir iç huzuruyla doldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 20,
	              "karma": 6,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "no_nav_sosyal_guvence",
	        "title": "NAV Refah Ağı ve Yeniden Eğitim Fırsatı",
	        "category": "ekonomi",
	        "vignette": "academy",
	        "context_note": "Norveç sosyal devletinin işsiz veya tükenmiş vatandaşlarına sunduğu kapsamlı dönüşüm desteği.",
	        "text": "Kariyerinde bir dönüm noktasındasın. Devlet kurumu NAV, maaşının önemli kısmını karşılayarak sana tamamen yeni bir alanda uzmanlaşma bursu teklif ediyor.",
	        "min_age": 25,
	        "max_age": 55,
	        "weight": 75,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Destekten yararlanıp yapay zeka ve deniz biyolojisi alanında uzmanlaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sosyal devlet güvencesiyle hiçbir maddi korku yaşamadan ikinci bir meslek edindin.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 15,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "cift_uzmanlik"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kamu desteğine ihtiyaç duymadan kendi girişimini kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bağımsızlığınla gurur duydun ve kendi işinin patronu oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "US": {
	    "code": "US",
	    "name": "ABD",
	    "flag": "🇺🇸",
	    "currency_symbol": "$",
	    "exchange_rate_to_usd": 1.0,
	    "global_pop_pct": 4.2,
	    "spawn_weight": 11.0,
	    "life_expectancy": 77,
	    "gdp_per_capita_usd": 81000,
	    "inflation_rate": 0.035,
	    "tax_rate": 0.26,
	    "annual_living_cost_usd": 22000,
	    "uni_tuition_usd": 28000,
	    "base_health_index": 76,
	    "cities": [
	      "New York",
	      "Los Angeles",
	      "Chicago",
	      "San Francisco",
	      "Austin",
	      "Boston",
	      "Seattle",
	      "Miami"
	    ],
	    "female_names": [
	      "Olivia",
	      "Emma",
	      "Charlotte",
	      "Amelia",
	      "Sophia",
	      "Mia",
	      "Harper",
	      "Evelyn",
	      "Chloe",
	      "Grace"
	    ],
	    "male_names": [
	      "Liam",
	      "Noah",
	      "Oliver",
	      "James",
	      "Elijah",
	      "William",
	      "Henry",
	      "Lucas",
	      "Benjamin",
	      "Ethan"
	    ],
	    "surnames": [
	      "Smith",
	      "Johnson",
	      "Williams",
	      "Brown",
	      "Jones",
	      "Garcia",
	      "Miller",
	      "Davis",
	      "Rodriguez",
	      "Wilson"
	    ],
	    "class_distribution": {
	      "extreme_poor": 8,
	      "low": 28,
	      "middle": 42,
	      "high": 16,
	      "elite": 6
	    },
	    "birth_report_text": "Sınırsız girişimcilik fırsatları ile devasa gelir uçurumunun yan yana yaşadığı ABD'de (%4.2) doğdun. Silikon Vadisi veya Wall Street'te milyoner olabilirsin; ancak sağlık sigortan yoksa tek bir ambulans faturası seni iflasa sürükleyebilir.",
	    "local_events": [
	      {
	        "id": "us_ivy_league_ogrenci_kredisi",
	        "title": "Ivy League Kabulü ve $180.000 Öğrenci Kredisi",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "ABD'de prestijli üniversitelerin astronomik eğitim ücretleri ve ömür boyu süren kredi yükü.",
	        "text": "Posta kutusunda kalın bir zarf var: Prestijli bir üniversiteden kabul aldın! Ancak yıllık eğitim ve kampüs ücreti ailenin bütçesini çok aşıyor; federal öğrenci kredisi imzalaman gerekiyor.",
	        "min_age": 17,
	        "max_age": 20,
	        "weight": 92,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kredi sözleşmesini imzala ve prestijli kampüse adım at",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Elit bir çevre ve harika bir eğitim kazandın ama omuzlarında ağır bir borçla mezun olacaksın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 14,
	              "reputation": 20,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": -8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "ivy_league",
	              "ogrenci_kredisi_borcu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Yerel Devlet Kolejine (Community College) gidip borçsuz mezun ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Gösterişsiz ama akıllıca bir tercihle sıfır borçla diplomana kavuştun.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Tutumlu",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Üniversiteyi boşver, garajda kendi teknoloji girişimini başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kriskli ama Amerikan rüyasına uygun bir başlangıç yaptın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 6,
	              "reputation": 5,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "garaj_girisimcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "us_ambulans_ve_hastane_faturasi",
	        "title": "Sigortasız Acil Servis ve $42.000 Fatura Şoku",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "ABD sağlık sisteminde özel sigorta kapsamı dışındaki tıbbi müdahalelerin yıkıcı maliyeti.",
	        "text": "Şiddetli apandisit ağrısıyla acil servise kaldırıldın ve ameliyat oldun. Taburcu olurken eline tutuşturulan faturada sigortanın 'ağ dışı' sayıldığı ve on binlerce dolar borçlu olduğun yazıyor!",
	        "min_age": 19,
	        "max_age": 75,
	        "weight": 86,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [
	            "extreme_poor",
	            "low",
	            "middle"
	          ],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hastane hukuk departmanıyla kalem kalem pazarlık yapıp indirim kopar",
	            "lock_reason": "Pazarlık İçin Zeka 65+ Gerekli",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Tıbbi kodlardaki şişirmeleri tespit ettin; faturayı %70 indirimle kapattın.",
	            "effects": {
	              "health": 10,
	              "happiness": 4,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tüm birikimini verip kredi kartlarını patlatarak öde",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sağlığına kavuştun ama yıllarca biriktirdiğin para bir gecede eridi.",
	            "effects": {
	              "health": 10,
	              "happiness": -18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -14,
	              "karma": 0,
	              "money_flat": -14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tibbi_borc"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Bireysel İflas (Chapter 7 Bankruptcy) ilan ederek borcu sildir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Borçtan kurtuldun ama kredi puanın (Credit Score) dibe vurdu.",
	            "effects": {
	              "health": 8,
	              "happiness": -10,
	              "smart": 0,
	              "reputation": -18,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kredi_sicili_bozuk"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "us_silikon_vadisi_pitch",
	        "title": "Silikon Vadisi'nde Risk Sermayesi (VC) Sunumu",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Sand Hill Road yatırımcıları önünde 5 dakikalık girişim sunumu.",
	        "text": "Palo Alto'da bir kafede tanıştığın melek yatırımcı, üzerinde çalıştığın yazılım fikrini dinlemek için sana 5 dakika verdi. Başarılı olursan milyon dolarlık tohum yatırım alabilirsin.",
	        "min_age": 21,
	        "max_age": 48,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 65
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Verilere dayalı, gerçekçi ve sağlam bir iş modeli sun",
	            "lock_reason": "Zeka En Az 72 Olmalı",
	            "req_stats": {
	              "smart": 72
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yatırımcılar dürüstlüğünden ve teknik hakimiyetinden etkilendi; tohum yatırımı aldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 8,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 18000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "vc_yatirimi_aldi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Vizyoner",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "'Sahte yapana kadar öyle görün' (Fake it till you make it) diyerek abartılı vaatler ver",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlk başta devasa fon topladın ama 3 yıl sonra denetim soruşturması kapını çalacak!",
	            "effects": {
	              "health": 0,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": -15,
	              "money_flat": 25000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "abartili_girisim"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 3,
	              "event_id": "arc_fin_4",
	              "origin_note": "Silikon Vadisi'nde yatırımcılara verdiğin abartılı vaatlerin denetimi"
	            }
	          }
	        ]
	      },
	      {
	        "id": "us_wall_street_opsiyon",
	        "title": "Wall Street Koridorları ve Borsa Çılgınlığı",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "New York finans merkezinde yüksek riskli opsiyon işlemleri.",
	        "text": "Manhattan'da bir aracı kurumda çalışan arkadaşın, teknoloji hisselerinde büyük bir dalgalanma olacağını söylüyor. Birikimini opsiyon kontratlarına yatırma fırsatın var.",
	        "min_age": 22,
	        "max_age": 60,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "S&P 500 endeks fonuna uzun vadeli ve disiplinli yatırım yap",
	            "lock_reason": "En Az $2000 Birikim Gerekli",
	            "req_stats": {},
	            "req_money": 2000,
	            "req_tags": [],
	            "outcome_text": "Bileşik getirinin gücüyle portföyün istikrarlı biçimde büyüdü.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 6500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Yüksek kaldıraçlı opsiyonlarla tek gecede servet avına çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Piyasa ters yöne kırıldı; ekran başında soğuk terler dökerken paranın yarısını kaybettin.",
	            "effects": {
	              "health": 0,
	              "happiness": -14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -16,
	              "karma": 0,
	              "money_flat": -4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "us_kasirga_ve_sigorta",
	        "title": "Kategori 4 Kasırga Уyarısı ve Tahliye Kararı",
	        "category": "kriz",
	        "vignette": "crisis",
	        "context_note": "Atlantik ve Körfez kıyılarında her sonbahar yaşanan yıkıcı kasırga mevsimi.",
	        "text": "Ulusal Kasırga Merkezi şehrinize doğru ilerleyen dev bir fırtına için zorunlu tahliye çağrısı yaptı. Otoyollar kilitlenmiş durumda, komşuların pencerelerine kontrplak çakıyor.",
	        "min_age": 16,
	        "max_age": 80,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Aileni ve evcil hayvanını alıp iç eyaletlere doğru erken tahliyeye çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Evde hasar oluşsa da canınızı kurtardınız.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": -1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Evini yağmacılara karşı korumak için içeride kal ve diren",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çatının bir kısmı uçtu, korku dolu bir gece geçirdin ama mülkünü korudun.",
	            "effects": {
	              "health": -10,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 8,
	              "sanity": -12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "us_route66_yol_hikayesi",
	        "title": "Route 66: Kıtayı Baştan Başa Geçen Yolculuk",
	        "category": "felsefe",
	        "vignette": "migration",
	        "context_note": "Amerikan edebiyatının ve özgürlük arayışının simgesi olan otoyol yolculuğu.",
	        "text": "Hayatının tekdüzeliğinden bunaldığın bir yaz, eski bir üstü açık araba alıp Chicago'dan Kaliforniya kıyılarına uzanan efsanevi Route 66 yoluna çıkma fikri doğdu.",
	        "min_age": 19,
	        "max_age": 65,
	        "weight": 70,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "US"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yola çık; çöl kasabalarında konaklayıp yol günlüğü yaz",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 1800,
	            "req_tags": [],
	            "outcome_text": "Yol boyunca tanıdığın sıradışı insanlar ufkunu açtı, ruhun özgürleşti.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 16,
	              "karma": 0,
	              "money_flat": -1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "yol_gezini"
	            ],
	            "remove_tags": [],
	            "add_trait": "Özgür Ruhlu",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "İzin günlerini harcamayıp mesaiye devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Banka hesabın korundu ama pencereden otoyola bakıp iç geçirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": -4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "NG": {
	    "code": "NG",
	    "name": "Nijerya",
	    "flag": "🇳🇬",
	    "currency_symbol": "₦",
	    "exchange_rate_to_usd": 1600.0,
	    "global_pop_pct": 2.8,
	    "spawn_weight": 12.0,
	    "life_expectancy": 62,
	    "gdp_per_capita_usd": 2100,
	    "inflation_rate": 0.32,
	    "tax_rate": 0.18,
	    "annual_living_cost_usd": 1800,
	    "uni_tuition_usd": 350,
	    "base_health_index": 68,
	    "cities": [
	      "Lagos",
	      "Abuja",
	      "Kano",
	      "Ibadan",
	      "Port Harcourt",
	      "Enugu"
	    ],
	    "female_names": [
	      "Amina",
	      "Chidinma",
	      "Ngozi",
	      "Zainab",
	      "Funke",
	      "Adaeze",
	      "fatima",
	      "Yetunde",
	      "Amara",
	      "Bolanle"
	    ],
	    "male_names": [
	      "Chinedu",
	      "Emeka",
	      "Oluwaseun",
	      "Ibrahim",
	      "Babatunde",
	      "Musa",
	      "Kayode",
	      "Obinna",
	      "Tunde",
	      "Yakubu"
	    ],
	    "surnames": [
	      "Okafor",
	      "Adeyemi",
	      "Bello",
	      "Eze",
	      "Abubakar",
	      "Okonkwo",
	      "Balogun",
	      "Nwosu",
	      "Mohammed",
	      "Ogunleye"
	    ],
	    "class_distribution": {
	      "extreme_poor": 28,
	      "low": 42,
	      "middle": 22,
	      "high": 6,
	      "elite": 2
	    },
	    "birth_report_text": "Dünyanın en genç ve en dinamik nüfuslarından birine sahip Nijerya'da (%2.8) doğdun. Altyapı kesintileri ve erken yaş hastalık riskleri yüksek; ancak Lagos'un ticaret enerjisi, Nollywood ve teknoloji rönesansı sana beklenmedik kapılar açabilir.",
	    "local_events": [
	      {
	        "id": "ng_nepa_elektrik_ve_jenerator",
	        "title": "NEPA Kesintisi ve Gece Yarısı Jeneratör Gürültüsü",
	        "category": "egitim",
	        "vignette": "tech",
	        "context_note": "Nijerya'da kronik elektrik kesintileri arasında sınavlara ve kodlamaya hazırlanma mücadelesi.",
	        "text": "Mahallede elektrikler yine kesildi ('NEPA took light'). Yarın çok önemli bir sınavın ve teslim etmen gereken yazılım projesi var; dışarıda sadece varlıklı komşunun jeneratörü çalışıyor.",
	        "min_age": 13,
	        "max_age": 24,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Komşunun kapısını çalıp bahçe ışığının altında sabaha kadar çalışmak için izin iste",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Komşun azmine hayran kaldı; hem sınavı geçtin hem de sana eski dizüstü bilgisayarını hediye etti.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 12,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "azimli_ogrenci"
	            ],
	            "remove_tags": [],
	            "add_trait": "Yılmaz",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Harçlıklarını birleştirip küçük bir güneş paneli ve akü sistemi kur",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 58
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahalledeki telefonları da ücretle şarj ederek ilk ticari gelirini elde ettin!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 14,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 900,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "gunes_girisimcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Karanlıkta çalışmayı bırakıp uyu",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Dinlendin ama derslerde geride kaldın.",
	            "effects": {
	              "health": 4,
	              "happiness": 0,
	              "smart": -6,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ng_yaba_silikon_lagunu",
	        "title": "Yaba 'Yabacon Valley' Fintech Rönesansı",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Lagos'un Yaba bölgesinde Afrika'nın en hızlı büyüyen mobil ödeme ve teknoloji ekosistemi.",
	        "text": "Lagos trafiğinde saatlerce süren yolculuklardan sonra Yaba'daki bir teknoloji kuluçka merkezinde mobil ödeme uygulaması geliştiren bir ekiple tanıştın.",
	        "min_age": 19,
	        "max_age": 40,
	        "weight": 86,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gece gündüz kod yazarak Afrika çapında mikro-ödeme altyapısı kur",
	            "lock_reason": "Zeka En Az 66 Olmalı",
	            "req_stats": {
	              "smart": 66
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Girişimin Londra ve Silikon Vadisi fonlarından yatırım aldı; Lagos'un parlayan yıldızı oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 12,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 8500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "fintech_kurucusu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Pazarlama ve saha operasyonlarını üstlenerek esnafı sisteme dahil et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sokak ticaretini dijitalleştirerek sağlam bir komisyon geliri elde ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ng_nollywood_set_firsati",
	        "title": "Nollywood Film Setinde Beklenmedik Rol",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "Dünyanın en çok film üreten ikinci sinema endüstrisi Nollywood'un baş döndürücü hızı.",
	        "text": "Surulere'de bir film çekimi sırasında yardımcı oyunculardan biri sete gelmedi. Yönetmen kalabalığın içinden seni işaret ederek 'Sen! Kameranın karşısına geç, bu sahneyi bugün çekmeliyiz!' diye bağırıyor.",
	        "min_age": 17,
	        "max_age": 45,
	        "weight": 78,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kamera karşısına geçip tüm duygularınla doğaçlama bir tirat at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sahnen sosyal medyada viral oldu! Peş peşe dizi ve sinema teklifleri almaya başladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 25,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "nollywood_yildizi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Karizmatik",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kamera önü yerine senaryo ve prodüksiyon ekibine girmeyi teklif et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yapım mutfağında kalarak sektörde kalıcı bir yönetmen yardımcısı oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 8,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ng_sitma_ve_klinik_mucadelesi",
	        "title": "Muson Yağmurları ve Ağır Sıtma Ateşi",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "Batı Afrika'da yağmur mevsiminde sivrisinek kaynaklı sıtma salgınları ve sahte ilaç tehlikesi.",
	        "text": "Günlerdir süren sağanak yağışların ardından yüksek ateş ve titremeyle yatağa düştün. Mahalledeki ruhsatsız büfe ucuz ilaç satarken, gerçek hastane kliniği oldukça pahalı.",
	        "min_age": 4,
	        "max_age": 65,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Paraya kıyıp onaylı hastane kliniğinde gerçek sıtma tedavisi gör",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kısa sürede ateşin düştü ve sağlığına tamamen kavuştun.",
	            "effects": {
	              "health": 15,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -600,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sokaktaki ucuz ve denetimsiz ilaçları kullan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlaçlar sahte çıktı! Böbreklerin ve genel sağlığın ağır hasar aldı.",
	            "effects": {
	              "health": -28,
	              "happiness": -14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ng_balogun_pazari_ticareti",
	        "title": "Balogun Pazarında İthalat ve Kumaş Ticareti",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Lagos'un devasa açık hava pazarlarında dönen milyon dolarlık kayıt dışı ticaret.",
	        "text": "Akraban Balogun pazarında renkli Ankara kumaşları ve elektronik eşya tezgahı açıyor. Sermaye koyup ortak olmanı veya gümrük işlerini takip etmeni istiyor.",
	        "min_age": 18,
	        "max_age": 55,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ortaklığa gir ve dürüst esnaflıkla toptan dağıtım ağı kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 800,
	            "req_tags": [],
	            "outcome_text": "Batı Afrika ülkelerine kumaş ihraç eden saygın bir tüccar oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 6,
	              "money_flat": 4800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "pazar_tuccari"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Gümrük memurlarına rüşvet verip kaçak konteyner sokmaya çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Baskında mallara el konuldu, elindeki sermayeyi de kaybettin.",
	            "effects": {
	              "health": 0,
	              "happiness": -16,
	              "smart": 0,
	              "reputation": -14,
	              "sanity": 0,
	              "karma": -12,
	              "money_flat": -2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ng_japa_goc_dalgasi",
	        "title": "'Japa' Dalgası: İngiltere veya Kanada'ya Göç Arayışı",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Nijeryalı gençler arasında ekonomik zorluklardan çıkıp yurtdışına gitmeyi ifade eden 'Japa' hareketi.",
	        "text": "Üniversiteden mezun olan arkadaşlarının yarısı IELTS sınavına girip İngiltere veya Kanada'ya sağlık/bilişim vizesiyle gitmeye ('Japa') hazırlanıyor.",
	        "min_age": 21,
	        "max_age": 38,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "NG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Dil ve meslek yeterlilik sınavlarını geçip yasal çalışma vizesine başvur",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 64
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uluslararası standartlarda bir uzman olarak yurtdışı kapılarını araladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 10,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "japa_hazirligi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ülkede kalıp Nijerya'nın kalkınması için yerel girişimlere liderlik et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zorluklara rağmen kendi topraklarında kök salıp binlerce kişiye ilham verdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 14,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "KR": {
	    "code": "KR",
	    "name": "Güney Kore",
	    "flag": "🇰🇷",
	    "currency_symbol": "₩",
	    "exchange_rate_to_usd": 1380.0,
	    "global_pop_pct": 0.65,
	    "spawn_weight": 6.0,
	    "life_expectancy": 84,
	    "gdp_per_capita_usd": 33500,
	    "inflation_rate": 0.028,
	    "tax_rate": 0.25,
	    "annual_living_cost_usd": 15000,
	    "uni_tuition_usd": 6500,
	    "base_health_index": 86,
	    "cities": [
	      "Seul",
	      "Busan",
	      "Incheon",
	      "Daegu",
	      "Daejeon",
	      "Gwangju"
	    ],
	    "female_names": [
	      "Seo-yeon",
	      "Ji-woo",
	      "Ha-yoon",
	      "Seo-yun",
	      "Min-seo",
	      "Ji-min",
	      "Chae-won",
	      "Soo-ah",
	      "Eun-ji",
	      "Hye-jin"
	    ],
	    "male_names": [
	      "Min-jun",
	      "Seo-jun",
	      "Do-yun",
	      "Ye-jun",
	      "Si-woo",
	      "Ha-jun",
	      "Ji-ho",
	      "Jun-seo",
	      "Tae-hyung",
	      "Jung-kook"
	    ],
	    "surnames": [
	      "Kim",
	      "Lee",
	      "Park",
	      "Choi",
	      "Jung",
	      "Kang",
	      "Cho",
	      "Yoon",
	      "Jang",
	      "Lim"
	    ],
	    "class_distribution": {
	      "extreme_poor": 5,
	      "low": 25,
	      "middle": 50,
	      "high": 15,
	      "elite": 5
	    },
	    "birth_report_text": "Teknoloji ve popüler kültür devi Güney Kore'de (%0.65) doğdun. Gece 22:00'ye kadar süren 'Hagwon' dershaneleri, uçakların bile rotasını değiştiren Suneung sınavı ve Chaebol holdinglerine girme yarışı seni bekliyor.",
	    "local_events": [
	      {
	        "id": "kr_hagwon_ve_suneung",
	        "title": "Hagwon Gece Mesaisi ve Suneung Sınav Cehennemi",
	        "category": "egitim",
	        "vignette": "exam",
	        "context_note": "Güney Kore'de SKY (Seoul, Korea, Yonsei) üniversitelerine girmek için verilen amansız mücadele.",
	        "text": "Saat gece 22:30. Gangnam'daki 'Hagwon' (özel dershane) sokağı yeni dağılıyor. Yarın tüm ülkede uçuşların bile sessizlik için durdurulduğu Suneung sınavı var.",
	        "min_age": 17,
	        "max_age": 19,
	        "weight": 95,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Günde 4 saat uykuyla hazırlandığın sınavda SKY üniversitelerinden birini kazan",
	            "lock_reason": "SKY Üniversiteleri İçin Zeka 74+ Gerekli",
	            "req_stats": {
	              "smart": 74
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ailen sevinçten ağlıyor; ülkenin en prestijli akademik elitleri arasına girdin!",
	            "effects": {
	              "health": -8,
	              "happiness": 18,
	              "smart": 14,
	              "reputation": 25,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "sky_mezunu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sınav yerine E-Spor veya K-Pop stajyer (Trainee) seçmelerine katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Geleneksel yolu terk edip sahne ve ekran dünyasının acımasız kampına adım attın.",
	            "effects": {
	              "health": -6,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 15,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kpop_espor_trainee"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Normal bir üniversiteye yerleşip akıl sağlığını koru",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "SKY olmasa da dengeli bir gençlik geçirme şansı yakaladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "kr_chaebol_mulakati",
	        "title": "Chaebol Holding Giriş Sınavı (Samsung / Hyundai)",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Güney Kore ekonomisini domine eden dev aile holdinglerine (Chaebol) girme yarışı.",
	        "text": "Binlerce adayın katıldığı yazılı yetenek sınavını geçtin ve Seul'deki cam gökdelenin 42. katında Chaebol yöneticilerinin karşısındasın.",
	        "min_age": 22,
	        "max_age": 32,
	        "weight": 88,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Üstün analitik zekan ve dil becerinle Chaebol yönetici adaylığına kabul edil",
	            "lock_reason": "Zeka En Az 70 Olmalı",
	            "req_stats": {
	              "smart": 70
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ülkenin en gıpta edilen kurumsal kimlik kartını boynuna astın; maaşın ve prestijin zirvede!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 7500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "chaebol_yoneticisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Holding baskısını reddedip Pangyo Teknovadisi'nde yenilikçi bir girişime katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Daha esnek ve özgür bir çalışma ortamında kendi hisselerine sahip oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "kr_dmz_askerlik",
	        "title": "DMZ Sınır Hattında 18 Aylık Zorunlu Askerlik",
	        "category": "askerlik",
	        "vignette": "military",
	        "context_note": "Kuzey Kore sınırındaki Silahsızlandırılmış Bölge (DMZ) yakınlarında zorunlu askerlik görevi.",
	        "text": "Kış ortasında askeri birliğe teslim oldun. Dondurucu soğukta Kuzey sınırına bakan gözetleme kulesinde 18 aylık zorlu nöbetin başlıyor.",
	        "min_age": 19,
	        "max_age": 27,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [
	            "askerlik_yapti"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Görevini üstün başarıyla tamamla ve teknoloji/siber birimde uzmanlaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem bedensel hem de teknik olarak güçlenerek terhis oldun.",
	            "effects": {
	              "health": 8,
	              "happiness": 0,
	              "smart": 6,
	              "reputation": 14,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kışladaki sert hiyerarşiye direnirken disiplin cezası al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zorlu ve yıpratıcı bir sürecin ardından nihayet sivil hayata döndün.",
	            "effects": {
	              "health": 0,
	              "happiness": -12,
	              "smart": 0,
	              "reputation": -6,
	              "sanity": -12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "kr_jeonse_konut_krizi",
	        "title": "Seul'de 'Jeonse' Depozitosu ve Konut Krizi",
	        "category": "ekonomi",
	        "vignette": "home",
	        "context_note": "Güney Kore'ye özgü, kira yerine ev değerinin %60-70'ini ev sahibine toplu depozito (Jeonse) olarak verme sistemi.",
	        "text": "Seul'de tuttuğun dairenin sahibi, yüksek 'Jeonse' depozitosunu emlak piyasası düştüğü için zamanında iade edemeyeceğini söylüyor!",
	        "min_age": 24,
	        "max_age": 55,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hukuki teminat sigortasını devreye sokup paranı yasal yoldan kurtar",
	            "lock_reason": "Hukuki Öngörü İçin Zeka 60+ Gerekli",
	            "req_stats": {
	              "smart": 60
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Önceden yaptırdığın Jeonse sigortası seni büyük bir iflastan kurtardı.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ev sahibiyle uzlaşıp yarı-kira (Wolse) modeline geç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bütçen biraz sarsılsa da sokakta kalmadan krizi yönetmeyi başardın.",
	            "effects": {
	              "health": 0,
	              "happiness": -6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -6,
	              "karma": 0,
	              "money_flat": -1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "kr_dis_gorunus_ve_ozgecmis",
	        "title": "Özgeçmiş Fotoğrafı ve Görünüm Rekabeti",
	        "category": "kariyer",
	        "vignette": "love",
	        "context_note": "Güney Kore iş başvurularında görünümün ve kusursuz profil fotoğrafının yarattığı sosyal baskı.",
	        "text": "Başvuracağın medya ve kurumsal şirketler özgeçmişte profesyonel stüdyo portresi istiyor. Arkadaşların mülakat öncesi küçük estetik dokunuşlar yaptırmanın şart olduğunu savunuyor.",
	        "min_age": 20,
	        "max_age": 40,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Doğal görünümünü koru, mülakatta yetkinliklerin ve özgüveninle fark yarat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Özgün duruşun jüri başkanının dikkatini çekti ve saygı topladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 10,
	              "karma": 6,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Gangnam'da profesyonel bakım ve imaj yenileme paketine bütçe ayır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 1800,
	            "req_tags": [],
	            "outcome_text": "Görsel sunumun kusursuzlaştı; sosyal çevrede özgüvenin arttı.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "kr_han_nehri_gece_piknigi",
	        "title": "Han Nehri Kıyısında Gece Yarısı Ramyeon ve Sohbet",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "Seul'ün ortasından geçen Han Nehri kıyısında stresli şehir hayatına verilen küçük mola.",
	        "text": "Yoğun bir haftanın sonunda Han Nehri kıyısında hazır ramyeon yapıp şehir ışıklarını izliyorsun. Yan masadaki genç müzisyenlerle derin bir sohbet başlıyor.",
	        "min_age": 18,
	        "max_age": 65,
	        "weight": 70,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "KR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Dostluk kur ve hafta sonları bağımsız kültür-sanat kulübüne katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Seul'ün rekabetçi temposu içinde nefes alacağın sıcak bir topluluk buldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 6,
	              "sanity": 15,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sessizce nehir esintisini dinleyip gelecek planlarını not defterine yaz",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zihnin berraklaştı, yeni haftaya yenilenmiş olarak başladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 5,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "BR": {
	    "code": "BR",
	    "name": "Brezilya",
	    "flag": "🇧🇷",
	    "currency_symbol": "R$",
	    "exchange_rate_to_usd": 5.6,
	    "global_pop_pct": 2.7,
	    "spawn_weight": 10.0,
	    "life_expectancy": 76,
	    "gdp_per_capita_usd": 10200,
	    "inflation_rate": 0.05,
	    "tax_rate": 0.27,
	    "annual_living_cost_usd": 5500,
	    "uni_tuition_usd": 1200,
	    "base_health_index": 77,
	    "cities": [
	      "São Paulo",
	      "Rio de Janeiro",
	      "Brasília",
	      "Salvador",
	      "Belo Horizonte",
	      "Curitiba",
	      "Recife"
	    ],
	    "female_names": [
	      "Helena",
	      "Alice",
	      "Laura",
	      "Maria",
	      "Valentina",
	      "Heloísa",
	      "Clara",
	      "Beatriz",
	      "Camila",
	      "Juliana"
	    ],
	    "male_names": [
	      "Miguel",
	      "Arthur",
	      "Gael",
	      "Heitor",
	      "Theo",
	      "Davi",
	      "Gabriel",
	      "Bernardo",
	      "Lucas",
	      "Mateus"
	    ],
	    "surnames": [
	      "Silva",
	      "Santos",
	      "Oliveira",
	      "Souza",
	      "Rodrigues",
	      "Ferreira",
	      "Alves",
	      "Pereira",
	      "Lima",
	      "Gomes"
	    ],
	    "class_distribution": {
	      "extreme_poor": 16,
	      "low": 38,
	      "middle": 32,
	      "high": 10,
	      "elite": 4
	    },
	    "birth_report_text": "Samba ritmi, futbol tutkusu ve Amazon ormanlarının ülkesi Brezilya'da (%2.7) doğdun. Favela (gecekondu) mahalleleri ile yüksek duvarlı lüks rezidanslar arasındaki keskin uçurumda kendi yolunu çizeceksin.",
	    "local_events": [
	      {
	        "id": "br_sokak_futbolu_kestimi",
	        "title": "Tozlu Sahada Yetenek Avcısı (Olheiro)",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Brezilya sokaklarında yalınayak oynanan futboldan dünya kulüplerine uzanan keşif hikayeleri.",
	        "text": "Mahallenin beton sahasında güneş batana kadar top koştururken, saha kenarında elinde not defteriyle duran São Paulo altyapı gözlemcisi seni yanına çağırdı.",
	        "min_age": 11,
	        "max_age": 19,
	        "weight": 88,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Altyapı seçmelerine katıl ve tüm enerjini profesyonel futbola ver",
	            "lock_reason": "Sağlık/Kondisyon En Az 65 Olmalı",
	            "req_stats": {
	              "health": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Muhteşem bilek hareketlerinle akademiye kabul edildin; profesyonel sözleşme imzaladın!",
	            "effects": {
	              "health": 12,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "futbol_akademisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Futbolu hobi olarak bırakıp ENEM (Üniversite Sınavı) bursuna odaklan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Daha güvenli bir akademik kariyer rotasını seçtin.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 12,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "akademik_odak"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "br_favela_cete_ve_muzik",
	        "title": "Favela Sokağında Yol Ayrımı: Ritim mi, Çete mi?",
	        "category": "suc",
	        "vignette": "music",
	        "context_note": "Dar gelirli mahallelerde gençlerin suç örgütleri ile toplumsal sanat projeleri arasındaki seçimi.",
	        "text": "Mahalledeki silahlı grup sana 'sadece gözcülük yaparak' haftalık yüksek nakit teklif ediyor; aynı sokaktaki toplum merkezi ise gençlik perküsyon ve kodlama atölyesi açtı.",
	        "min_age": 13,
	        "max_age": 23,
	        "weight": 86,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [
	            "extreme_poor",
	            "low"
	          ],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Toplum merkezine katıl; müzik ve yazılımla mahallenin sesi ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uluslararası bir vakıftan burs kazandın ve suç batağından uzak durdun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 12,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 15,
	              "money_flat": 1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "toplum_lideri"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Çetenin kolay para teklifini kabul edip sokak köşesinde gözcülük yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Cebin sıcak para gördü ama polis baskınları ve çatışma korkusu hayatına yerleşti.",
	            "effects": {
	              "health": 0,
	              "happiness": -8,
	              "smart": 0,
	              "reputation": -15,
	              "sanity": -14,
	              "karma": -20,
	              "money_flat": 3200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "cete_baglantisi",
	              "sabikali"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 3,
	              "event_id": "arc_crime_2",
	              "origin_note": "Gençliğinde sokak çetesiyle kurduğun karanlık bağın devamı olarak"
	            }
	          }
	        ]
	      },
	      {
	        "id": "br_rio_karnavali_kortej",
	        "title": "Rio Karnavalı ve Sambadrome Işıkları",
	        "category": "aile",
	        "vignette": "art",
	        "context_note": "Dünyanın en büyük sokak festivali Rio Karnavalı'nda mahalle samba okulunun geçidi.",
	        "text": "Aylarca süren hazırlıkların ardından Sambadrome'da davullar gürlüyor! Mahallenin samba okulu kostüm ve koreografi tasarımında senin desteğine ihtiyaç duyuyor.",
	        "min_age": 16,
	        "max_age": 70,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Korteje katıl, tasarım ve organizasyonda öncülük et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Okulunuz jüri özel ödülünü kazandı; mahallede festival kahramanı oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 1100,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Karnaval boyunca turistlere rehberlik ve ticaret yaparak gelir elde et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Festival haftasını yüksek kazançla kapattın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2600,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "br_amazon_ekoloji_gorevi",
	        "title": "Amazon Yağmur Ormanlarında Kaçak Kesim İhbarı",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "Dünyanın akciğerleri sayılan Amazonlar'da çevre savunucuları ile yasadışı kereste baronlarının çatışması.",
	        "text": "Bölgesel bir sivil toplum kuruluşuyla yürüttüğün saha çalışmasında, koruma altındaki yağmur ormanlarında yasadışı altın ve kereste şebekesinin izlerine rastladın.",
	        "min_age": 21,
	        "max_age": 58,
	        "weight": 78,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Uydu koordinatlarını federal çevre polisine (IBAMA) ve basına sızdır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Operasyonla şebeke çökertildi! Tehditler alsan da doğayı korumanın onurunu yaşadın.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": -4,
	              "karma": 22,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "amazon_koruyucusu"
	            ],
	            "remove_tags": [],
	            "add_trait": "Cesur",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tehlikeye bulaşmadan sessizce şehre geri dön",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Can güvenliğin korundu ama vicdanında buruk bir sızı kaldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 2,
	              "karma": -8,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "br_concurso_publico_sinavi",
	        "title": "Concurso Público: Ömür Boyu Memuriyet Yarışı",
	        "category": "kariyer",
	        "vignette": "exam",
	        "context_note": "Brezilya'da yüksek maaş ve iş güvencesi sunan federal kamu sınavları (Concurso).",
	        "text": "Ekonomik dalgalanmalardan korunmak için yüz binlerce aday gibi sen de federal yargı ve maliye bakanlığının 'Concurso Público' sınavına girdin.",
	        "min_age": 20,
	        "max_age": 42,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Dereceye girerek federal kamu kadrosuna atan",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Brezilya'da ulaşılması en zor istikrar ve maaş güvencesine kavuştun!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 18,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 5200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "federal_memur"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Özel sektörde serbest girişimcilikle şansını dene",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bürokrasiden uzak, kendi ritminde bir iş hayatı kurdun.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "br_copacabana_firtinasi",
	        "title": "Atlantik Kıyısında Dostluk ve Hayat Felsefesi",
	        "category": "felsefe",
	        "vignette": "love",
	        "context_note": "Brezilya'nın 'Saudade' (derin özlem ve yaşama sevinci) duygusu.",
	        "text": "Gün batımında okyanus kıyısında hindistancevizi suyu içerken eski bir çocukluk aşkınla yıllar sonra karşılaştın.",
	        "min_age": 20,
	        "max_age": 65,
	        "weight": 70,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "BR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Geçmişin kırgınlıklarını onarıp yeniden sıcak bir bağ kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yılların özlemi dindi; kalbin yeniden umutla doldu.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 6,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Güzel bir tebessümle vedalaşıp kendi yoluna devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Geçmişle barıştın ve önüne huzurla baktın.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "DE": {
	    "code": "DE",
	    "name": "Almanya",
	    "flag": "🇩🇪",
	    "currency_symbol": "€",
	    "exchange_rate_to_usd": 0.92,
	    "global_pop_pct": 1.0,
	    "spawn_weight": 7.0,
	    "life_expectancy": 81,
	    "gdp_per_capita_usd": 52800,
	    "inflation_rate": 0.025,
	    "tax_rate": 0.36,
	    "annual_living_cost_usd": 18500,
	    "uni_tuition_usd": 300,
	    "base_health_index": 89,
	    "cities": [
	      "Berlin",
	      "Münih",
	      "Hamburg",
	      "Frankfurt",
	      "Köln",
	      "Stuttgart",
	      "Heidelberg"
	    ],
	    "female_names": [
	      "Emilia",
	      "Mia",
	      "Hannah",
	      "Sophia",
	      "Lina",
	      "Mila",
	      "Clara",
	      "Lea",
	      "Marie",
	      "Johanna"
	    ],
	    "male_names": [
	      "Noah",
	      "Matteo",
	      "Elias",
	      "Leon",
	      "Paul",
	      "Lukas",
	      "Finn",
	      "Felix",
	      "Maximilian",
	      "Jonas"
	    ],
	    "surnames": [
	      "Müller",
	      "Schmidt",
	      "Schneider",
	      "Fischer",
	      "Weber",
	      "Meyer",
	      "Wagner",
	      "Becker",
	      "Schulz",
	      "Hoffmann"
	    ],
	    "class_distribution": {
	      "extreme_poor": 3,
	      "low": 20,
	      "middle": 58,
	      "high": 15,
	      "elite": 4
	    },
	    "birth_report_text": "Avrupa'nın sanayi ve mühendislik kalbi Almanya'da (%1.0) doğdun. Ücretsiz üniversiteler, güçlü sendikalar ve düzenli bir sistem seni bekliyor; ancak erken yaşta yapılan 'Gymnasium vs. Ausbildung' ayrımı ve katı bürokrasi (Ordnung) hayatına yön verecek.",
	    "local_events": [
	      {
	        "id": "de_ausbildung_vs_abitur",
	        "title": "Abitur mu, Duale Ausbildung (Çiftli Meslek Eğitimi) mi?",
	        "category": "egitim",
	        "vignette": "work",
	        "context_note": "Alman eğitim sisteminin 16-18 yaşlarında sunduğu akademik üniversite veya maaşlı sanayi uzmanlığı ayrımı.",
	        "text": "Okul danışmanın önünde iki dosya tutuyor: Ya Abitur sınavıyla teorik üniversite eğitimine gideceksin ya da dev bir otomotiv fabrikasında maaşlı 'Ausbildung' programına başlayacaksın.",
	        "min_age": 16,
	        "max_age": 19,
	        "weight": 92,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Abitur'u tamamlayıp Teknik Üniversite'de (TU) Mühendislik oku",
	            "lock_reason": "Zeka En Az 62 Olmalı",
	            "req_stats": {
	              "smart": 62
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ücretsiz ve dünya çapında bir mühendislik eğitimine adım attın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 14,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "tag_muhendislik_diplomasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Otomotiv ve mekatronik alanında 'Duale Ausbildung' programına katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Daha 18 yaşında kendi maaşını kazanmaya ve usta (Meister) unvanına yürümeye başladın!",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 8,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "meister_adayi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "de_burokrasi_ve_finanzamt",
	        "title": "Finanzamt Mektubu ve Alman Bürokrasisi Sınavı",
	        "category": "ekonomi",
	        "vignette": "court",
	        "context_note": "Almanya'da hala faks ve sarı zarflarla işleyen katı vergi ve belediye bürokrasisi.",
	        "text": "Posta kutuna Vergi Dairesi'nden (Finanzamt) 14 sayfalık ağır bürokratik Almancayla yazılmış bir beyanname denetimi geldi. Son teslim tarihi yarın!",
	        "min_age": 22,
	        "max_age": 65,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Tüm faturalarını klasörleyip vergi danışmanıyla (Steuerberater) zamanında teslim et",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 55
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Denetimden kusursuz geçtin; üstelik 2.400 € vergi iadesi aldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 2400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "Düzenli",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Mektubu görmezden gel ve geciktir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Gecikme faizi ve idari ceza kesildi; Alman bürokrasisiyle şaka olmayacağını öğrendin.",
	            "effects": {
	              "health": 0,
	              "happiness": -10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": -1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "de_mittelstand_muhendislik",
	        "title": "Mittelstand: Gizli Dünya Şampiyonu Şirkette Yenilik",
	        "category": "kariyer",
	        "vignette": "science",
	        "context_note": "Almanya'nın kasabalarda faaliyet gösteren ama kendi alanında dünya lideri olan orta ölçekli sanayi şirketleri.",
	        "text": "Baden-Württemberg'de çalıştığın hassas optik ve robotik firmasında, üretimi %30 hızlandıracak bir patent fikri geliştirdin.",
	        "min_age": 24,
	        "max_age": 55,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Alman Çalışan Buluşları Yasası kapsamında patenti şirketle tescille",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem AR-GE direktörlüğüne terfi ettin hem de her satıştan yasal prim almaya başladın!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 10,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 7500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "patent_sahibi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tasarımı açık kaynak olarak küresel mühendislik topluluğuyla paylaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Maddi getirin az olsa da bilim dünyasında büyük saygınlık kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 15,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "de_berlin_kultur_ve_kira",
	        "title": "Berlin'de Sanat Kolektifi ve Kira Tavanı Mücadelesi",
	        "category": "aile",
	        "vignette": "home",
	        "context_note": "Berlin'in alternatif kültür sahnesi ile hızla artan konut kiraları arasındaki gerilim.",
	        "text": "Kreuzberg'de yıllardır uygun kirayla oturduğun apartman uluslararası bir emlak fonuna satıldı. Kiracılar birliği (Mieterverein) direniş başlatıyor.",
	        "min_age": 20,
	        "max_age": 50,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kiracılar Derneği avukatlarıyla mahkemeye başvur ve hakkını ara",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahkeme fahiş kira artışını iptal etti; evini ve mahalle kültürünü korudun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 10,
	              "karma": 8,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Taşınma tazminatını (Abfindung) alıp banliyöye taşın",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Toplu nakit tazminat aldın ama şehrin kalbinden uzaklaştın.",
	            "effects": {
	              "health": 0,
	              "happiness": -2,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "de_autobahn_ve_endustri_donusumu",
	        "title": "Otomotiv Devrimi ve Sendika Grevi (IG Metall)",
	        "category": "kariyer",
	        "vignette": "protest",
	        "context_note": "Elektrikli araç dönüşümü sırasında Alman sanayi işçilerinin hak mücadelesi.",
	        "text": "Çalıştığın tesiste yönetim vardiya saatlerini artırmak istiyor. Sendika 24 saatlik uyarı grevi ve toplu sözleşme masası kurdu.",
	        "min_age": 22,
	        "max_age": 60,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "İşyeri konseyi (Betriebsrat) temsilcisi olarak müzakereyi yönet",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Haftalık 35 saat çalışma hakkını ve enflasyon zammını kazandınız!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 12,
	              "money_flat": 2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "sendika_temsilcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tartışmalardan uzak durup kendi bireysel sözleşmeni müzakere et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sessizce maaşını artırdın.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "de_noel_pazari_dayanisma",
	        "title": "Weihnachtsmarkt Işıkları ve Kültürlerarası Dostluk",
	        "category": "felsefe",
	        "vignette": "family",
	        "context_note": "Aralık ayında kurulan geleneksel Noel pazarlarında sıcak şarap/elma suyu ve komşuluk.",
	        "text": "Kar yağışı altında kurulan ahşap kulübelerin önünde, Türkiye ve Suriye'den yeni göç etmiş komşu bir ailenin dil engeli nedeniyle belediye evraklarında zorlandığını gördün.",
	        "min_age": 18,
	        "max_age": 80,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "DE"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gönüllü tercümanlık yapıp entegrasyon süreçlerine destek ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yeni komşularınla ömürlük bir dostluk kurdun; mahallede örnek gösterildin.",
	            "effects": {
	              "health": 0,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 10,
	              "karma": 16,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "Yardımsever",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sıcak içeceğini alıp kendi arkadaşlarınla sohbete devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Keyifli bir kış akşamı geçirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "IN": {
	    "code": "IN",
	    "name": "Hindistan",
	    "flag": "🇮🇳",
	    "currency_symbol": "₹",
	    "exchange_rate_to_usd": 84.0,
	    "global_pop_pct": 17.7,
	    "spawn_weight": 18.0,
	    "life_expectancy": 71,
	    "gdp_per_capita_usd": 2700,
	    "inflation_rate": 0.055,
	    "tax_rate": 0.2,
	    "annual_living_cost_usd": 2200,
	    "uni_tuition_usd": 900,
	    "base_health_index": 72,
	    "cities": [
	      "Mumbai",
	      "Yeni Delhi",
	      "Bengaluru",
	      "Haydarabad",
	      "Chennai",
	      "Kalküta",
	      "Pune",
	      "Jaipur"
	    ],
	    "female_names": [
	      "Aadhya",
	      "Ananya",
	      "Diya",
	      "Pari",
	      "Saanvi",
	      "Priya",
	      "Kavya",
	      "Neha",
	      "Riya",
	      "Meera"
	    ],
	    "male_names": [
	      "Aarav",
	      "Vihaan",
	      "Aditya",
	      "Arjun",
	      "Rohan",
	      "Sai",
	      "Aryan",
	      "Kabir",
	      "Vikram",
	      "Rahul"
	    ],
	    "surnames": [
	      "Sharma",
	      "Verma",
	      "Patel",
	      "Kumar",
	      "Singh",
	      "Gupta",
	      "Reddy",
	      "Nair",
	      "Iyer",
	      "Joshi"
	    ],
	    "class_distribution": {
	      "extreme_poor": 22,
	      "low": 40,
	      "middle": 28,
	      "high": 7,
	      "elite": 3
	    },
	    "birth_report_text": "Dünyada doğan her 6 bebekten birinin gözlerini açtığı Hindistan'da (%17.7) dünyaya geldin! 1.4 milyar insanın nefes aldığı bu kıta-ülkede milyonlarca gencin yarıştığı JEE/IIT sınavları, geleneksel aile beklentileri ve Bengaluru'nun yazılım yükselişi seni bekliyor.",
	    "local_events": [
	      {
	        "id": "in_jee_iit_sinav_maratonu",
	        "title": "JEE Advanced: 1.5 Milyon Aday Arasında IIT Mücadelesi",
	        "category": "egitim",
	        "vignette": "exam",
	        "context_note": "Hindistan Teknoloji Enstitülerine (IIT) girmek için Kota şehrindeki hazırlık kamplarında verilen sınav savaşı.",
	        "text": "Sabah 04:30'da alarm çaldı. Seninle aynı sınava girecek 1.5 milyon gencin arasında ilk %1'lik dilime girersen Hindistan Teknoloji Enstitüsü (IIT) kapıları ve küresel teknoloji devleri açılacak.",
	        "min_age": 17,
	        "max_age": 19,
	        "weight": 95,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gece gündüz matematik ve fizik çözerek IIT Bilgisayar Mühendisliği'ni kazan!",
	            "lock_reason": "IIT İçin Zeka 76+ Gerekli",
	            "req_stats": {
	              "smart": 76
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mucizeyi başardın! Mahallede davullar çalındı, küresel teknoloji şirketleri şimdiden peşinde.",
	            "effects": {
	              "health": -6,
	              "happiness": 22,
	              "smart": 16,
	              "reputation": 28,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "iit_mezunu",
	              "tag_muhendislik_diplomasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Eyalet üniversitesinde mühendislik/işletme okuyup Bengaluru'da staja başla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Aşırı yıpranmadan sağlam bir mesleki temel attın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 9,
	              "reputation": 0,
	              "sanity": 4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sınav baskısını reddedip aile dükkanında ticaret ve baharat ihracatına gir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Akademik yarıştan çekilip çarşı ticaretinde ustalaştın.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "in_gorucu_usulu_ve_kast_ikilemi",
	        "title": "Aile Meclisi: Görücü Usulü Evlilik mi, Aşk mı?",
	        "category": "ask",
	        "vignette": "love",
	        "context_note": "Hindistan'da geleneksel aile onayı, yıldız haritası (Kundali) ve statü/kast kalıntıları.",
	        "text": "Anne ve baban elinde varlıklı ve saygın bir aileden gelen adayın özgeçmişiyle (Biodata) odana girdi. Oysa senin kalbin farklı bir sosyal çevreden gelen üniversite arkadaşında.",
	        "min_age": 22,
	        "max_age": 34,
	        "weight": 86,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [
	            "evli"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ailenin baskısına diren ve sevdiğin insanla kendi kararınla evlen",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Akrabaların bir kısmı düğüne gelmese de gerçek aşkınla özgür bir yuva kurdun.",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": -8,
	              "sanity": 12,
	              "karma": 8,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "evli",
	              "ask_evliligi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ailenin seçtiği varlıklı adayla tanışıp geleneksel görkemli bir düğün yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Üç gün süren renkli düğünle iki aile birleşti; yüksek çeyiz ve sermaye desteği aldın.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "evli",
	              "geleneksel_evlilik"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "in_bengaluru_it_yukselisi",
	        "title": "Bengaluru Silikon Platosu ve Küresel Yazılım İhracatı",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Hindistan'ın bilişim başkenti Bengaluru'da küresel yazılım merkezleri.",
	        "text": "Bengaluru'daki teknoloji parkında yürüttüğün bulut mimarisi projesi ABD ve Avrupa bankalarının dikkatini çekti. Kendi yazılım danışmanlık firmanı kurma şansın var.",
	        "min_age": 23,
	        "max_age": 48,
	        "weight": 84,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kendi yazılım ihracat şirketini kur ve 50 genç mühendisi işe al",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Dolar bazında gelir elde ederek Hindistan'ın yeni nesil teknoloji liderleri arasına girdin!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 10,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 7800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "it_girisimcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Çok uluslu şirkette kıdemli direktör olarak güvenli maaşla devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yüksek maaş ve istikrarlı bir kariyer çizgisi yakaladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "in_muson_seli_ve_dayanisma",
	        "title": "Mumbai Muson Yağmurları ve Dabbawala Dayanışması",
	        "category": "kriz",
	        "vignette": "crisis",
	        "context_note": "Şiddetli muson yağmurlarının metropol ulaşımını felç ettiği günler.",
	        "text": "Mumbai'de son 20 yılın en şiddetli muson yağmuru yağdı; banliyö trenleri durdu, sokaklar bel hizasına kadar suya gömüldü.",
	        "min_age": 14,
	        "max_age": 75,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Mahalledeki aşevleriyle birlikte yolda kalan binlerce insana sıcak yemek dağıt",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Felaket gününde sergilediğin dayanışma ruhunu yüceltti.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Evini ve dükkanını kum torbalarıyla su baskınına karşı koru",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Maddi hasarı en aza indirerek fırtınayı atlattın.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "in_kriket_tutkusu_ve_turnuva",
	        "title": "Stadyumda Kriket Finali ve Sponsorluk Fırsatı",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Hindistan'da bir spor olmaktan öte adeta bir tutku olan kriket kültürü.",
	        "text": "Yerel kriket turnuvasında sergilediğin performans veya organizasyon yeteneğin eyalet ligi yöneticilerinin dikkatini çekti.",
	        "min_age": 15,
	        "max_age": 38,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kulüp yönetimine ve spor pazarlamasına adım at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Turnuva sponsorluklarından yüksek gelir ve çevre kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 15,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sadece taraftar olarak dostlarınla maçın heyecanını yaşa",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Unutulmaz bir zafer gecesi kutladınız.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "in_ganj_kiyisinda_tefekkur",
	        "title": "Varanasi ve Ganj Kıyısında Işık Ritüeli (Ganga Aarti)",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "Binlerce yıllık felsefi geleneğin nehir kıyısında yankılanan ilahileri ve kandilleri.",
	        "text": "Akşam alacakaranlığında nehir kıyısında yüzlerce pirinç kandil yanıyor. Hayatın koşturmacası içinde neyin gerçekten değerli olduğunu sorguluyorsun.",
	        "min_age": 20,
	        "max_age": 88,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "IN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Bir süre inzivaya çekilip klasik felsefe ve meditasyon çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zihnindeki gürültü dindi; hayata bambaşka bir berraklıkla döndün.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 20,
	              "karma": 12,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Nehre bir çiçek ve kandil bırakıp sevdiklerin için dilek tut",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kalbinde derin bir şükran duygusu uyandı.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 6,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "EG": {
	    "code": "EG",
	    "name": "Mısır",
	    "flag": "🇪🇬",
	    "currency_symbol": "E£",
	    "exchange_rate_to_usd": 49.0,
	    "global_pop_pct": 1.4,
	    "spawn_weight": 7.0,
	    "life_expectancy": 72,
	    "gdp_per_capita_usd": 3800,
	    "inflation_rate": 0.28,
	    "tax_rate": 0.22,
	    "annual_living_cost_usd": 3100,
	    "uni_tuition_usd": 400,
	    "base_health_index": 74,
	    "cities": [
	      "Kahire",
	      "İskenderiye",
	      "Gize",
	      "Luksor",
	      "Asvan",
	      "Port Said"
	    ],
	    "female_names": [
	      "Mariam",
	      "Fatma",
	      "Nour",
	      "Salma",
	      "Habiba",
	      "Aya",
	      "Yasmine",
	      "Farida",
	      "Layla",
	      "Hana"
	    ],
	    "male_names": [
	      "Mohamed",
	      "Ahmed",
	      "Mahmoud",
	      "Omar",
	      "Youssef",
	      "Mustafa",
	      "Ali",
	      "Khaled",
	      "Tarek",
	      "Karim"
	    ],
	    "surnames": [
	      "El-Sayed",
	      "Hassan",
	      "Ibrahim",
	      "Mansour",
	      "Soliman",
	      "Abdel-Rahman",
	      "Farouk",
	      "Nasser",
	      "Zaki",
	      "Khalil"
	    ],
	    "class_distribution": {
	      "extreme_poor": 18,
	      "low": 40,
	      "middle": 30,
	      "high": 9,
	      "elite": 3
	    },
	    "birth_report_text": "Nil Nehri'nin ve piramitlerin yurdu Mısır'da (%1.4) doğdun. Binlerce yıllık tarih, Kahire'nin hiç uyumayan sokakları, Thanaweya Amma sınavı ve ekonomik devalüasyon dalgaları arasında yolunu bulacaksın.",
	    "local_events": [
	      {
	        "id": "eg_thanaweya_amma_sinavi",
	        "title": "Thanaweya Amma: Mısır'ın Kader Sınavı",
	        "category": "egitim",
	        "vignette": "exam",
	        "context_note": "Mısır'da tıp ve mühendislik fakültelerine (Kulliyat Al-Qimma) girmek için verilen ulusal lise sınavı.",
	        "text": "Kahire'nin sıcak yaz gününde bütün ailenin birikimi özel derslere harcandı. 'Thanaweya Amma' sınav sonucu açıklandığında mahallede ya zılgıtlar çalınacak ya da derin bir sessizlik çökecek.",
	        "min_age": 17,
	        "max_age": 19,
	        "weight": 92,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "%98 dilime girerek Kahire Üniversitesi Tıp veya Mühendislik Fakültesi'ni kazan",
	            "lock_reason": "Zeka En Az 70 Olmalı",
	            "req_stats": {
	              "smart": 70
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahallede büyük sevinç yaşandı; saygın bir mesleğin kapısını açtın!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 12,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "tag_muhendislik_diplomasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Yabancı dil ve turizm/arkeoloji bölümüne yerleş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mısır'ın eşsiz tarihsel mirasını dünyaya tanıtan uluslararası bir uzman olma yoluna girdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 8,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "arkeoloji_uzmani"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "eg_luksor_antik_kesif",
	        "title": "Nil Kıyısında Arkeolojik Kazı ve Tarihi Eser İkilemi",
	        "category": "kriz",
	        "vignette": "secret",
	        "context_note": "Mısır'da kazı alanlarında çıkan paha biçilmez antik eserlerin korunması veya karaborsaya sızdırılması.",
	        "text": "Luksor yakınlarında çalıştığın altyapı veya kazı projesinde toprağın altından mühürlü bir Geç Dönem firavun heykelciği çıktı. Gece vakti yabancı bir koleksiyoncu sana servet teklif ediyor.",
	        "min_age": 21,
	        "max_age": 58,
	        "weight": 84,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kaçakçıyı reddet ve eseri resmi tutanakla Büyük Mısır Müzesi'ne teslim et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bakanlık seni ödüllendirdi; adın ulusal gazetelerde dürüst vatansever olarak geçti!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 22,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "miras_koruyucusu"
	            ],
	            "remove_tags": [],
	            "add_trait": "Dürüst",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Heykelciği gizlice koleksiyoncuya sat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kısa vadede çantalar dolusu döviz aldın ama tarihi eser kaçakçılığı soruşturması peşini bırakmayacak!",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": -15,
	              "sanity": -14,
	              "karma": -25,
	              "money_flat": 11000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kacakci_suphelisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 3,
	              "event_id": "arc_crime_3",
	              "origin_note": "Luksor'da gizlice sattığın antik eserin uluslararası polis takibi"
	            }
	          }
	        ]
	      },
	      {
	        "id": "eg_shabka_evlilik_altini",
	        "title": "Shabka ve Daire Şartı: Kahire'de Evlilik Ekonomisi",
	        "category": "ask",
	        "vignette": "love",
	        "context_note": "Mısır'da evlenebilmek için damat ve gelin aileleri arasında yapılan çeyiz, altın (Shabka) ve ev müzakereleri.",
	        "text": "Sevdiğin insanla evlenmek istiyorsun; ancak aile büyükleri oturulacak dairenin tapusu ve yüksek gramajlı altın ('Shabka') olmadan nikaha onay vermeyeceklerini söylüyor.",
	        "min_age": 22,
	        "max_age": 38,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [
	            "evli"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Partnerinle el ele verip gösterişsiz, modern ve ortak bütçeli bir yuva kurun",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Geleneksel kalıpları kırarak borca batmadan mutlu bir evlilik başlattınız.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": -1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "evli"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ailelerin istediği tüm altın ve düğün şartlarını borçlanarak yerine getir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Görkemli bir düğün oldu ama yıllarca sürecek senet ödemeleri başladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": -4800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "evli",
	              "agir_borclu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "eg_suveys_ve_deniz_ticareti",
	        "title": "Süveyş Kanalı Lojistik ve Deniz Ticareti Fırsatı",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Dünya ticaretinin %12'sinin geçtiği Süveyş Kanalı limanlarındaki uluslararası gemicilik ağı.",
	        "text": "Port Said ve Süveyş liman bölgesinde uluslararası gemi tedarik ve lojistik acentesi kurma veya yönetme teklifi aldın.",
	        "min_age": 23,
	        "max_age": 55,
	        "weight": 78,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Döviz bazlı deniz lojistiği işine gir ve filoyu büyüt",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 60
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mısır lirasındaki devalüasyondan etkilenmeyen güçlü bir döviz geliri yakaladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 6200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "deniz_tuccari"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kahire'deki sabit maaşlı işinde kalmayı tercih et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Risk almadın ama enflasyon karşısında maaşın zorlandı.",
	            "effects": {
	              "health": 0,
	              "happiness": 2,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 900,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "eg_iskenderiye_kutuphanesi",
	        "title": "İskenderiye Kütüphanesi'nde Uluslararası Sempozyum",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Akdeniz kıyısında yeniden yükselen Bibliotheca Alexandrina kültür merkezi.",
	        "text": "İskenderiye'nin deniz kokulu esintisinde düzenlenen Akdeniz Bilim ve Edebiyat Buluşması'nda konuşmacı veya araştırmacı olarak yer alma şansı doğdu.",
	        "min_age": 19,
	        "max_age": 70,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Araştırma bildirini sun ve uluslararası akademisyenlerle ortak proje başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bilimsel çevren genişledi, ufkun açıldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 12,
	              "reputation": 15,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Dinleyici olarak katılıp İskenderiye sahilinde edebi denemeler yaz",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ruhunu dinlendiren verimli bir hafta geçirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "eg_ramazan_fenerleri_dayanisma",
	        "title": "Han el-Halili Sokaklarında Fanous Işıkları ve İftar Sofrası",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "Eski Kahire sokaklarında kurulan yüzlerce metrelik dayanışma sofraları (Maidat Al-Rahman).",
	        "text": "Akşam ezanı yaklaşırken Han el-Halili çarşısı renkli fenerlerle (Fanous) ışıldıyor. Mahalle esnafı dar gelirli aileler için büyük bir dayanışma sofrası kuruyor.",
	        "min_age": 15,
	        "max_age": 85,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "EG"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Maddi destek ver ve bizzat servis yaparak komşularınla ekmeğini paylaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahallede gönülleri fethettin; iç huzurun tavan yaptı.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": 10,
	              "karma": 18,
	              "money_flat": -400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ailenle evin balkonunda Nil manzarasına karşı sakin bir akşam geçir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sevdiklerinle huzurlu bir gece yaşadın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "CO": {
	    "code": "CO",
	    "name": "Kolombiya",
	    "flag": "🇨🇴",
	    "currency_symbol": "COP",
	    "exchange_rate_to_usd": 4200.0,
	    "global_pop_pct": 0.65,
	    "spawn_weight": 5.5,
	    "life_expectancy": 77,
	    "gdp_per_capita_usd": 7000,
	    "inflation_rate": 0.07,
	    "tax_rate": 0.23,
	    "annual_living_cost_usd": 4500,
	    "uni_tuition_usd": 1100,
	    "base_health_index": 78,
	    "cities": [
	      "Bogotá",
	      "Medellín",
	      "Cali",
	      "Cartagena",
	      "Barranquilla",
	      "Manizales"
	    ],
	    "female_names": [
	      "Valentina",
	      "Mariana",
	      "Isabella",
	      "Luciana",
	      "Gabriela",
	      "Camila",
	      "Valeria",
	      "Salomé",
	      "Daniela",
	      "Sara"
	    ],
	    "male_names": [
	      "Santiago",
	      "Mateo",
	      "Sebastián",
	      "Matías",
	      "Nicolás",
	      "Samuel",
	      "Alejandro",
	      "Diego",
	      "Daniel",
	      "Juan"
	    ],
	    "surnames": [
	      "Rodríguez",
	      "Gómez",
	      "González",
	      "Martínez",
	      "García",
	      "López",
	      "Hernández",
	      "Sánchez",
	      "Ramírez",
	      "Torres"
	    ],
	    "class_distribution": {
	      "extreme_poor": 15,
	      "low": 38,
	      "middle": 34,
	      "high": 10,
	      "elite": 3
	    },
	    "birth_report_text": "And Dağları'nın zümrüt yamaçları ve büyülü gerçekçiliğin ülkesi Kolombiya'da (%0.65) doğdun. Kahve tarlalarının emeği ve Medellín'in kentsel dönüşüm mucizesi ile yeraltı kartellerinin karanlık tuzakları arasında keskin ahlaki seçimler yapacaksın.",
	    "local_events": [
	      {
	        "id": "co_kahve_hasadi_ve_kooperatif",
	        "title": "And Yamaçlarında Kahve Hasadı ve Adil Ticaret",
	        "category": "ekonomi",
	        "vignette": "nature",
	        "context_note": "Kolombiya'nın dünyaca ünlü kahve üçgeninde (Eje Cafetero) üreticilerin aracılara karşı mücadelesi.",
	        "text": "Ailenin veya bölgedeki çiftçilerin binbir emekle topladığı birinci sınıf Arabica kahve çekirdeklerini, tekelci aracılar yok pahasına kapatmak istiyor.",
	        "min_age": 18,
	        "max_age": 55,
	        "weight": 86,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Üreticileri örgütleyip doğrudan Japonya ve Avrupa'daki butik kavuruculara ihraç et",
	            "lock_reason": "İhracat Ağı İçin Zeka 60+ Gerekli",
	            "req_stats": {
	              "smart": 60
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Aracıları devre dışı bıraktın! Bölge çiftçilerinin geliri üç katına çıktı, saygın bir ihracatçı oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 10,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 16,
	              "money_flat": 5400,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kahve_ihracatcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Aracıların verdiği düşük peşin parayı kabul et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Risk almadın ama emeğinin gerçek karşılığını alamadın.",
	            "effects": {
	              "health": 0,
	              "happiness": -4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1100,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "co_kartel_kurye_teklifi",
	        "title": "Karanlık Teklif: 'Tek Bir Bavul, Ömür Boyu Rahatlık'",
	        "category": "suc",
	        "vignette": "crime",
	        "context_note": "Kolombiya'da gençleri hızlı zenginlik vaadiyle tuzağa düşüren yeraltı şebekeleri.",
	        "text": "Lüks saatli ve güneş gözlüklü bir adam kafede yanına oturdu. 'Sadece bir kez Madrid uçağına bu bavulla bineceksin, döndüğünde kendi evini alırsın' diyor.",
	        "min_age": 18,
	        "max_age": 36,
	        "weight": 88,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [
	            "extreme_poor",
	            "low",
	            "middle"
	          ],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Masadan derhal kalk ve adamla tüm irtibatı kes",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Alnın açık, vicdanın rahat kaldı; özgürlüğünü hiçbir paraya değişmedin.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "temiz_sicil"
	            ],
	            "remove_tags": [],
	            "add_trait": "İlkeli",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Teklifi kabul et ve havalimanı kontrol noktasına yürü",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "X-Ray cihazında kırmızı ışık yandı! Uluslararası narkotik polisi kelepçeyi taktığında hayatın karardı.",
	            "effects": {
	              "health": -20,
	              "happiness": -35,
	              "smart": 0,
	              "reputation": -40,
	              "sanity": -30,
	              "karma": -25,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "sabikali",
	              "hapis_yatti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "co_medellin_inovasyon_merkezi",
	        "title": "Medellín Kentsel Dönüşüm ve Teleferik Kütüphanesi",
	        "category": "egitim",
	        "vignette": "tech",
	        "context_note": "Bir zamanlar dünyanın en tehlikeli şehriyken inovasyon başkentine dönüşen Medellín mucizesi.",
	        "text": "Comuna 13 mahallesinde açılan yürüyen merdivenler ve teleferik hattı sayesinde şehrin teknoloji ve tasarım merkezine tam burslu kabul edildin.",
	        "min_age": 15,
	        "max_age": 32,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yazılım ve kentsel mimari eğitimine katılıp mahalleni dönüştür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Projelerin Latin Amerika Kalkınma Bankası'ndan ödül kazandı!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 14,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3600,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kent_yenilikcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sokak sanatı (Grafiti) ve müzik turları düzenleyerek kültür turizmi başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mahallenin hikayesini dünyadan gelen gezginlere anlatarak hem kazandın hem de ilham verdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "co_cumbia_ve_buyulu_gercekcilik",
	        "title": "Cartagena Surlarında Edebiyat ve Cumbia Gecesi",
	        "category": "felsefe",
	        "vignette": "art",
	        "context_note": "Gabriel García Márquez'in topraklarında edebiyat, müzik ve büyülü gerçekçilik.",
	        "text": "Karayip Denizi kıyısındaki tarihi Cartagena surlarında düzenlenen edebiyat gecesinde, aile geçmişini anlatan öykü taslağın ünlü bir editörün eline geçti.",
	        "min_age": 19,
	        "max_age": 75,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gece gündüz çalışıp romanını tamamla ve yayımla",
	            "lock_reason": "Roman Yazımı İçin Zeka 64+ Gerekli",
	            "req_stats": {
	              "smart": 64
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kitabın İspanyolca konuşulan tüm ülkelerde çok satanlar listesine girdi!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 10,
	              "reputation": 24,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 4800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "edebiyat_yazari"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Öykülerini sadece dost meclislerinde anlatıp müziğin tadını çıkar",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Büyülü bir Karayip gecesinde ruhun dinlendi.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "co_and_daglari_bisiklet",
	        "title": "Escarabajos: And Dağları Bisiklet Tırmanışı",
	        "category": "saglik",
	        "vignette": "sports",
	        "context_note": "Kolombiyalı dağ bisikletçilerinin (Escarabajos) 3.000 metre rakımdaki efsanevi dayanıklılığı.",
	        "text": "Bogotá çevresindeki dik dağ geçitlerinde düzenlenen ulusal tırmanış yarışına katıldın. İnce havada ciğerlerin yanıyor ama zirveye çok az kaldı.",
	        "min_age": 16,
	        "max_age": 45,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Son virajda atağa kalk ve zirveye ilk ulaşan sporcu ol",
	            "lock_reason": "",
	            "req_stats": {
	              "health": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Muazzam bir kondisyon ve ulusal spor bursu kazandın!",
	            "effects": {
	              "health": 16,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 15,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kendi temponu koruyarak yarışı sağlıkla tamamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ciğerlerin açıldı, bedensel direncin yükseldi.",
	            "effects": {
	              "health": 10,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "co_baris_anlasmasi_ve_koy_donusu",
	        "title": "Barış Süreci ve Kırsal Toprakların İadesi",
	        "category": "aile",
	        "vignette": "home",
	        "context_note": "Yıllar süren iç çatışmaların ardından köylülerin terk ettikleri verimli topraklara geri dönüşü.",
	        "text": "Büyükbabanın yıllar önce silahlı çatışmalar yüzünden terk etmek zorunda kaldığı vadi, barış anlaşmasıyla güvenli hale geldi. Devlet tapu iadesi yapıyor.",
	        "min_age": 22,
	        "max_age": 68,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CO"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Toprağı teslim al ve ekolojik kakao/avokado çiftliği kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Aile mirasını yeniden yeşerttin ve düzenli tarımsal gelir elde ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 12,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "toprak_sahibi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Devletin verdiği nakit tazminatı alıp şehirde kal",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Şehirdeki düzenini bozmadan toplu para aldın.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "RU": {
	    "code": "RU",
	    "name": "Rusya",
	    "flag": "🇷🇺",
	    "currency_symbol": "₽",
	    "exchange_rate_to_usd": 96.0,
	    "global_pop_pct": 1.8,
	    "spawn_weight": 7.5,
	    "life_expectancy": 73,
	    "gdp_per_capita_usd": 13800,
	    "inflation_rate": 0.085,
	    "tax_rate": 0.15,
	    "annual_living_cost_usd": 6200,
	    "uni_tuition_usd": 1400,
	    "base_health_index": 74,
	    "cities": [
	      "Moskova",
	      "St. Petersburg",
	      "Novosibirsk",
	      "Yekaterinburg",
	      "Kazan",
	      "Vladivostok"
	    ],
	    "female_names": [
	      "Sofia",
	      "Anna",
	      "Maria",
	      "Eva",
	      "Victoria",
	      "Polina",
	      "Alisa",
	      "Daria",
	      "Anastasia",
	      "Ekaterina"
	    ],
	    "male_names": [
	      "Alexander",
	      "Mikhail",
	      "Maxim",
	      "Artem",
	      "Daniil",
	      "Ivan",
	      "Dmitry",
	      "Kirill",
	      "Andrei",
	      "Nikita"
	    ],
	    "surnames": [
	      "Ivanov",
	      "Smirnov",
	      "Kuznetsov",
	      "Popov",
	      "Vasiliev",
	      "Petrov",
	      "Sokolov",
	      "Mikhailov",
	      "Novikov",
	      "Fedorov"
	    ],
	    "class_distribution": {
	      "extreme_poor": 10,
	      "low": 36,
	      "middle": 38,
	      "high": 12,
	      "elite": 4
	    },
	    "birth_report_text": "11 saat dilimine yayılan devasa coğrafya Rusya'da (%1.8) doğdun. Sert kışlar, derin edebiyat, satranç ve matematik disiplini ruhunu şekillendirirken; oligark ekonomisi, politik baskılar ve zorunlu askerlik celpleri kaderini sınayacak.",
	    "local_events": [
	      {
	        "id": "ru_olimpiyat_matematik_ve_satranc",
	        "title": "Moskova Fizik-Matematik ve Satranç Olimpiyatı",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Sovyet döneminden miras kalan üst düzey matematik, fizik ve satranç okulu geleneği.",
	        "text": "Karlı bir kış sabahı bölge satranç ve uygulamalı matematik olimpiyatlarının final masasındasın. Jüride Moskova Devlet Üniversitesi (MGU) profesörleri oturuyor.",
	        "min_age": 13,
	        "max_age": 19,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Cesur bir gambit ve analitik kanıtla birincilik kürsüsüne çık",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "MGU'ya sınavsız tam burslu kabul edildin; bilimsel dehan tescillendi!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 16,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "olimpiyat_sampiyonu",
	              "tag_muhendislik_diplomasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Güvenli oynayıp dereceye girerek teknik enstitüye yerleş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sağlam bir mühendislik eğitimi alma hakkı kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 10,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ru_voenkomat_askerlik_celbi",
	        "title": "Voenkomat: Askerlik Komiserliği Celp Kağıdı",
	        "category": "askerlik",
	        "vignette": "military",
	        "context_note": "Rusya'da genç erkeklerin kapısını çalan zorunlu askerlik ve seferberlik ikilemi.",
	        "text": "Sabah erken saatte apartman görevlisi elinde resmi mühürlü 'Voenkomat' celp kağıdıyla kapıyı çaldı. Uzak Doğu veya sınır birliklerine sevk edilme ihtimalin var.",
	        "min_age": 18,
	        "max_age": 28,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [
	            "askerlik_yapti"
	          ],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Birliğe teslim ol ve Sibirya'daki kışlada 1 yıllık zorlu hizmeti tamamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Eksi 35 derecede dayanıklılığın sınandı; sertleşmiş bir iradeyle sivil hayata döndün.",
	            "effects": {
	              "health": -6,
	              "happiness": -8,
	              "smart": 0,
	              "reputation": 10,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Stratejik bilişim/bilim kadrosuna (IT-Bron) girerek muafiyet al",
	            "lock_reason": "Kritik Bilim Muafiyeti İçin Zeka 72+ Gerekli",
	            "req_stats": {
	              "smart": 72
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kritik mühendislik bilgin sayesinde sivil savunma araştırma merkezinde kalarak muaf oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "askerlik_yapti",
	              "bilim_muafiyeti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tek yön uçak bileti alıp Tiflis veya Erivan üzerinden yurtdışına çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 2200,
	            "req_tags": [],
	            "outcome_text": "Anavatanını geride bırakıp belirsiz ama özgür bir dijital göçebe hayatına adım attın.",
	            "effects": {
	              "health": 0,
	              "happiness": -4,
	              "smart": 0,
	              "reputation": -12,
	              "sanity": -6,
	              "karma": 0,
	              "money_flat": -2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "gocmen",
	              "politik_surgun"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ru_oligark_ihale_teklifi",
	        "title": "Enerji ve Maden İhalesinde 'Gri' Ortaklık Teklifi",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Doğal gaz ve maden zenginliğinin bürokratik bağlantılarla paylaşıldığı oligark düzeni.",
	        "text": "Moskova'da lüks bir restoranda bir bakanlık yetkilisi ve maden şirketi yöneticisi, imzan karşılığında sana yüksek komisyonlu ama yasal sınırları zorlayan bir tedarik sözleşmesi öneriyor.",
	        "min_age": 25,
	        "max_age": 58,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Teklifi reddet; bağımsız ve şeffaf ticaret ilkelerinden taviz verme",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Devasa bir serveti elinin tersiyle ittin ama gece yastığa başını korkusuzca koydun.",
	            "effects": {
	              "health": 0,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 14,
	              "karma": 16,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sözleşmeyi imzala ve oligark çemberine adım at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Banka hesapların hızla doldu; ancak politik rüzgar dönerse tüm varlığına el konulma riski doğdu!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": -12,
	              "karma": -18,
	              "money_flat": 14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "oligark_bagi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 4,
	              "event_id": "arc_pol_4",
	              "origin_note": "Moskova'da imzaladığın gri enerji ihalesinin siyasi hesaplaşması"
	            }
	          }
	        ]
	      },
	      {
	        "id": "ru_dacha_yazlik_ve_orman",
	        "title": "Dacha Mevsimi: Huş Ağaçları Altında Semaver ve Huzur",
	        "category": "aile",
	        "vignette": "nature",
	        "context_note": "Rus ailelerinin hafta sonları şehirden kaçıp ahşap kulübelerinde (Dacha) sebze yetiştirdiği gelenek.",
	        "text": "Yaz geldiğinde ailenle birlikte orman kıyısındaki ahşap 'Dacha'ya gittiniz. Semaverde çay kaynarken, deden sana gençlik yıllarından kalma el yazması günlüğünü veriyor.",
	        "min_age": 14,
	        "max_age": 85,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Banyada (Rus saunası) arın, ormandan mantar topla ve aile tarihini oku",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Köklerinle bağın güçlendi, bedenin ve zihnin şifa buldu.",
	            "effects": {
	              "health": 12,
	              "happiness": 16,
	              "smart": 6,
	              "reputation": 0,
	              "sanity": 16,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Dacha arazisini genişletip organik tarım ürünleri yetiştir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem kışlık erzak çıktı hem de ek gelir elde ettin.",
	            "effects": {
	              "health": 6,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ru_st_petersburg_beyaz_geceler",
	        "title": "St. Petersburg Beyaz Geceleri ve Dostoyevski Sokakları",
	        "category": "felsefe",
	        "vignette": "art",
	        "context_note": "Haziran ayında güneşin neredeyse hiç batmadığı Neva Nehri köprüleri ve sanat geceleri.",
	        "text": "Neva Nehri üzerindeki dev köprüler gece yarısı gemiler için açılırken, gökyüzü hâlâ gümüşi bir aydınlık içinde. Bir tiyatro ve edebiyat topluluğu seni aralarına davet ediyor.",
	        "min_age": 18,
	        "max_age": 65,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Topluluğa katılıp klasik tiyatro ve felsefe tartışmalarına öncülük et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kültürel derinliğin ve çevrendeki saygınlığın büyük ölçüde arttı.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 10,
	              "reputation": 14,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kultur_insani"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Köprülerin açılışını izleyip sabaha kadar nehir kıyısında yürü",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Unutulmaz bir melankoli ve ilhamla doldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ru_trans_sibirya_treni",
	        "title": "Trans-Sibirya Ekspresi: 9.289 Kilometrelik Yolculuk",
	        "category": "felsefe",
	        "vignette": "migration",
	        "context_note": "Moskova'dan Japon Denizi kıyısındaki Vladivostok'a 7 gün süren efsanevi tren yolculuğu.",
	        "text": "Hayatında yeni bir başlangıç yapmak veya iş bağlantısı kurmak için Trans-Sibirya treninin üçüncü mevki (Platskart) vagonuna bindin. Kompartımanda her meslekten insan var.",
	        "min_age": 20,
	        "max_age": 70,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "RU"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yedi gün boyunca yolcuların hikayelerini dinle ve Baykal Gölü'nde mola ver",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İnsan doğasına dair eşsiz bir bilgelik ve yeni ticari/akademik dostlar kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 10,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Trendeki tüccarlarla ortak olup Vladivostok liman ticaretine gir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uzak Doğu ticaret hattından ciddi bir kazanç elde ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "CN": {
	    "code": "CN",
	    "name": "Çin",
	    "flag": "🇨🇳",
	    "currency_symbol": "¥",
	    "exchange_rate_to_usd": 7.2,
	    "global_pop_pct": 17.5,
	    "spawn_weight": 17.5,
	    "life_expectancy": 78,
	    "gdp_per_capita_usd": 12700,
	    "inflation_rate": 0.02,
	    "tax_rate": 0.25,
	    "annual_living_cost_usd": 6500,
	    "uni_tuition_usd": 1100,
	    "base_health_index": 82,
	    "cities": [
	      "Şanghay",
	      "Pekin",
	      "Shenzhen",
	      "Guangzhou",
	      "Chengdu",
	      "Hangzhou",
	      "Wuhan"
	    ],
	    "female_names": [
	      "Mei",
	      "Xinyi",
	      "Yuhan",
	      "Zihan",
	      "Yinuo",
	      "Jing",
	      "Lan",
	      "Xiaoli",
	      "Fang",
	      "Ting"
	    ],
	    "male_names": [
	      "Wei",
	      "Hao",
	      "Yichen",
	      "Z轩 (Zixuan)",
	      "Ming",
	      "Jun",
	      "Jie",
	      "Tao",
	      "Lei",
	      "Chen"
	    ],
	    "surnames": [
	      "Wang",
	      "Li",
	      "Zhang",
	      "Liu",
	      "Chen",
	      "Yang",
	      "Huang",
	      "Zhao",
	      "Wu",
	      "Zhou"
	    ],
	    "class_distribution": {
	      "extreme_poor": 8,
	      "low": 34,
	      "middle": 44,
	      "high": 11,
	      "elite": 3
	    },
	    "birth_report_text": "Dünya nüfusunun %17.5'ini barındıran üretim ve teknoloji devi Çin'de doğdun! 12 milyon adayın ter döktüğü Gaokao sınavı, kırsal/kentsel 'Hukou' kayıt sistemi ve Shenzhen'in '996' çalışma temposu kaderini belirleyecek.",
	    "local_events": [
	      {
	        "id": "cn_gaokao_sinav_savasi",
	        "title": "Gaokao: On İki Milyon Gencin Tek Köprü Savaşı",
	        "category": "egitim",
	        "vignette": "exam",
	        "context_note": "Çin'de 'binlerce askerin tek bir kütük köprüden geçmeye çalışması' olarak anılan ulusal üniversite sınavı.",
	        "text": "Haziran başında iki gün sürecek Gaokao sınavı geldi çattı. Sıra üzerinde üst üste yığılmış test kitaplarının arkasından zar zor görünüyorsun; Pekin veya Tsinghua Üniversitesi hayalin bu 9 saate bağlı.",
	        "min_age": 17,
	        "max_age": 19,
	        "weight": 96,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Üstün puan alarak birinci sınıf (985/211 Projesi) üniversiteye yerleş ve kentsel Hukou kazan",
	            "lock_reason": "Birinci Sınıf Üniversite İçin Zeka 74+ Gerekli",
	            "req_stats": {
	              "smart": 74
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Köyünden/mahallenden çıkan en parlak öğrenci oldun; büyükşehir oturum hakkı (Hukou) ve parlak bir gelecek açıldı!",
	            "effects": {
	              "health": -6,
	              "happiness": 20,
	              "smart": 16,
	              "reputation": 26,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "kentsel_hukou",
	              "tag_muhendislik_diplomasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Eyalet meslek yüksekokuluna gidip e-ticaret ve tedarik zinciri öğren",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Pratik üretim ve ticaret becerileriyle piyasaya hızlı giriş yaptın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "cn_996_vs_tangping",
	        "title": "Shenzhen'de '996' Mesaisi mi, 'Tang Ping' (Düz Yatma) mı?",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Sabah 9'dan akşam 9'a haftada 6 gün çalışma temposu (996) ile gençlerin sade yaşam protestosu (Tang Ping).",
	        "text": "Shenzhen'deki dev bir teknoloji ve donanım şirketinde çalışıyorsun. Müdürün yeni proje için '996' (haftada 72 saat) temposunu dayatırken, bazı arkadaşların istifa edip Yunnan'da sakin bir hayat kuruyor.",
	        "min_age": 22,
	        "max_age": 42,
	        "weight": 88,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "996 temposuna gir, hisse opsiyonlarını topla ve donanım direktörü ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sağlığın ve uykun yıprandı ama 5 yılda servet biriktirdin!",
	            "effects": {
	              "health": -18,
	              "happiness": -8,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": -14,
	              "karma": 0,
	              "money_flat": 9200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "shenzhen_yoneticisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "'Tang Ping' (Düz Yatma) felsefesini seç; gösteriş tüketimini bırakıp bağımsız çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Az harcayıp ruhsal özgürlüğünü ve sağlığını korudun.",
	            "effects": {
	              "health": 12,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": -8,
	              "sanity": 18,
	              "karma": 0,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tang_ping"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "cn_hukou_ve_emlak_dugumu",
	        "title": "Büyükşehir Hukou Kaydı ve Evlilik İçin Daire Şartı",
	        "category": "ekonomi",
	        "vignette": "home",
	        "context_note": "Çin'de büyükşehirde eğitim ve sağlık hakkı veren 'Hukou' belgesi ile evlilik öncesi konut beklentisi.",
	        "text": "Şanghay veya Pekin'de yuva kurmak istiyorsun; ancak müstakbel eşinin ailesi büyükşehirde tapulu bir daire olmadan evliliğe sıcak bakmıyor.",
	        "min_age": 24,
	        "max_age": 40,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ailelerin birikimini birleştirip (6 Cüzdan modeli) yüksek teknoloji bölgesinden daire al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 3500,
	            "req_tags": [],
	            "outcome_text": "Mülk sahibi oldun, kentsel statün ve aile bağların güçlendi.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "ev_sahibi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Fahiş emlak fiyatlarını reddet, Chengdu gibi yaşam kalitesi yüksek bir şehre yerleş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Konut kredisi kölesi olmadan çay bahçeleri ve kültür dolu bir şehirde refah içinde yaşadın.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 15,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "cn_shenzhen_donanim_fabrikasi",
	        "title": "Huaqiangbei Elektronik Pazarından Küresel Markaya",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Shenzhen'in dünyanın fabrika merkezi olan elektronik tedarik ekosisteminde girişimcilik.",
	        "text": "Huaqiangbei pazarında akıllı sensör ve elektrikli araç parçaları üreten bir atölyeyle ortaklık kurma fırsatın doğdu.",
	        "min_age": 21,
	        "max_age": 55,
	        "weight": 80,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kendi patentli akıllı cihaz markanı yaratıp küresel e-ticaretle dünyaya sat",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ürünün küresel pazarlarda yok sattı; ihracat şampiyonu oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 10,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 8400,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "ihracat_devi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Fason üretici (OEM) olarak büyük markalara parça tedarik et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Düşük riskle düzenli ve sağlam bir fabrika geliri elde ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "cn_bahar_bayrami_chunyun",
	        "title": "Chunyun: Bahar Bayramı'nda 3 Milyar Yolculuk",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "Ay Yeni Yılı'nda yüz milyonlarca insanın aile sofrasına yetişmek için çıktığı dünyanın en büyük insan göçü.",
	        "text": "Ay Yeni Yılı (Chunjie) geldi. Hızlı tren biletleri saniyeler içinde tükendi; anne ve baban memlekette mantı (Jiaozi) açmış yolunu gözlüyor.",
	        "min_age": 18,
	        "max_age": 75,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Aktarmalı trenlerle 18 saat yolculuk yapıp aile sofrasına yetiş ve kırmızı zarf (Hongbao) dağıt",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ailenin gözlerindeki mutluluk tüm yorgunluğunu unutturdu.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": 12,
	              "karma": 10,
	              "money_flat": -500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Şehirde kalıp bayram mesaisinde üç kat ücret al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Cebin doldu ama görüntülü konuşmada annenin buruk tebessümü içini sızlattı.",
	            "effects": {
	              "health": 0,
	              "happiness": -6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "cn_geleneksel_tip_ve_tai_chi",
	        "title": "Sabah Parkında Tai Chi ve Geleneksel Bilgelik",
	        "category": "saglik",
	        "vignette": "philosophy",
	        "context_note": "Şehir parklarında sabahın erken saatlerinde yapılan Tai Chi, kaligrafi ve çay seremonisi.",
	        "text": "Şafak vakti parktaki bambu ağaçlarının arasında yaşlı bir usta Tai Chi hareketleriyle nefesini dengeliyor.",
	        "min_age": 30,
	        "max_age": 95,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "CN"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Her sabah Tai Chi ve Gongfu çay ritüelini hayatının parçası yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kan dolaşımın ve zihinsel dengen mükemmel bir uyuma kavuştu.",
	            "effects": {
	              "health": 16,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 16,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tai_chi_ustasi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Parktaki satranç (Xiangqi) ustalarıyla zihin egzersizleri yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Stratejik düşünme becerin yaşın ilerlese de keskin kaldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 10,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "GB": {
	    "code": "GB",
	    "name": "İngiltere",
	    "flag": "🇬🇧",
	    "currency_symbol": "£",
	    "exchange_rate_to_usd": 0.78,
	    "global_pop_pct": 0.85,
	    "spawn_weight": 6.5,
	    "life_expectancy": 81,
	    "gdp_per_capita_usd": 48900,
	    "inflation_rate": 0.032,
	    "tax_rate": 0.32,
	    "annual_living_cost_usd": 21000,
	    "uni_tuition_usd": 11500,
	    "base_health_index": 85,
	    "cities": [
	      "Londra",
	      "Manchester",
	      "Edinburgh",
	      "Birmingham",
	      "Oxford",
	      "Bristol",
	      "Liverpool"
	    ],
	    "female_names": [
	      "Olivia",
	      "Amelia",
	      "Isla",
	      "Ava",
	      "Freya",
	      "Florence",
	      "Lily",
	      "Mia",
	      "Willow",
	      "Eleanor"
	    ],
	    "male_names": [
	      "Noah",
	      "George",
	      "Oliver",
	      "Muhammad",
	      "Arthur",
	      "Leo",
	      "Harry",
	      "Oscar",
	      "Archie",
	      "charlie"
	    ],
	    "surnames": [
	      "Smith",
	      "Jones",
	      "Taylor",
	      "Brown",
	      "Williams",
	      "Wilson",
	      "Johnson",
	      "Davies",
	      "Patel",
	      "Wright"
	    ],
	    "class_distribution": {
	      "extreme_poor": 4,
	      "low": 26,
	      "middle": 48,
	      "high": 16,
	      "elite": 6
	    },
	    "birth_report_text": "Köklü tarih, finans merkezi Londra ve ücretsiz NHS sağlık sisteminin ülkesi İngiltere'de (%0.85) doğdun. Ancak aksanından okuduğun okula kadar hissedilen görünmez sınıf sistemi (Class System) ve fahiş konut kiraları hayat mücadeleni şekillendirecek.",
	    "local_events": [
	      {
	        "id": "gb_alevels_ve_oxbridge",
	        "title": "A-Level Sonuç Günü ve Oxbridge Mülakatı",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "İngiltere'de Oxford ve Cambridge'in asırlık kolej salonlarında yapılan zorlu kabul mülakatları.",
	        "text": "A-Level sınav sonuç zarfını açtın! Oxford/Cambridge kolejindeki mülakatta dünyaca ünlü bir profesör sana ders kitabında olmayan felsefi ve analitik bir bilmece soruyor.",
	        "min_age": 17,
	        "max_age": 19,
	        "weight": 92,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Soğukkanlılıkla argümanını kur ve Oxbridge bursunu kazan",
	            "lock_reason": "Oxbridge İçin Zeka 74+ Gerekli",
	            "req_stats": {
	              "smart": 74
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Asırlık taş avlulara kabul edildin; İngiltere'nin en güçlü entelektüel ve siyasi ağına adım attın!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 16,
	              "reputation": 25,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "oxbridge_mezunu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Russell Grubu bir şehir üniversitesine (Manchester / Bristol) yerleş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Harika bir öğrenci hayatı ve sağlam bir akademik eğitim kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 10,
	              "reputation": 12,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "gb_londra_kira_ve_zone_krizi",
	        "title": "Londra Konut Krizi: Zone 2'de Küflü Oda mı, Taşra mı?",
	        "category": "ekonomi",
	        "vignette": "home",
	        "context_note": "Londra'da genç profesyonellerin maaşlarının yarısından fazlasını yutan konut ve kira krizi.",
	        "text": "Londra'daki ev sahibin kirayı aylık £600 daha artırdığını duyurdu. Paylaşımlı evdeki (Flatshare) odan zaten daracık; karar vermen gerekiyor.",
	        "min_age": 21,
	        "max_age": 45,
	        "weight": 84,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hükümetin İlk Evim (Shared Ownership) programıyla banliyöden kendi evini al",
	            "lock_reason": "Peşinat İçin Birikim Gerekli",
	            "req_stats": {},
	            "req_money": 3200,
	            "req_tags": [],
	            "outcome_text": "Kira döngüsünden kurtulup kendi tapuna adım attın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": -3200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "ev_sahibi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Kuzey İngiltere'ye veya İskoçya'ya (Manchester / Edinburgh) taşınıp yaşam kaliteni artır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kira giderin yarıya düştü; kültürel olarak zengin ve ferah bir hayat kurdun.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": 2400,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Londra merkezde kalmak için aşırı kirayı sineye çek",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kariyer ağına yakın kaldın ama ay sonunu getirmekte zorlanıyorsun.",
	            "effects": {
	              "health": 0,
	              "happiness": -8,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -8,
	              "karma": 0,
	              "money_flat": -2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "gb_city_of_london_finans",
	        "title": "The City of London: Küresel Finans ve Hukuk Kuleleri",
	        "category": "kariyer",
	        "vignette": "finance",
	        "context_note": "Londra'nın finans kalbi 'Square Mile' ve Canary Wharf'taki uluslararası yatırım bankaları.",
	        "text": "Canary Wharf'taki bir yatırım fonu veya uluslararası hukuk bürosu, küresel bir birleşme anlaşmasında seni baş analist olarak görevlendirmek istiyor.",
	        "min_age": 23,
	        "max_age": 52,
	        "weight": 82,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gece gündüz çalışıp anlaşmayı kapat ve yıllık dev ikramiyeyi (Bonus) al",
	            "lock_reason": "Zeka En Az 68 Olmalı",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sterlin bazında büyük bir ikramiye kazandın ve Londra finans elitine girdin!",
	            "effects": {
	              "health": -6,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 8800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "city_finansci"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Etik yatırım ve yeşil finans birimine geçerek dengeli çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Vicdanın ve özel hayatınla uyumlu saygın bir kariyer sürdürdün.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 12,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "gb_nhs_bekleme_listesi",
	        "title": "NHS Bekleme Sırası ve Özel Sağlık İkilemi",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "İngiltere Ulusal Sağlık Sistemi'nin (NHS) ücretsiz ama aylarca sürebilen randevu kuyrukları.",
	        "text": "Dizinde ve sırtında kronikleşen bir ağrı başladı. Ücretsiz NHS ameliyat sırası için 9 ay bekleme süresi verildi; özel klinik ise hemen yarın yapabileceğini söylüyor.",
	        "min_age": 25,
	        "max_age": 80,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Özel sağlık kliniğine ödeme yapıp hemen tedavi ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 2800,
	            "req_tags": [],
	            "outcome_text": "Ağrılarından anında kurtuldun ve iş gücü kaybı yaşamadın.",
	            "effects": {
	              "health": 16,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "NHS sırasını bekle ve fizyoterapi egzersizleriyle süreci yönet",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Para harcamadan birkaç ay sonra ücretsiz ameliyatını oldun.",
	            "effects": {
	              "health": 8,
	              "happiness": -2,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "gb_west_end_ve_muzik_sahnesi",
	        "title": "Soho & West End: İngiliz Kültür ve Müzik Sahnesi",
	        "category": "kariyer",
	        "vignette": "music",
	        "context_note": "Beatles'tan West End müzikallerine uzanan Britanya kültür endüstrisi.",
	        "text": "Arkadaşlarınla kurduğun müzik grubu veya yazdığın tiyatro metni, Londra Soho'daki bağımsız bir yapımcının dikkatini çekti.",
	        "min_age": 18,
	        "max_age": 48,
	        "weight": 74,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Glastonbury Festivali ve West End seçmelerine çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Performansın BBC radyolarında çalındı; kültür dünyasında adın duyuldu!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "brit_sanatci"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Telif haklarını satıp mevcut mesleğine odaklan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Net ve risksiz bir telif geliri elde ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "gb_pub_quiz_ve_mahalle",
	        "title": "Yağmurlu Akşamda Mahalle Pub'ı ve Bilgi Yarışması",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "İngiliz sosyal yaşamının kalbi olan geleneksel mahalle pub kültürü ve Pub Quiz geceleri.",
	        "text": "Dışarıda ince bir İngiliz yağmuru çiseliyor. Mahalledeki asırlık ahşap pub'da düzenlenen genel kültür yarışmasında (Pub Quiz) takımının son soruyu bilmesi sana bağlı.",
	        "min_age": 18,
	        "max_age": 85,
	        "weight": 70,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "GB"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Tarih ve bilim birikiminle doğru cevabı verip kupayı kaldır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bütün salon seni alkışladı; komşularınla bağların güçlendi.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 5,
	              "reputation": 10,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Şömine başında dostlarınla sohbet edip yorgunluk at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sıcak ve samimi bir akşam geçirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  "AR": {
	    "code": "AR",
	    "name": "Arjantin",
	    "flag": "🇦🇷",
	    "currency_symbol": "ARS",
	    "exchange_rate_to_usd": 980.0,
	    "global_pop_pct": 0.58,
	    "spawn_weight": 5.5,
	    "life_expectancy": 77,
	    "gdp_per_capita_usd": 13700,
	    "inflation_rate": 0.85,
	    "tax_rate": 0.28,
	    "annual_living_cost_usd": 5800,
	    "uni_tuition_usd": 0,
	    "base_health_index": 80,
	    "cities": [
	      "Buenos Aires",
	      "Córdoba",
	      "Rosario",
	      "Mendoza",
	      "La Plata",
	      "Bariloche"
	    ],
	    "female_names": [
	      "Olivia",
	      "Emilia",
	      "Isabella",
	      "Catalina",
	      "Martina",
	      "Sofía",
	      "Delfina",
	      "Valentina",
	      "Lucía",
	      "Camila"
	    ],
	    "male_names": [
	      "Mateo",
	      "Bautista",
	      "Juan",
	      "Felipe",
	      "Bruno",
	      "Noah",
	      "Benicio",
	      "Thiago",
	      "Santino",
	      "Valentino"
	    ],
	    "surnames": [
	      "González",
	      "Rodríguez",
	      "Gómez",
	      "Fernández",
	      "López",
	      "Díaz",
	      "Martínez",
	      "Pérez",
	      "García",
	      "Sánchez"
	    ],
	    "class_distribution": {
	      "extreme_poor": 14,
	      "low": 38,
	      "middle": 36,
	      "high": 9,
	      "elite": 3
	    },
	    "birth_report_text": "Tango, edebiyat, mate çayı ve futbol efsanelerinin ülkesi Arjantin'de (%0.58) doğdun! Buenos Aires Üniversitesi (UBA) gibi ücretsiz ve prestijli okulların var; ancak yıllık %100'ü aşabilen kronik hiperenflasyon nedeniyle maaşını aldığın gün dolara ('Dólar Blue') veya mala çevirmezsen birikimin eriyecek!",
	    "local_events": [
	      {
	        "id": "ar_hiperenflasyon_ve_dolar_blue",
	        "title": "Hiperenflasyon Fırtınası ve Florida Caddesi'nde 'Cambio!' Sesleri",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Arjantin pesosunun her ay değer kaybettiği ortamda halkın birikimini koruma mücadelesi.",
	        "text": "Market etiketleri haftada iki kez değişiyor! Maaşın hesabına yattı; Buenos Aires Florida Caddesi'nde 'Cambio! Cambio!' diye bağıran dövizciler ve sabit vadeli hesaplar arasında hemen karar vermelisin.",
	        "min_age": 18,
	        "max_age": 70,
	        "weight": 94,
	        "repeatable": true,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Maaşını alır almaz dolara ve enflasyona endeksli varlıklara çevir",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 55
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Peso %50 değer kaybederken senin alım gücün sapasağlam kaldı!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 3600,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "kur_korumali"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Dayanıklı tüketim malları ve gayrimenkul stokla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Enflasyonist ortamda aldığın malların değeri katlandı.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Parayı vadesiz peso hesabında unut",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Birkaç ay içinde birikiminin yarısı enflasyon canavarına yem oldu!",
	            "effects": {
	              "health": 0,
	              "happiness": -16,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -14,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": -0.35
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ar_uba_ucretsiz_universite",
	        "title": "Buenos Aires Üniversitesi (UBA) ve Nobel Geleneği",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Latin Amerika'nın en çok Nobel ödülü çıkaran ücretsiz devlet üniversitesi UBA.",
	        "text": "Ekonomik krizlere rağmen Arjantin'in gururu olan ücretsiz Buenos Aires Üniversitesi'nin (UBA) ağır hazırlık yılı (CBC) sınavlarını geçtin. Amfiler tıklım tıklım ama eğitim kalitesi dünya çapında.",
	        "min_age": 18,
	        "max_age": 23,
	        "weight": 90,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Biyoteknoloji, Tıp veya Edebiyat bölümünde dereceyle mezun ol",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 64
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sıfır eğitim borcuyla dünya standartlarında bir bilim insanı/uzman oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 16,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "uba_mezunu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Öğrenci hareketlerine ve politik tartışmalara liderlik et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hitabet gücün ve toplumsal ağın muazzam gelişti.",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 10,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "universite_ogrencisi",
	              "ogrenci_lideri"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ar_potrero_futbol_tutkusu",
	        "title": "Potrero'dan La Bombonera / Monumental Çimlerine",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Arjantin'de mahalle arsalarından (Potrero) doğan futbol dehaları.",
	        "text": "Rosario veya Buenos Aires'in mahalle sahasında sergilediğin oyun zekası ve sol ayağın, köklü bir kulübün altyapı hocasını büyüledi.",
	        "min_age": 12,
	        "max_age": 21,
	        "weight": 84,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kulüp akademisine gir ve Avrupa transferi için gece gündüz antrenman yap",
	            "lock_reason": "Kondisyon/Sağlık En Az 66 Olmalı",
	            "req_stats": {
	              "health": 66
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Genç yaşta A takıma yükseldin; stadyum senin adını haykırıyor!",
	            "effects": {
	              "health": 14,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 6800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "profesyonel_futbolcu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Spor gazeteciliği ve kulüp yöneticiliği yolunu seç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Futbol tutkusunu kaleminle ve zekanla birleştirip saygın bir yorumcu oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 8,
	              "reputation": 15,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ar_cacerolazo_sokak_protestosu",
	        "title": "Plaza de Mayo'da 'Cacerolazo' (Tencere-Tava) Protestosu",
	        "category": "kriz",
	        "vignette": "protest",
	        "context_note": "Arjantin halkının ekonomik paketlere ve banka kısıtlamalarına karşı tencere çalarak sokağa dökülmesi.",
	        "text": "Hükümet yeni bir kemer sıkma ve banka çekim kısıtlaması (Corralito benzeri) açıkladı. Bütün mahalle balkonlarda ve Plaza de Mayo meydanında tencere çalarak yürüyor.",
	        "min_age": 18,
	        "max_age": 75,
	        "weight": 78,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Mahalle meclisi (Asamblea) kurup komşular arası takas ve dayanışma ağı örgütle",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kriz günlerinde mahalleni açlıktan ve umutsuzluktan koruyan lider oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 10,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "dayanisma_lideri"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Protestolardan uzak durup birikimini korumaya odaklan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Güvenli kaldın ve işine devam ettin.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ar_asado_ve_mate_sofrasi",
	        "title": "Pazar Günü Asado Ateşi, Mate Çayı ve Psikanaliz",
	        "category": "aile",
	        "vignette": "family",
	        "context_note": "Dünyada kişi başına en çok psikoloğun düştüğü Buenos Aires'te dostluk, et (Asado) ve derin sohbetler.",
	        "text": "Pazar öğleden sonra bahçede Asado ateşi yanıyor, elden ele sıcak 'Mate' kabı dolaşıyor. Dostlarınla hayatın anlamını ve krizlere rağmen mutlu kalmayı konuşuyorsunuz.",
	        "min_age": 16,
	        "max_age": 88,
	        "weight": 76,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Dostlarınla sabaha kadar müzik yap, tango öğren ve içini dök",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Arjantin'e özgü sıcak dostluk ruhunu tamir etti; akıl sağlığın yenilendi!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 8,
	              "sanity": 18,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Mendoza bağları veya Patagonya doğasına bir gezi planla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "And Dağları'nın eteklerinde unutulmaz bir nefes aldın.",
	            "effects": {
	              "health": 10,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": -900,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "ar_san_telmo_tango_ve_edebiyat",
	        "title": "San Telmo'da Eski Kitapçı ve Tango Milongası",
	        "category": "felsefe",
	        "vignette": "art",
	        "context_note": "Borges ve Cortázar'ın izlerini taşıyan Buenos Aires kafeleri.",
	        "text": "San Telmo'nun Arnavut kaldırımlı sokaklarında tarihi bir kafenin üst katında edebiyat ve kültür dergisi çıkarma teklifi aldın.",
	        "min_age": 20,
	        "max_age": 75,
	        "weight": 72,
	        "repeatable": false,
	        "conditions": {
	          "countries": [
	            "AR"
	          ],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Dergiyi çıkar ve Latin Amerika kültür dünyasında ses getir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Entelektüel çevrelerde büyük saygınlık ve ödül kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 12,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Akşamları Milonga salonlarında dans ederek hayatın ritmini yakala",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ruhun ve bedenin zarafet kazandı.",
	            "effects": {
	              "health": 8,
	              "happiness": 15,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  }
	}
