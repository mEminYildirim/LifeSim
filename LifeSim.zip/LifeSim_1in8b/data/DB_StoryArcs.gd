extends RefCounted

# Yıllara Yayılan Çok Aşamalı 18 Büyük Hikaye Zinciri (72 Bağlantılı Aşama Olayı)
static func get_story_arcs() -> Array:
	return [
	  {
	    "arc_id": "arc_tech",
	    "arc_title": "Sıfırdan Teknoloji Girişimi",
	    "stages": [
	      {
	        "id": "arc_tech_1",
	        "title": "Sıfırdan Teknoloji Girişimi (Bölüm I): Gece Yarısı Garaj Prototipi",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Küresel bir sorunu çözen yapay zeka ve bulut tabanlı ilk kod çekirdeği.",
	        "text": "Not defterine çizdiğin mimari sonunda çalıştı! Küçük bir sunucuda çalışan prototipin ilk 500 kullanıcıyı organik olarak çekti. Bu fikri gerçek bir şirkete dönüştürmek ister misin?",
	        "min_age": 20,
	        "max_age": 45,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 62
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Birikimini ortaya koy, şirketi tescille ve tam zamanlı geliştirmeye başla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uykusuz geceler başladı ama ilk gerçek ürünün (MVP) yayına girdi!",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": -1200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_tech_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "Kurucu",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_tech_2",
	              "origin_note": "Sıfırdan Teknoloji Girişimi (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Fikri hobi olarak bırakıp mevcut rutinine dön",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Risk almadın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 2,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_tech_2",
	        "title": "Sıfırdan Teknoloji Girişimi (Bölüm II): Melek Yatırımcı Masası ve Sunucu Çökmesi",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Kullanıcı sayısı 50.000'i aşarken gelen yatırım teklifi.",
	        "text": "Ürünün viral oldu ancak sunucular trafik altında inliyor! Tam bu sırada bir risk sermayesi fonu %40 hisse karşılığında yatırım teklif etti.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yalnızca %15 hisse verip kontrolü elinde tutarak tohum yatırım al",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sert pazarlığın sonuç verdi; şirketin kontrolünü kaybetmeden sermayeyi kasaya koydun!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 6,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_tech_3",
	              "origin_note": "Sıfırdan Teknoloji Girişimi (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Yatırımcının tüm şartlarını kabul edip %40 hisseyi devret",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sunucular kurtuldu ama yönetim kurulunda baskı arttı.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_tech_3",
	              "origin_note": "Sıfırdan Teknoloji Girişimi (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_tech_3",
	        "title": "Sıfırdan Teknoloji Girişimi (Bölüm III): Silikon Vadisi / Küresel Devlerin Satın Alma Kuşatması",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Küresel bir teknoloji tekelinin senin ürününü kopyalama veya satın alma tehdidi.",
	        "text": "Sektör devi bir şirket, ya şirketinizi bize satın ya da aynı özelliği kendi platformumuzda ücretsiz çıkarıp sizi ezeriz diyerek ültimatom verdi!",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Patent korumasını devreye sokup özgün algoritmanla devlere meydan oku",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 72
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kullanıcılar senin hızından ve gizlilik ilkenden vazgeçmedi; pazar payın ikiye katlandı!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": -6,
	              "karma": 0,
	              "money_flat": 6500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_tech_4",
	              "origin_note": "Sıfırdan Teknoloji Girişimi (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Dev şirketle stratejik lisans ortaklığı imzala",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çatışmadan kaçınıp güvenli bir gelir akışı sağladın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_tech_4",
	              "origin_note": "Sıfırdan Teknoloji Girişimi (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_tech_4",
	        "title": "Sıfırdan Teknoloji Girişimi (Final): Borsa Halka Arzı (IPO) Çanı",
	        "category": "kariyer",
	        "vignette": "tech",
	        "context_note": "Yıllar önce bir odada başlayan yazılımın küresel teknoloji borsasında işlem görmeye başlaması.",
	        "text": "Borsa kürsüsündesin! Şirketin milyar dolarlık değerlemeyle (Unicorn) halka arz ediliyor. Çanı çaldığın an hayatın sonsuza dek değişecek.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hisselerinin bir kısmını satarak finansal özgürlüğe ulaş ve CEO olarak devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sıfırdan kurduğun teknoloji imparatorluğuyla tarihe geçtin!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 32,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": 28000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "unicorn_kurucusu",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Teknoloji Vizyoneri",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Tüm hisselerini devredip tamamen özgür bir emekliliğe ve melekyatırımcılığa geç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Muazzam bir nakit servetle (Exit) şirketi devrettin!",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 20,
	              "karma": 0,
	              "money_flat": 32000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "unicorn_kurucusu",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_crime",
	    "arc_title": "Yeraltı Gölge İmparatorluğu",
	    "stages": [
	      {
	        "id": "arc_crime_1",
	        "title": "Yeraltı Gölge İmparatorluğu (Bölüm I): Gece Limanında Mühürsüz Konteyner",
	        "category": "suc",
	        "vignette": "crime",
	        "context_note": "Yasal dünyanın dışındaki karanlık ticaretin ilk basamağı.",
	        "text": "Liman/gümrük çevresinde karanlık işler çeviren bir baron, bu gece gelecek tek bir konteynerin geçişini sağlaman karşılığında yıllık maaşın kadar nakit teklif ediyor.",
	        "min_age": 19,
	        "max_age": 48,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Karanlık teklifi kabul et ve yeraltı dünyasına ilk adımını at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zarf dolusu nakdi cebine koydun; artık geri dönüşü zor bir yoldasın.",
	            "effects": {
	              "health": 0,
	              "happiness": 6,
	              "smart": 0,
	              "reputation": -10,
	              "sanity": -8,
	              "karma": -22,
	              "money_flat": 5000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_crime_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_crime_2",
	              "origin_note": "Yeraltı Gölge İmparatorluğu (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Teklifi reddet ve limandan uzaklaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Temiz kaldın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 10,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_crime_2",
	        "title": "Yeraltı Gölge İmparatorluğu (Bölüm II): Gece Kulübü Paravanı ve Rakip Çete",
	        "category": "suc",
	        "vignette": "crime",
	        "context_note": "Kayıt dışı paranın aklanması ve bölge savaşı.",
	        "text": "Baron seni sağ kolu yaptı ve paravan bir gece kulübünün yönetimini verdi. Ancak rakip şebeke kulübü basıp haraç istiyor!",
	        "min_age": 20,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Soğukkanlı bir pusu ve müzakereyle rakip şebekeyi şehirden söküp at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yeraltı dünyasında adın korku ve saygıyla fısıldanmaya başladı!",
	            "effects": {
	              "health": -8,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 12,
	              "sanity": -10,
	              "karma": -20,
	              "money_flat": 9500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_crime_3",
	              "origin_note": "Yeraltı Gölge İmparatorluğu (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Bölgeyi paylaşarak kan dökülmesini önle",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ateşkes sağlandı ve kasa dolmaya devam etti.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": -10,
	              "money_flat": 5500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_crime_3",
	              "origin_note": "Yeraltı Gölge İmparatorluğu (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_crime_3",
	        "title": "Yeraltı Gölge İmparatorluğu (Bölüm III): Köstebek Şüphesi ve Organize Suçlar Masası",
	        "category": "suc",
	        "vignette": "crime",
	        "context_note": "Emniyetin şebekeyi teknik takibe alması.",
	        "text": "Organize Suçlar Bürosu tüm telefonları dinliyor! İçeride bir muhbir olduğu kesinleşti; çember daralıyor.",
	        "min_age": 21,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Sahte istihbarat sızdırarak köstebeği açığa çıkar ve tüm kanıtları yok et",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Operasyon boşa çıktı; şebekenin mutlak lideri (Baron) koltuğuna sen oturdun!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": -14,
	              "karma": -20,
	              "money_flat": 14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_crime_4",
	              "origin_note": "Yeraltı Gölge İmparatorluğu (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Nakit çantalarını alıp izini kaybettirmeye çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kaçış hazırlıkları başladı ama polis ensende.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -16,
	              "karma": 0,
	              "money_flat": 6000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_crime_4",
	              "origin_note": "Yeraltı Gölge İmparatorluğu (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_crime_4",
	        "title": "Yeraltı Gölge İmparatorluğu (Final): Şafak Operasyonu: Hesaplaşma Günü",
	        "category": "suc",
	        "vignette": "crime",
	        "context_note": "Karanlık imparatorluğun son perdesi.",
	        "text": "Saat 05:00'te helikopter sesleri ve sirenlerle malikanen/ofisin kuşatıldı! Başsavcı megafonla teslim ol çağrısı yapıyor.",
	        "min_age": 22,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gizli tünelden ve sahte pasaportla denizaşırı bir ülkeye kaçıp servetini kurtar",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 70
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Karanlık geçmişini ardında bırakıp başka bir isimle gölgelerde yaşamaya başladın!",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": -25,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": 18000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "yeralti_baronu",
	              "kacak_milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Gölge Baron",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Teslim ol, etkin pişmanlıktan yararlanıp cezanı çekerek temizlen",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yıllarca demir parmaklıklar ardında kaldıktan sonra özgürlüğüne ve vicdanına kavuştun.",
	            "effects": {
	              "health": -16,
	              "happiness": -20,
	              "smart": 0,
	              "reputation": -30,
	              "sanity": 0,
	              "karma": 15,
	              "money_flat": -12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "sabikali",
	              "hapis_yatti"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_mig",
	    "arc_title": "Yabancı Topraklarda Kök Salmak",
	    "stages": [
	      {
	        "id": "arc_mig_1",
	        "title": "Yabancı Topraklarda Kök Salmak (Bölüm I): Tek Bavul ve Bilinmeyen Dil",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Doğduğun topraklardan ayrılıp yeni bir ülkede sıfırdan başlama.",
	        "text": "Yabancı bir metropolün tren istasyonunda elinde tek bir bavulla duruyorsun. Tabelalar yabancı, hava soğuk ve cebindeki para sadece bir aylık odaya yetiyor.",
	        "min_age": 20,
	        "max_age": 45,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gündüz dil kursuna git, gece restoran mutfağında çalışarak dişini sık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ellerin çatladı ama 6 ay içinde hem dili söktün hem de ilk birikimini yaptın!",
	            "effects": {
	              "health": -4,
	              "happiness": 0,
	              "smart": 10,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 1800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_mig_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_mig_2",
	              "origin_note": "Yabancı Topraklarda Kök Salmak (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Kendi memleketlilerinin mahallesine kapanıp dış dünyadan uzak dur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yalnızlık çekmedin ama ülkeye entegrasyonun yavaş kaldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 4,
	              "smart": -2,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 900,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_mig_2",
	        "title": "Yabancı Topraklarda Kök Salmak (Bölüm II): Diploma Denkliği ve Yabancı Düşmanlığı Sınavı",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Göçmenlerin nitelikli işlere girerken karşılaştığı görünmez duvarlar.",
	        "text": "Başvurduğun kurumda yönetici aksanına ve yabancı soyadına bakarak seni küçümsedi. Diploma denkliği için de ağır bir yeterlilik sınavı şart koşuluyor.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yeterlilik sınavında en yüksek puanı alarak önyargıları paramparça et",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 64
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kurul başkanı ayağa kalkıp elini sıktı; uzmanlık kadrosuna atandın!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 10,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_mig_3",
	              "origin_note": "Yabancı Topraklarda Kök Salmak (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Kendi göçmen girişimini ve ticaret ağını kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Başkalarının kapısında beklemek yerine kendi iş yerini açtın!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_mig_3",
	              "origin_note": "Yabancı Topraklarda Kök Salmak (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_mig_3",
	        "title": "Yabancı Topraklarda Kök Salmak (Bölüm III): İki Kültür Arasında Kimlik Köprüsü",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Hem anavatanın hem de yeni ülkenin değerlerini birleştirme.",
	        "text": "Yıllar geçti; artık bu ülkede saygın bir yerin var. Ancak memleketteki ailen 'Bizi unuttun mu?' derken, buradaki çevren tam uyum bekliyor.",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "İki ülke arasında kültür ve ticaret köprüsü kuran bir vakıf/şirket başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Her iki toplumda da el üstünde tutulan bir kültür elçisi oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 16,
	              "money_flat": 6500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_mig_4",
	              "origin_note": "Yabancı Topraklarda Kök Salmak (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Aileni de yanına davet edip bir arada yaşama düzeni kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hasret sona erdi!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 14,
	              "karma": 0,
	              "money_flat": -1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_mig_4",
	              "origin_note": "Yabancı Topraklarda Kök Salmak (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_mig_4",
	        "title": "Yabancı Topraklarda Kök Salmak (Final): Vatandaşlık Yemini ve Onur Madalyası",
	        "category": "goc",
	        "vignette": "migration",
	        "context_note": "Tek bavulla inilen istasyondan toplumsal liderliğe uzanan zafer.",
	        "text": "Belediye sarayında düzenlenen törende hem tam vatandaşlık belgeni hem de ülkeye yaptığın üstün katkılar nedeniyle Yılın Göçmen Başarı Ödülü'nü alıyorsun.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kürsüde iki dilde konuşma yaparak tüm göçmen gençlere umut ver",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hikayen ders kitaplarına ve belgesellere konu oldu!",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 28,
	              "sanity": 20,
	              "karma": 18,
	              "money_flat": 8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "gocmen_basarisi",
	              "cift_vatandas"
	            ],
	            "remove_tags": [],
	            "add_trait": "Dünya Vatandaşı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Birikiminle anavatanında da bir okul yaptırarak köklerini selamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İki kıtada birden hayırla anılan bir isim oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 26,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "gocmen_basarisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_sci",
	    "arc_title": "Akademik Keşif ve Bilim Zirvesi",
	    "stages": [
	      {
	        "id": "arc_sci_1",
	        "title": "Akademik Keşif ve Bilim Zirvesi (Bölüm I): Mikroskop Altındaki Anomali",
	        "category": "egitim",
	        "vignette": "science",
	        "context_note": "Laboratuvarda herkesin 'cihaz hatası' deyip geçtiği sıradışı veri.",
	        "text": "Gece geç saatte deney sonuçlarını incelerken hücresel/kuantum düzeyde daha önce literatürde hiç tanımlanmamış bir etkileşim yakaladın.",
	        "min_age": 22,
	        "max_age": 55,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 68
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Aylarca laboratuvara kapanıp hipotezini matematiksel olarak kanıtla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Öncü bulgun uluslararası hakemli dergide kapak konusu oldu!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 12,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_sci_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sci_2",
	              "origin_note": "Akademik Keşif ve Bilim Zirvesi (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Veriyi standart sapma sayıp rutin araştırmaya devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Keşif fırsatını kaçırdın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_sci_2",
	        "title": "Akademik Keşif ve Bilim Zirvesi (Bölüm II): Akademik Kıskançlık ve Fon Kesintisi",
	        "category": "egitim",
	        "vignette": "science",
	        "context_note": "Yerleşik teorileri sarsan buluşlara karşı bilim dünyasındaki tutucu direnç.",
	        "text": "Kürsüdeki kıdemli rakiplerin teorinin 'imkansız' olduğunu iddia ederek araştırma bütçeni dondurttu!",
	        "min_age": 23,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Uluslararası bağımsız bilim fonlarına başvurup açık veriyle deneyini canlı tekrarla",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 74
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Deney canlı yayında doğrulandı; rakiplerin sessizliğe gömüldü!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 10,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 5000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sci_3",
	              "origin_note": "Akademik Keşif ve Bilim Zirvesi (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Özel bir biyoteknoloji/teknoloji şirketinin AR-GE sponsorluğunu kabul et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bütçe sorununu çözdün ve araştırmayı hızlandırdın.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 6500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sci_3",
	              "origin_note": "Akademik Keşif ve Bilim Zirvesi (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_sci_3",
	        "title": "Akademik Keşif ve Bilim Zirvesi (Bölüm III): İnsanlığın Hizmetine mi, Tekel Patentine mi?",
	        "category": "egitim",
	        "vignette": "science",
	        "context_note": "Keşfin milyonlarca insanın hayatını değiştirecek aşamaya gelmesi.",
	        "text": "Geliştirdiğin yöntem artık kullanıma hazır. Dev ilaç/teknoloji kartelleri patenti kapatıp fahiş fiyata satmak için sana servet teklif ediyor.",
	        "min_age": 24,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Temel kullanım hakkını tüm dünyadaki kamu hastanelerine/üniversitelere açık tut",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Milyonlarca insanın hayatına dokundun; adın bilim tarihine altın harflerle yazıldı!",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 35,
	              "sanity": 0,
	              "karma": 35,
	              "money_flat": 6000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sci_4",
	              "origin_note": "Akademik Keşif ve Bilim Zirvesi (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Ticari lisans anlaşması imzalayıp dev telif geliri al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bilim milyonerleri arasına girdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 22000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sci_4",
	              "origin_note": "Akademik Keşif ve Bilim Zirvesi (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_sci_4",
	        "title": "Akademik Keşif ve Bilim Zirvesi (Final): Stockholm'den Gelen Telefon: Büyük Bilim Ödülü",
	        "category": "egitim",
	        "vignette": "science",
	        "context_note": "Bir bilim insanının ulaşabileceği en yüce onur.",
	        "text": "Ekim sabahı telefonun çaldı. İsveç Kraliyet Bilimler Akademisi sekreteri, insanlığa yaptığın katkıdan dolayı yılın Büyük Bilim / Nobel Ödülü'ne layık görüldüğünü bildiriyor!",
	        "min_age": 25,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kraliyet salonunda ödülü al ve para ödülüyle genç bilim insanları enstitüsü kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yaşayan bir bilim efsanesi haline geldin!",
	            "effects": {
	              "health": 0,
	              "happiness": 30,
	              "smart": 10,
	              "reputation": 40,
	              "sanity": 20,
	              "karma": 25,
	              "money_flat": 25000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "nobel_bilim_odulu",
	              "akademik_basari"
	            ],
	            "remove_tags": [],
	            "add_trait": "Bilim Efsanesi",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ödülü ailenle ve araştırma ekibinle paylaşarak kutla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Tarihe geçen onurlu bir bilim zaferi kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 36,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 25000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "nobel_bilim_odulu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_pol",
	    "arc_title": "Meydanlardan Zirveye: Siyaset Sınavı",
	    "stages": [
	      {
	        "id": "arc_pol_1",
	        "title": "Meydanlardan Zirveye: Siyaset Sınavı (Bölüm I): Mahalle Meclisinden Parti Kürsüsüne",
	        "category": "kariyer",
	        "vignette": "politics",
	        "context_note": "Halkın sorunlarını dile getirirken başlayan siyasi yürüyüş.",
	        "text": "Şehirdeki altyapı ve adalet sorunları üzerine yaptığın konuşma binlerce kişi tarafından paylaşıldı. Ön seçimlerde aday olman için halktan büyük baskı var.",
	        "min_age": 25,
	        "max_age": 62,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Adaylığını koy ve kapı kapı dolaşarak halk hareketi başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ön seçimi ezici çoğunlukla kazandın!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_pol_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_pol_2",
	              "origin_note": "Meydanlardan Zirveye: Siyaset Sınavı (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Siyasetin stresinden uzak dur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sakin hayatını korudun.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_pol_2",
	        "title": "Meydanlardan Zirveye: Siyaset Sınavı (Bölüm II): Seçim Gecesi ve İmar Baronlarının Çantası",
	        "category": "kariyer",
	        "vignette": "politics",
	        "context_note": "Kampanya bütçesi biterken gelen kirli bağış teklifi.",
	        "text": "Seçime bir hafta kala reklam bütçen tükendi. Şehrin en büyük inşaat ve ihale lobisi, seçildiğinde imar planlarını değiştirmek şartıyla kampanyanı finanse etmeyi öneriyor.",
	        "min_age": 26,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Lobiyi kapıdan kov; halktan 10'ar birimlik küçük şeffaf bağışlarla kampanyayı tamamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Halk senin satılık olmadığını gördü ve sandığa akın etti!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 24,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_pol_3",
	              "origin_note": "Meydanlardan Zirveye: Siyaset Sınavı (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Lobinin parasını al ve televizyon reklamlarını domine et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Seçimi kazandın ama imar baronlarına göbekten bağlandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": -22,
	              "money_flat": 12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_pol_3",
	              "origin_note": "Meydanlardan Zirveye: Siyaset Sınavı (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_pol_3",
	        "title": "Meydanlardan Zirveye: Siyaset Sınavı (Bölüm III): Meclis Kürsüsünde Kumpas ve Kaset Tehdidi",
	        "category": "kariyer",
	        "vignette": "politics",
	        "context_note": "Siyasi rakiplerin bel altı saldırısı.",
	        "text": "Hazırladığın yolsuzluk karşıtı yasa tasarısı oylanmadan bir gün önce, rakiplerin montajlanmış belgelerle seni istifaya zorlayan bir karalama kampanyası başlattı.",
	        "min_age": 27,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Canlı yayında tüm mal varlığını ve bağımsız bilirkişi raporlarını açıklayarak hücuma geç",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 65
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kumpas ters tepti! Kamuoyu desteği %70'e fırladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 28,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_pol_4",
	              "origin_note": "Meydanlardan Zirveye: Siyaset Sınavı (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Parti içi dengelerle uzlaşıp tasarıyı yumuşat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Koltuğunu korudun ama idealist destekçilerin kırıldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 4,
	              "sanity": 0,
	              "karma": -8,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_pol_4",
	              "origin_note": "Meydanlardan Zirveye: Siyaset Sınavı (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_pol_4",
	        "title": "Meydanlardan Zirveye: Siyaset Sınavı (Final): Devlet Adamlığı ve Tarihin Hükmü",
	        "category": "kariyer",
	        "vignette": "politics",
	        "context_note": "Siyasi kariyerin zirvesinde bırakılan miras.",
	        "text": "Bakanlık / Büyükşehir liderliği döneminin sonuna geldin. Eğitim, adalet ve sosyal refah alanında yaptığın reformlar oylanıyor.",
	        "min_age": 28,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Reformları tamamla ve koltuğa yapışmadan zirvede gençlere devret",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ülke tarihinde dürüstlüğüyle efsaneleşen bir Devlet İnsanı olarak anıldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 38,
	              "sanity": 18,
	              "karma": 28,
	              "money_flat": 9000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "devlet_insani",
	              "siyasetci"
	            ],
	            "remove_tags": [],
	            "add_trait": "Bilge Lider",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Gücü elinde tutmak için sert bir siyasi makine kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uzun yıllar koltukta kaldın; kimileri sevdi, kimileri korktu.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": -10,
	              "karma": -15,
	              "money_flat": 18000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "demir_siyasetci"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_art",
	    "arc_title": "Başyapıt ve Şöhretin Bedeli",
	    "stages": [
	      {
	        "id": "arc_art_1",
	        "title": "Başyapıt ve Şöhretin Bedeli (Bölüm I): Tavan Arasında Doğurulan Eser",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "Ruhun en derin yaralarından beslenen sanatsal yaratım.",
	        "text": "Aylardır üzerinde çalıştığın roman/senfoni/tablo serisi tamamlandı. Eleştirmenler bunun son 50 yılın en sarsıcı eseri olabileceğini fısıldıyor.",
	        "min_age": 20,
	        "max_age": 58,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Eseri hiçbir ticari sansüre izin vermeden özgün haliyle yayımla/sergile",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sanat dünyasında bomba etkisi yarattı!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 8,
	              "reputation": 20,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_art_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_art_2",
	              "origin_note": "Başyapıt ve Şöhretin Bedeli (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Popüler piyasa zevkine göre değiştir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İyi sattı ama derinliğini kaybetti.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_art_2",
	        "title": "Başyapıt ve Şöhretin Bedeli (Bölüm II): Başyapıtın Patlaması ve Kameralar",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "Ani gelen uluslararası şöhretin özel hayatı yutması.",
	        "text": "Eserin 30 dile çevrildi / uluslararası bienalde başköşeye kondu! Ancak paparazziler ve hayranlar kapının önünden ayrılmıyor.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Şöhret başını döndürmesin; sadece üretimine odaklanıp gizemini koru",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Saygınlığın daha da büyüdü, telif gelirlerin servete dönüştü.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 8500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_art_3",
	              "origin_note": "Başyapıt ve Şöhretin Bedeli (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Her gece sosyete partilerinde ve ekranlarda boy göster",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çok eğlendin ama üretim disiplinin ve akıl sağlığın sarsıldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": -14,
	              "karma": 0,
	              "money_flat": 5000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_art_3",
	              "origin_note": "Başyapıt ve Şöhretin Bedeli (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_art_3",
	        "title": "Başyapıt ve Şöhretin Bedeli (Bölüm III): Yaratıcılık Tıkanması (Boş Sayfa Sendromu)",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "İlk büyük başarıdan sonra herkesin ikinci başyapıtı beklemesi.",
	        "text": "Yayıncılar ve sanat galerileri ikinci büyük eserin için sıkıştırıyor; ancak aylardır tuvale/kağıda tek bir çizgi bile çekemiyorsun!",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Baskıyı reddet; bir kıyı köyüne çekilip kendi ruhunun ritmini bekle",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sessizliğin içinden ilkini bile aşan olgunlukta ikinci başyapıtın doğdu!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 18,
	              "karma": 0,
	              "money_flat": 7000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_art_4",
	              "origin_note": "Başyapıt ve Şöhretin Bedeli (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Aceleyle yarım yamalak bir eser çıkar",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Eleştirmenler acımasızca yerden yere vurdu.",
	            "effects": {
	              "health": 0,
	              "happiness": -12,
	              "smart": 0,
	              "reputation": -10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_art_4",
	              "origin_note": "Başyapıt ve Şöhretin Bedeli (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_art_4",
	        "title": "Başyapıt ve Şöhretin Bedeli (Final): Ölümsüzler Kulübü: Retrospektif ve Klasikleşme",
	        "category": "kariyer",
	        "vignette": "art",
	        "context_note": "Sanatçının hayattayken eserlerinin klasik mertebesine yükselmesi.",
	        "text": "Ulusal Modern Sanat Müzesi / Dünya Edebiyat Akademisi senin bütün eserlerini kapsayan büyük bir 'Yaşayan Efsane' seçkisi açıyor.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Telif gelirlerinle genç sanatçılar için bağımsız bir akademi kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çağının en büyük kültür çınarlarından biri oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 38,
	              "sanity": 20,
	              "karma": 24,
	              "money_flat": 14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "sanat_efsanesi",
	              "edebiyat_yazari"
	            ],
	            "remove_tags": [],
	            "add_trait": "Ölümsüz Sanatçı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ödülü alıp sakin atölyende üretmeye devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Huzurlu ve saygın bir usta olarak tarihe geçtin.",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 32,
	              "sanity": 22,
	              "karma": 0,
	              "money_flat": 12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "sanat_efsanesi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_fam",
	    "arc_title": "Büyük Aile Sırrı ve Kayıp Miras",
	    "stages": [
	      {
	        "id": "arc_fam_1",
	        "title": "Büyük Aile Sırrı ve Kayıp Miras (Bölüm I): Döşeme Tahtasının Altındaki Osmanlı/Tarihi Tapu",
	        "category": "aile",
	        "vignette": "secret",
	        "context_note": "Yüzyıllık aile geçmişinden çıkan gizemli belgeler.",
	        "text": "Eski aile evinin tadilatı sırasında döşeme tahtalarının altında bakır bir muhafaza içinde 100 yıllık tapu kayıtları ve şifreli bir mektup buldun!",
	        "min_age": 22,
	        "max_age": 58,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Tarihçi ve hukukçularla anlaşarak belgelerin izini sür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Belgelerin şehir merkezindeki çok değerli bir han/araziye ait olduğu ortaya çıktı!",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": -600,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_fam_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fam_2",
	              "origin_note": "Büyük Aile Sırrı ve Kayıp Miras (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Eski kağıtlarla uğraşmayıp rafa kaldır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sır tozlu raflarda kaldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 2,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_fam_2",
	        "title": "Büyük Aile Sırrı ve Kayıp Miras (Bölüm II): Arşivdeki Karanlık İhanet",
	        "category": "aile",
	        "vignette": "secret",
	        "context_note": "Aile servetinin geçmişte hileli bir vekaletle el değiştirdiğinin anlaşılması.",
	        "text": "Tapu arşivinde yaptığın incelemede, 70 yıl önce ailenin en güvendiği ortağın sahte imzayla mülkü kendi üstüne geçirdiğini ve bugünkü zengin bir holdingin o mülk üzerinde yükseldiğini öğrendin!",
	        "min_age": 23,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Holdingin hukuk ordusuna karşı tarihi tapu iptal davası aç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Dava açıldı! Holding avukatları uzlaşmak için kapını aşındırmaya başladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": -6,
	              "karma": 12,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fam_3",
	              "origin_note": "Büyük Aile Sırrı ve Kayıp Miras (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Belgeleri holdinge gösterip sessizce tazminat talep et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlk uzlaşma masası kuruldu.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fam_3",
	              "origin_note": "Büyük Aile Sırrı ve Kayıp Miras (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_fam_3",
	        "title": "Büyük Aile Sırrı ve Kayıp Miras (Bölüm III): Kayıp Kardeş Kolu ve Aile Meclisi",
	        "category": "aile",
	        "vignette": "secret",
	        "context_note": "Dava sürecinde ortaya çıkan uzaktaki diğer mirasçılar.",
	        "text": "Mahkeme soy ağacını incelerken, dedenin yıllar önce küstüğü kardeşinin torunlarının da başka bir şehirde yoksulluk içinde yaşadığını tespit etti.",
	        "min_age": 24,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Onları bul, kucakla ve davaya eşit mirasçı olarak dahil et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yarım asırlık aile küslüğü bitti; mahkemede tek yumruk oldunuz!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 12,
	              "karma": 26,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fam_4",
	              "origin_note": "Büyük Aile Sırrı ve Kayıp Miras (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Onlardan habersiz sadece kendi payını kurtarmaya çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Payını büyüttün ama vicdanında bir düğüm kaldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": -14,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fam_4",
	              "origin_note": "Büyük Aile Sırrı ve Kayıp Miras (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_fam_4",
	        "title": "Büyük Aile Sırrı ve Kayıp Miras (Final): Yüksek Mahkeme Kararı: Adaletin Tecellisi",
	        "category": "aile",
	        "vignette": "secret",
	        "context_note": "Yıllar süren miras davasında son tokmak.",
	        "text": "Yüksek Mahkeme bilirkişi raporlarını onayladı ve tarihi mülkün/tazminatın yasal mirasçılara iadesine hükmetti!",
	        "min_age": 25,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Miras payını al ve tarihi binanın bir katını aile kültür müzesine dönüştür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem servet sahibi oldun hem de atalarının adını onurla yaşattın!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 28,
	              "sanity": 18,
	              "karma": 20,
	              "money_flat": 22000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tarihi_miras_kazandi",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Köklerine Sadık",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Mülkü hemen nakde çevirip servetin tadını çıkar",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Banka hesabına devasa bir miras yattı!",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 26000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tarihi_miras_kazandi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_med",
	    "arc_title": "Nadir Hastalık ve Tıbbi Mucize",
	    "stages": [
	      {
	        "id": "arc_med_1",
	        "title": "Nadir Hastalık ve Tıbbi Mucize (Bölüm I): Teşhis Konulamayan Nörolojik Semptomlar",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "Tıbbın sınırlarında başlayan hayatta kalma mücadelesi.",
	        "text": "Son aylarda ellerinde başlayan titreme ve ani baş dönmeleri için gittiğin üç hastane de farklı şeyler söyledi. Sonunda bir profesör çok nadir görülen bir sendromdan şüphelendi.",
	        "min_age": 20,
	        "max_age": 65,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Korkuya teslim olma; tıbbi literatürü kendin de tarayarak araştırma hastanesine başvur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Doğru teşhis konuldu ve mücadele protokolün başladı.",
	            "effects": {
	              "health": -6,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_med_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_med_2",
	              "origin_note": "Nadir Hastalık ve Tıbbi Mucize (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Hastalığı inkar edip tedaviyi geciktir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Semptomlar ağırlaştı.",
	            "effects": {
	              "health": -16,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_med_2",
	        "title": "Nadir Hastalık ve Tıbbi Mucize (Bölüm II): Faz-1 Deneysel Gen Tedavisi Teklifi",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "Henüz onaylanmamış öncü bir klinik araştırmaya gönüllü olma ikilemi.",
	        "text": "Uluslararası bir araştırma ekibi, yeni geliştirdikleri mRNA/Gen onarım tedavisinin ilk insan denemeleri (Faz-1) için seni aday seçti. Risk yüksek ama tam iyileşme şansı var.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Onam formunu imzala ve bilim adına deneysel tedaviye katıl",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlk hafta yüksek ateşle sarsıldın ama vücudun tedaviye olumlu yanıt vermeye başladı!",
	            "effects": {
	              "health": 8,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 4,
	              "karma": 12,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_med_3",
	              "origin_note": "Nadir Hastalık ve Tıbbi Mucize (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Klasik semptomatik ilaçlarla güvenli kalmayı seç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hastalığın ilerlemesi yavaşlatıldı.",
	            "effects": {
	              "health": 2,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_med_3",
	              "origin_note": "Nadir Hastalık ve Tıbbi Mucize (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_med_3",
	        "title": "Nadir Hastalık ve Tıbbi Mucize (Bölüm III): Klinik Verilerin Manipülasyonu Şüphesi",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "İlaç şirketinin yan etkileri gizleme girişimi.",
	        "text": "Tedavi grubundaki diğer hastalarla konuşurken, sponsor firmanın bazı yan etkileri rapordan çıkardığını fark ettin.",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hastalar birliği kurup bağımsız etik kurulun denetim yapmasını sağla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Formül düzeltildi; hem kendi hayatını hem de binlerce hastanın güvenliğini kurtardın!",
	            "effects": {
	              "health": 12,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 24,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_med_4",
	              "origin_note": "Nadir Hastalık ve Tıbbi Mucize (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Sadece kendi dozuna odaklanıp tartışmadan uzak dur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Tedavin tamamlandı.",
	            "effects": {
	              "health": 8,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_med_4",
	              "origin_note": "Nadir Hastalık ve Tıbbi Mucize (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_med_4",
	        "title": "Nadir Hastalık ve Tıbbi Mucize (Final): Tam Remisyon (Şifa) ve Hasta Hakları Vakfı",
	        "category": "saglik",
	        "vignette": "hospital",
	        "context_note": "Tıbbi mucizenin tamamlanması.",
	        "text": "Son MR ve kan tahlillerin tertemiz çıktı! Doktorlar senin vakanı tıp kongresinde 'Tam İyileşme Mucizesi' olarak sunuyor.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Nadir hastalıklarla mücadele edenler için uluslararası bir dayanışma vakfı kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kendi acından binlerce insana umut olan bir şifa hareketi doğurdun!",
	            "effects": {
	              "health": 22,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 20,
	              "karma": 28,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tibbi_mucize",
	              "sifa_elcisi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Yaşama Tutunan",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "İkinci hayatını sevdiklerinle sessiz ve sağlıklı biçimde kutla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yeniden doğmuş gibi sağlıklı bir ömre kavuştun.",
	            "effects": {
	              "health": 24,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 20,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "tibbi_mucize"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_sport",
	    "arc_title": "Tozlu Sahalardan Dünya Stadyumlarına",
	    "stages": [
	      {
	        "id": "arc_sport_1",
	        "title": "Tozlu Sahalardan Dünya Stadyumlarına (Bölüm I): Altyapı Seçmeleri ve Yırtık Krampon",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Profesyonel spor kariyerinin ilk kıvılcımı.",
	        "text": "Bölge seçmelerinde yağmur altında yüzlerce genç yetenek yarışıyor. Son 15 dakikada oyuna alındın.",
	        "min_age": 15,
	        "max_age": 34,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Bencillik yapmadan hem gol at hem asist yap; oyun zekanı göster",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Başantrenör adını listenin en başına yazdı; akademi sözleşmesini kaptın!",
	            "effects": {
	              "health": 10,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_sport_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sport_2",
	              "origin_note": "Tozlu Sahalardan Dünya Stadyumlarına (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Tek başına çalım atmaya çalışırken topu kaptır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yedek kadrodan zorlukla kabul edildin.",
	            "effects": {
	              "health": 4,
	              "happiness": 4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_sport_2",
	        "title": "Tozlu Sahalardan Dünya Stadyumlarına (Bölüm II): Derbi Maçında İlk 11 ve Menajer Tuzağı",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Genç yıldızların etrafını saran menajerler ve gece hayatı.",
	        "text": "A takımla çıktığın ilk derbi maçında galibiyet sayısını/golünü sen attın! Ertesi gün lüks araçlı menajerler ve magazin basını kapında.",
	        "min_age": 16,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Gece hayatından uzak dur, bireysel antrenör tut ve kurumsal bir menajerle çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Performansın istikrarla yükseldi; Avrupa/Dünya devlerinin radarına girdin!",
	            "effects": {
	              "health": 12,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 6800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sport_3",
	              "origin_note": "Tozlu Sahalardan Dünya Stadyumlarına (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Şöhretin tadını çıkarıp antrenmanları aksat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Magazin sayfalarına düştün, hocan seni yedek kulübesine çekti.",
	            "effects": {
	              "health": -6,
	              "happiness": 8,
	              "smart": 0,
	              "reputation": -10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sport_3",
	              "origin_note": "Tozlu Sahalardan Dünya Stadyumlarına (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_sport_3",
	        "title": "Tozlu Sahalardan Dünya Stadyumlarına (Bölüm III): Şampiyonlar Finali ve Sakatlık İğnesi",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Kariyerin en büyük maçı öncesi ayak bileği burkulması.",
	        "text": "Büyük kupa finalinden bir gün önce antrenmanda bileğin şişti. Kulüp doktoru 'Uyuşturucu iğneyle oynayabilirsin ama riskli' diyor.",
	        "min_age": 17,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Bandaj ve akıllı pozisyon bilgisiyle sahaya çıkıp takımına liderlik et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "70 dakika sahada kalıp kupanın kazanılmasında başrolü oynadın!",
	            "effects": {
	              "health": -6,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 30,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sport_4",
	              "origin_note": "Tozlu Sahalardan Dünya Stadyumlarına (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Sağlığını riske atmayıp kenardan takım arkadaşlarını motive et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Takımın kupayı aldı, sen de sakatlığını kalıcı olmadan atlattın.",
	            "effects": {
	              "health": 8,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_sport_4",
	              "origin_note": "Tozlu Sahalardan Dünya Stadyumlarına (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_sport_4",
	        "title": "Tozlu Sahalardan Dünya Stadyumlarına (Final): Jübile Gecesi ve Spor Akademisi Mirası",
	        "category": "kariyer",
	        "vignette": "sports",
	        "context_note": "Aktif sporculuktan efsaneliğe geçiş.",
	        "text": "60.000 taraftarın senin adını haykırdığı stadyumda son kez sahaya çıkıyorsun. Forman kulüp müzesinin tavanına asılıyor!",
	        "min_age": 18,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Birikiminle dar gelirli çocuklar için ücretsiz spor ve eğitim akademisi kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sadece saha içinde değil, saha dışında da ölümsüz bir spor efsanesi oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 38,
	              "sanity": 20,
	              "karma": 28,
	              "money_flat": 18000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "spor_efsanesi",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Şampiyon",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Teknik direktör ve spor yorumcusu olarak kariyerine devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Futbol/spor dünyasının en saygın taktik dehalarından biri oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 8,
	              "reputation": 30,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 20000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "spor_efsanesi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_fin",
	    "arc_title": "Borsa Kuleleri ve İçeriden Bilgi Sınavı",
	    "stages": [
	      {
	        "id": "arc_fin_1",
	        "title": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (Bölüm I): Gece Yarısı Şifreli Birleşme Dosyası",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Finans piyasalarında haksız kazanç (Insider Trading) tuzağı.",
	        "text": "Yatırım masasında çalışırken yarın sabah açıklanacak dev bir şirket satın almasının gizli dosyasını tesadüfen gördün. Hisseler sabah %80 fırlayacak!",
	        "min_age": 23,
	        "max_age": 55,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yasalara uy; içeriden bilgiyle işlem yapmayıp kendi kantitatif algoritmanı kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Temiz ve matematiksel fon yönetiminle yatırımcıların güvenini kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 10,
	              "reputation": 16,
	              "sanity": 8,
	              "karma": 14,
	              "money_flat": 3800,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_fin_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fin_2",
	              "origin_note": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Başkalarının hesapları üzerinden gizlice hisse topla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bir gecede servet kazandın ama Sermaye Piyasası Kurulu algoritmaları işlemi işaretledi!",
	            "effects": {
	              "health": 0,
	              "happiness": 12,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -10,
	              "karma": -22,
	              "money_flat": 12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_fin_2",
	        "title": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (Bölüm II): Hedge Fon Kuruluşu ve Açığa Satış (Short) Savaşı",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Piyasa balonuyla mücadele.",
	        "text": "Borsada içi boş bir şirketin hisselerinin manipülasyonla şişirildiğini tespit ettin. Açığa satış (Short) pozisyonu açarsan ya ihya olacaksın ya da batacaksın.",
	        "min_age": 24,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Bilanço hilelerini belgeleyen 100 sayfalık analiz raporunu yayımlayıp pozisyon aç",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 68
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Balon patladı! Piyasayı temizlerken fonuna rekor getiri kazandırdın.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 10,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 11000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fin_3",
	              "origin_note": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Riskli savaşa girmeden altın ve tahvil sepetinde kal",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sermayeni güvenle korudun.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fin_3",
	              "origin_note": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_fin_3",
	        "title": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (Bölüm III): Küresel Likidite Krizi ve Müşteri Paniği",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Yatırımcıların aynı anda paralarını çekmek istemesi.",
	        "text": "Piyasalarda panik çıktı; fonundaki müşteriler anaparalarını hemen çekmek için sıraya girdi.",
	        "min_age": 25,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Şeffaf bir canlı yayınla portföy teminatlarını gösterip panik ateşini söndür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yatırımcılar sana güvendi ve fonunu çekmekten vazgeçti!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 6000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fin_4",
	              "origin_note": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Kendi kişisel nakdini teminat göstererek çıkışları karşıla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İtibarını korudun.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 14,
	              "money_flat": -2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_fin_4",
	              "origin_note": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_fin_4",
	        "title": "Borsa Kuleleri ve İçeriden Bilgi Sınavı (Final): Finans Denetim Kurulu ve Efsanevi Fon Yöneticisi",
	        "category": "ekonomi",
	        "vignette": "finance",
	        "context_note": "Finans dünyasındaki nihai karne.",
	        "text": "Sermaye Piyasası denetçileri 10 yıllık tüm fon işlemlerini inceledi ve raporunu açıkladı.",
	        "min_age": 26,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Sıfır kusurla denetimden geç ve ülkenin en güvenilir yatırım fonu başkanı ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Finans dünyasının 'Bilge Kahini' unvanını ve büyük bir serveti kazandın!",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 34,
	              "sanity": 18,
	              "karma": 0,
	              "money_flat": 26000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "finans_efsanesi",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Piyasa Kahini",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Fon yönetimini devredip kendi aile ofisini (Family Office) kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Stresten uzak, servetini yönettiğin huzurlu bir hayata geçtin.",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 22,
	              "karma": 0,
	              "money_flat": 20000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "finans_efsanesi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_jour",
	    "arc_title": "Karanlık Dosya: Araştırmacı Gazetecilik",
	    "stages": [
	      {
	        "id": "arc_jour_1",
	        "title": "Karanlık Dosya: Araştırmacı Gazetecilik (Bölüm I): Gece Yarısı Otoparkta Verilen Flash Bellek",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Kamu ihaleleri ve zehirli gıda/ilaç şebekesini ifşa eden belgeler.",
	        "text": "Yağmurlu bir gecede ismini gizleyen bir kaynak sana binlerce gizli yazışma içeren şifreli bir bellek verdi: 'Bunu yayınlarsan yer yerinden oynar ama peşine düşerler.'",
	        "min_age": 22,
	        "max_age": 55,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Belgeleri üç ayrı bağımsız kaynaktan doğrulatıp yazı dizisini hazırla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlk manşet yayınlandığı sabah ülkede gündem altüst oldu!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 22,
	              "sanity": -4,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_jour_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_jour_2",
	              "origin_note": "Karanlık Dosya: Araştırmacı Gazetecilik (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Tehlikeyi göze alamayıp belleği imha et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Güvende kaldın.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 4,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_jour_2",
	        "title": "Karanlık Dosya: Araştırmacı Gazetecilik (Bölüm II): Sansür Baskısı ve İlan Kesintisi",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Şebekenin medya patronuna baskı yaparak seni susturmaya çalışması.",
	        "text": "Yazı dizisinin ikinci bölümü basılmadan önce genel yayın yönetmeni odana geldi: 'Reklamverenler çekiliyor, bu dosyayı burada kapatıyoruz!'",
	        "min_age": 23,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "İstifa et ve bağımsız okur fonlu dijital medya platformunda dosyayı yayınla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Yüz binlerce okur aboneliğiyle bağımsız gazeteciliğin kalesi oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 28,
	              "sanity": 0,
	              "karma": 22,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_jour_3",
	              "origin_note": "Karanlık Dosya: Araştırmacı Gazetecilik (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Belgeleri uluslararası basın konsorsiyumuyla eşzamanlı paylaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sansür duvarı aşıldı, haber tüm dünyada manşet oldu!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 20,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_jour_3",
	              "origin_note": "Karanlık Dosya: Araştırmacı Gazetecilik (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_jour_3",
	        "title": "Karanlık Dosya: Araştırmacı Gazetecilik (Bölüm III): Tazminat Davaları ve Mahkeme Salonu",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "İfşa olan baronların açtığı milyonluk susturma davaları (SLAPP).",
	        "text": "Hakkında 15 ayrı tazminat davası açıldı. Bugün hakim karşısında belgelerin gerçekliğini ve kamu yararını savunacaksın.",
	        "min_age": 24,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kusursuz kanıt zinciriyle mahkemede tüm suçlamaları çürüt",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Beraat ettin ve mahkeme baronlar hakkında tutuklama kararı çıkardı!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 30,
	              "sanity": 14,
	              "karma": 24,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_jour_4",
	              "origin_note": "Karanlık Dosya: Araştırmacı Gazetecilik (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Basın meslek örgütlerinin avukat ordusuyla savunma yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Dayanışmayla davaları kazandın.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 10,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_jour_4",
	              "origin_note": "Karanlık Dosya: Araştırmacı Gazetecilik (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_jour_4",
	        "title": "Karanlık Dosya: Araştırmacı Gazetecilik (Final): Uluslararası Basın Özgürlüğü ve Pulitzer Onuru",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Gerçeğin peşinde geçen yılların taçlanması.",
	        "text": "Kalemini satmadan ortaya çıkardığın gerçekler sayesinde yasalar değişti ve Uluslararası Basın Onur Ödülü'ne layık görüldün.",
	        "min_age": 25,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ödülü al ve genç araştırmacı gazeteciler için bağımsız bir okul kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hakikatin korkusuz kalemi olarak tarihe geçtin!",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 38,
	              "sanity": 18,
	              "karma": 30,
	              "money_flat": 8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "onurlu_gazeteci"
	            ],
	            "remove_tags": [],
	            "add_trait": "Hakikat Savaşçısı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Araştırmalarını belgesel ve kitap serisine dönüştür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kitapların milyonlarca okura ulaştı.",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 32,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 11000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "onurlu_gazeteci"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_eco",
	    "arc_title": "Kuruyan Vadiyi Yeşerten Mücadele",
	    "stages": [
	      {
	        "id": "arc_eco_1",
	        "title": "Kuruyan Vadiyi Yeşerten Mücadele (Bölüm I): Kuruyan Göl ve Çatlayan Topraklar",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "İklim krizi ve vahşi sulama nedeniyle yok olan su havzası.",
	        "text": "Çocukluğunda kıyısında yürüdüğün gölün yarı yarıya çekildiğini ve köylülerin göç etmeye başladığını gördün.",
	        "min_age": 20,
	        "max_age": 65,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Toprak analizleri yapıp kuraklığa dayanıklı tarım ve yağmur hasadı projesi başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "İlk pilot tarlada %60 su tasarrufuyla rekor ürün alındı!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 8,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_eco_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_eco_2",
	              "origin_note": "Kuruyan Vadiyi Yeşerten Mücadele (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Duruma üzülüp şehre geri dön",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sadece uzaktan izledin.",
	            "effects": {
	              "health": 0,
	              "happiness": -2,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_eco_2",
	        "title": "Kuruyan Vadiyi Yeşerten Mücadele (Bölüm II): Maden Şirketinin Siyanür Havuzu Planı",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "Su kaynağının tam üstüne kurulmak istenen maden tesisi.",
	        "text": "Uluslararası bir maden şirketi vadinin su kaynağına atık barajı kurmak için ruhsat aldı. Köylüler senin öncülük etmeni bekliyor.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Hidrojeoloji raporlarıyla İdare Mahkemesi'nde yürütmeyi durdurma davası aç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bilimsel kanıtlar karşısında mahkeme ruhsatı iptal etti!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 26,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_eco_3",
	              "origin_note": "Kuruyan Vadiyi Yeşerten Mücadele (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Bölgeyi ekoturizm ve jeopark alanı ilan ettirerek koruma kalkanına al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Vadi milli park statüsü kazandı!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 22,
	              "money_flat": 2500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_eco_3",
	              "origin_note": "Kuruyan Vadiyi Yeşerten Mücadele (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_eco_3",
	        "title": "Kuruyan Vadiyi Yeşerten Mücadele (Bölüm III): On Milyon Meşe ve Zeytin Tohumu Seferberliği",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "Bozkırı yeniden ormana dönüştürme.",
	        "text": "Kurduğun çevre hareketi binlerce gönüllüye ulaştı. Çorak yamaçları yeniden ormanlaştırmak için büyük kampanya başlıyor.",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Beş yıl boyunca her sonbahar binlerce fidanı toprakla buluştur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Mikroklima değişti; kuruyan pınarlar yeniden akmaya başladı!",
	            "effects": {
	              "health": 14,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 30,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_eco_4",
	              "origin_note": "Kuruyan Vadiyi Yeşerten Mücadele (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Güneş enerjili tarım kooperatifi kurarak köylüyü zenginleştir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem doğa korundu hem bölge ekonomisi canlandı.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 5500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_eco_4",
	              "origin_note": "Kuruyan Vadiyi Yeşerten Mücadele (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_eco_4",
	        "title": "Kuruyan Vadiyi Yeşerten Mücadele (Final): Birleşmiş Milletler Toprak ve Yaşam Ödülü",
	        "category": "felsefe",
	        "vignette": "nature",
	        "context_note": "Çölleşmeyi durduran yerel mucizenin dünyaya örnek olması.",
	        "text": "Yıllar önce çatlamış topraklardan ibaret olan vadi bugün yemyeşil bir orman ve tarım vahası! BM Çevre Programı seni Yılın Doğa Kahramanı seçti.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ödülü tüm vadi halkı adına al ve tohum bankası kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Toprağa bıraktığın yeşil miras yüzyıllar boyu nefes olacak!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 34,
	              "sanity": 22,
	              "karma": 35,
	              "money_flat": 7000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "doga_kahramani"
	            ],
	            "remove_tags": [],
	            "add_trait": "Toprak Bilgesi",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Ormanın içindeki taş evinde huzurlu bir hayat sür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kendi yeşerttiğin ormanın gölgesinde eşsiz bir ömür sürdün.",
	            "effects": {
	              "health": 18,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 24,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "doga_kahramani"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_chef",
	    "arc_title": "Sokak Tezgahından Gastronomi Zirvesine",
	    "stages": [
	      {
	        "id": "arc_chef_1",
	        "title": "Sokak Tezgahından Gastronomi Zirvesine (Bölüm I): Kömür Ateşinde Babanne Tarifi",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Gastronomi tutkusunun küçük bir tezgahla başlaması.",
	        "text": "Aileden kalan gizli baharat ve sos tarifiyle hazırladığın yemekler, küçük sokak tezgahının önünde uzun kuyruklar oluşturmaya başladı.",
	        "min_age": 19,
	        "max_age": 55,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Malzeme kalitesinden asla ödün verme ve ilk küçük dükkanını kirala",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Şehrin en lezzetli durağı olarak dilden dile yayıldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2200,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_chef_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_chef_2",
	              "origin_note": "Sokak Tezgahından Gastronomi Zirvesine (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Ucuz malzeme kullanıp sürümden kazanmaya çalış",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Müşteriler lezzet farkını anladı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": -6,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 900,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_chef_2",
	        "title": "Sokak Tezgahından Gastronomi Zirvesine (Bölüm II): Gizli Gurme Eleştirmeninin Ziyareti",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Yağmurlu bir akşam köşedeki masaya oturan gizemli müşteri.",
	        "text": "Mutfağın en yoğun olduğu akşam, ülkenin en sert yemek eleştirmeni kimliğini gizleyerek dükkanına geldi ve imza tabağını sipariş etti.",
	        "min_age": 20,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yerel malzemeleri modern pişirme tekniğiyle harmanlayıp kusursuz tabağı sun",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Pazar günü gazetede 'Bir Başyapıt Doğuyor' başlığıyla tam puan aldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 5800,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_chef_3",
	              "origin_note": "Sokak Tezgahından Gastronomi Zirvesine (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Klasik ev usulü sıcak sunumundan şaşma",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Samimiyetin ve lezzetin övgü aldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_chef_3",
	              "origin_note": "Sokak Tezgahından Gastronomi Zirvesine (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_chef_3",
	        "title": "Sokak Tezgahından Gastronomi Zirvesine (Bölüm III): Zincirleşme Teklifi mi, Butik Şef Restoranı mı?",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Hızlı para ile mutfak sanatı arasındaki ayrım.",
	        "text": "Büyük bir gıda holdingi markanı satın alıp 100 AVM'de fast-food zincirine dönüştürmek istiyor.",
	        "min_age": 21,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Zincirleşmeyi reddet; kendi bahçenden malzeme kullanan 12 masalık şef restoranı kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Aylar öncesinden rezervasyon yapılan uluslararası bir gastronomi tapınağı yarattın!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 28,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_chef_4",
	              "origin_note": "Sokak Tezgahından Gastronomi Zirvesine (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Franchise anlaşması imzalayıp ticari büyümeyi seç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Her şehirde şubelerin açıldı, servetin katlandı!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 14000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_chef_4",
	              "origin_note": "Sokak Tezgahından Gastronomi Zirvesine (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_chef_4",
	        "title": "Sokak Tezgahından Gastronomi Zirvesine (Final): Michelin Yıldızı ve Gastronomi Mirası",
	        "category": "kariyer",
	        "vignette": "work",
	        "context_note": "Mutfak sanatlarının en yüksek nişanı.",
	        "text": "Uluslararası gastronomi rehberi töreninde sahneye senin adın okundu! Beyaz şef ceketini giyip ödülü alıyorsun.",
	        "min_age": 22,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Ödülü yerel çiftçilere ve mutfak ekibine adayıp yemek kültürü akademisi aç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ülkenin mutfak kültürünü dünyaya tanıtan efsanevi Başşef oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 36,
	              "sanity": 18,
	              "karma": 20,
	              "money_flat": 16000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "michelin_sefi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Lezzet Üstadı",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Dünya başkentlerinde şubeler açarak küresel bir imparatorluk kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem yıldızlı bir şef hem de çok zengin bir iş insanı oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 32,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 24000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "michelin_sefi",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_dip",
	    "arc_title": "Diplomatik Kulis ve Gölge Satrancı",
	    "stages": [
	      {
	        "id": "arc_dip_1",
	        "title": "Diplomatik Kulis ve Gölge Satrancı (Bölüm I): Dışişleri Sınavı ve Şifreli Telgraf",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Uluslararası krizlerin perde arkasındaki sessiz görev.",
	        "text": "Yabancı dil ve strateji yeteneğin nedeniyle uluslararası bir kriz masasında özel ataşe/uzman olarak görevlendirildin.",
	        "min_age": 23,
	        "max_age": 58,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 65
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kriz bölgesindeki yerel aktörlerle doğrudan diyalog kurup istihbarat topla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Büyükelçiliğin en güvenilir kriz çözücüsü oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 10,
	              "reputation": 18,
	              "sanity": -4,
	              "karma": 0,
	              "money_flat": 3500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_dip_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dip_2",
	              "origin_note": "Diplomatik Kulis ve Gölge Satrancı (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Masa başı protokol görevlerinde kal",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Güvenli bir diplomatik kariyer sürdürdün.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 8,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_dip_2",
	        "title": "Diplomatik Kulis ve Gölge Satrancı (Bölüm II): Tarafsız Şehirde Gece Yarısı Rehine/Kriz Müzakeresi",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "İki ülke arasında savaş çıkarabilecek gerilimi düşürme.",
	        "text": "Cenevre/İstanbul'da kapalı kapılar ardında yürütülen gizli müzakerede taraflar masayı devirmek üzere. Söz sırası sende.",
	        "min_age": 24,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Her iki tarafın da onurunu kurtaran yaratıcı bir ara formül (Kazan-Kazan) sun",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 70
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Anlaşma imzalandı! Olası bir çatışmayı masa başında önledin.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 8,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 24,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dip_3",
	              "origin_note": "Diplomatik Kulis ve Gölge Satrancı (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Sert caydırıcılık kartını masaya sür",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Karşı taraf geri adım attı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": -6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dip_3",
	              "origin_note": "Diplomatik Kulis ve Gölge Satrancı (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_dip_3",
	        "title": "Diplomatik Kulis ve Gölge Satrancı (Bölüm III): Çift Taraflı Ajan ve Bilgi Sızıntısı",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Diplomatik heyetteki sızıntıyı yakalama.",
	        "text": "Gizli müzakere tutanaklarının yabancı bir lobiye sızdırıldığını fark ettin.",
	        "min_age": 25,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Farklı nüshalara gizli işaretler (Canary Trap) koyarak köstebeği suçüstü yakala",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Zekice kurduğun tuzakla sızıntıyı kaynağında kurbansız kopardın!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 10,
	              "reputation": 24,
	              "sanity": 8,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dip_4",
	              "origin_note": "Diplomatik Kulis ve Gölge Satrancı (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Güvenlik birimine devredip dosyayı kapat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sorun çözüldü.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 10,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dip_4",
	              "origin_note": "Diplomatik Kulis ve Gölge Satrancı (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_dip_4",
	        "title": "Diplomatik Kulis ve Gölge Satrancı (Final): Büyükelçilik Kararnamesi ve Barış Nişanı",
	        "category": "kariyer",
	        "vignette": "secret",
	        "context_note": "Diplomasi sanatının zirvesi.",
	        "text": "Yıllarca yürüttüğün sessiz ve etkili diplomasi sonucunda Büyükelçi / Uluslararası Özel Temsilci unvanına atandın.",
	        "min_age": 26,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Barış anlaşmalarına öncülük et ve diplomasi hatıratını yaz",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Uluslararası ilişkiler tarihinde efsanevi bir Büyükelçi olarak yerini aldın!",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 36,
	              "sanity": 18,
	              "karma": 22,
	              "money_flat": 12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "buyukelci"
	            ],
	            "remove_tags": [],
	            "add_trait": "Gölge Diplomat",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Uluslararası düşünce kuruluşunun (Think-Tank) başına geç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Dünya siyasetine yön veren bir stratejist oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 30,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 15000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "buyukelci"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_zen",
	    "arc_title": "Modern Dünyadan İnzivaya: Bilgelik Yolu",
	    "stages": [
	      {
	        "id": "arc_zen_1",
	        "title": "Modern Dünyadan İnzivaya: Bilgelik Yolu (Bölüm I): Gürültünün Ortasında Sessizlik Çağrısı",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "Tüketim ve hız çağının anlamsızlığını fark etme.",
	        "text": "Bildirim sesleri, bitmeyen hırslar ve yapay kalabalıklar ruhunu boğmaya başladı. İçinde sade ve hakiki bir yaşama dönme çağrısı var.",
	        "min_age": 26,
	        "max_age": 75,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Fazla eşyalarını dağıt, ekran süreni sıfırla ve felsefi bir sadeliğe adım at",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Omuzlarındaki görünmez yükler kalktı; derin bir nefes aldın.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 20,
	              "karma": 12,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_zen_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_zen_2",
	              "origin_note": "Modern Dünyadan İnzivaya: Bilgelik Yolu (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Şehir temposuna devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Rutin sürdü.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": -2,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_zen_2",
	        "title": "Modern Dünyadan İnzivaya: Bilgelik Yolu (Bölüm II): Dağ Kulübesinde Kırk Günlük Sessizlik",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "Kendi zihninin derinlikleriyle yüzleşme.",
	        "text": "Orman/dağ eteğindeki taş bir kulübede 40 gün boyunca sadece doğayı dinleyip felsefe ve iç gözlem yapma kararı aldın.",
	        "min_age": 27,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Korkularınla ve geçmişinle yüzleşip içsel dinginliğe ulaş",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kırkıncı günün şafağında zihnin kristal bir su gibi berraklaştı!",
	            "effects": {
	              "health": 12,
	              "happiness": 20,
	              "smart": 10,
	              "reputation": 0,
	              "sanity": 26,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_zen_3",
	              "origin_note": "Modern Dünyadan İnzivaya: Bilgelik Yolu (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Doğa notları ve şiirler kaleme al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Notların elden ele dolaşan bir başucu kitabına dönüştü.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 16,
	              "sanity": 18,
	              "karma": 0,
	              "money_flat": 2000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_zen_3",
	              "origin_note": "Modern Dünyadan İnzivaya: Bilgelik Yolu (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_zen_3",
	        "title": "Modern Dünyadan İnzivaya: Bilgelik Yolu (Bölüm III): Yolunu Kaybedenlerin Uğrak Noktası",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "İnziva evinin bilgelik arayanların durağı haline gelmesi.",
	        "text": "Sen şöhretten kaçtıkça, hayatın anlamını arayan gençler ve tükenmiş şehir insanları seninle bir bardak çay içip öğüt almak için kapına gelmeye başladı.",
	        "min_age": 28,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kapını herkese karşılıksız aç; birlikte toprak işleyip felsefe konuşulan bir okul kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hiçbir ücret almadan yüzlerce ruhun iyileşmesine vesile oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 0,
	              "reputation": 28,
	              "sanity": 20,
	              "karma": 30,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_zen_4",
	              "origin_note": "Modern Dünyadan İnzivaya: Bilgelik Yolu (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Sadece yazılı eserlerinle insanlara seslenmeyi seç",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Sessizliğini koruyarak bilgelik yaydın.",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 20,
	              "sanity": 24,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_zen_4",
	              "origin_note": "Modern Dünyadan İnzivaya: Bilgelik Yolu (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_zen_4",
	        "title": "Modern Dünyadan İnzivaya: Bilgelik Yolu (Final): Bozkırın / Dağların Yaşayan Bilgesi",
	        "category": "felsefe",
	        "vignette": "philosophy",
	        "context_note": "Tam aydınlanma ve iç huzur.",
	        "text": "Artık ne ölüm korkusu ne de dünya hırsı kalbinde yer bulabiliyor. Doğayla ve insanlıkla tam bir uyum içindesin.",
	        "min_age": 29,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Felsefi külliyatını tamamla ve huzur içinde yaşamaya devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çağının yaşayan bilgesi olarak gönüllerde ölümsüzleştin!",
	            "effects": {
	              "health": 14,
	              "happiness": 30,
	              "smart": 0,
	              "reputation": 30,
	              "sanity": 30,
	              "karma": 30,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "yasayan_bilge"
	            ],
	            "remove_tags": [],
	            "add_trait": "Aydınlanmış Ruh",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Sessiz bir tebessümle doğanın parçası ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Saf huzura ulaştın.",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 30,
	              "karma": 25,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "yasayan_bilge"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_lab",
	    "arc_title": "Alın Teri ve Dayanışma Destanı",
	    "stages": [
	      {
	        "id": "arc_lab_1",
	        "title": "Alın Teri ve Dayanışma Destanı (Bölüm I): Fabrika/Ofis Koridorunda Güvencesizliğe İtiraz",
	        "category": "kariyer",
	        "vignette": "protest",
	        "context_note": "Emekçilerin ödenmeyen fazla mesaileri ve iş güvenliği ihmalleri.",
	        "text": "Çalıştığın iş yerinde iş kazaları artarken yönetim maaş zamlarını enflasyonun altında bıraktı. Arkadaşların ses çıkaracak bir sözcü arıyor.",
	        "min_age": 20,
	        "max_age": 58,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Öne çık ve yasal sendikal örgütlenme / çalışan konseyi hakkını başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Çalışanların %80'i etrafında kenetlendi!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": -4,
	              "karma": 18,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_lab_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_lab_2",
	              "origin_note": "Alın Teri ve Dayanışma Destanı (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Risk almayıp sessiz kal",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Düzen değişmedi.",
	            "effects": {
	              "health": 0,
	              "happiness": -4,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_lab_2",
	        "title": "Alın Teri ve Dayanışma Destanı (Bölüm II): Kış Ortasında Grev Çadırı ve Dayanışma Ateşi",
	        "category": "kariyer",
	        "vignette": "protest",
	        "context_note": "Toplu sözleşme masasının tıkanması üzerine başlayan tarihi grev.",
	        "text": "Yönetim temsilcileri işten çıkarmakla tehdit etti! Fabrika/şirket önünde grev ateşi yakıldı; basın kameraları senin konuşmanı bekliyor.",
	        "min_age": 21,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Şiddetten uzak, hukuki ve kararlı bir direnişle kamuoyunun desteğini kazan",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Bütün ülke sizin haklı mücadelenize destek verdi; yönetim masaya dönmek zorunda kaldı!",
	            "effects": {
	              "health": 0,
	              "happiness": 18,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 24,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_lab_3",
	              "origin_note": "Alın Teri ve Dayanışma Destanı (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Ara bulucu üzerinden hızlı uzlaşma sağla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kısmi zam ve güvence alındı.",
	            "effects": {
	              "health": 0,
	              "happiness": 10,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 1500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_lab_3",
	              "origin_note": "Alın Teri ve Dayanışma Destanı (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_lab_3",
	        "title": "Alın Teri ve Dayanışma Destanı (Bölüm III): Toplu Sözleşme Zaferi ve Kooperatifleşme",
	        "category": "kariyer",
	        "vignette": "protest",
	        "context_note": "Emek mücadelesinin kurumsal kazanıma dönüşmesi.",
	        "text": "Tarihi toplu iş sözleşmesi imzalandı! Şimdi çalışanların kârdan pay aldığı ve çocuklarının burs aldığı bir sandık kurma vakti.",
	        "min_age": 22,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Şeffaf emeklilik ve eğitim sandığını kurarak binlerce aileyi güvenceye al",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Modelin çalışma ekonomisi derslerinde örnek olarak okutulmaya başlandı!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 8,
	              "reputation": 28,
	              "sanity": 0,
	              "karma": 26,
	              "money_flat": 3200,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_lab_4",
	              "origin_note": "Alın Teri ve Dayanışma Destanı (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Konfederasyon genel başkanlığına seçil",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Ülke çapında milyonlarca emekçinin sesi oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 26,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_lab_4",
	              "origin_note": "Alın Teri ve Dayanışma Destanı (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_lab_4",
	        "title": "Alın Teri ve Dayanışma Destanı (Final): Emek Onur Anıtı ve Halkın Sevgisi",
	        "category": "kariyer",
	        "vignette": "protest",
	        "context_note": "Alın terine adanmış bir ömrün meyvesi.",
	        "text": "Sayende binlerce işçi güvenli şartlarda çalıştı ve çocuklarını okuttu. Emekliliğinde tüm çalışanlar senin onuruna büyük bir tören düzenliyor.",
	        "min_age": 23,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Alnın açık, başın dik olarak halkın alkışlarını selamla",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Emek tarihine adını altın harflerle yazdırdın!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 36,
	              "sanity": 20,
	              "karma": 32,
	              "money_flat": 5000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "emek_kahramani"
	            ],
	            "remove_tags": [],
	            "add_trait": "Halkın Sesi",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Uluslararası Çalışma Örgütü (ILO) danışmanı olarak deneyimlerini dünyaya aktar",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Küresel çapta saygın bir sosyal politika uzmanı oldun.",
	            "effects": {
	              "health": 0,
	              "happiness": 24,
	              "smart": 0,
	              "reputation": 32,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 8500,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "emek_kahramani"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_arch",
	    "arc_title": "Kumların Altındaki Kayıp Uygarlık",
	    "stages": [
	      {
	        "id": "arc_arch_1",
	        "title": "Kumların Altındaki Kayıp Uygarlık (Bölüm I): Antik Haritadaki Silik Koordinat",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Tarihin akışını değiştirecek arkeolojik iz.",
	        "text": "Kütüphane arşivinde incelediğin eski bir seyyah günlüğünde, varlığı efsane sanılan antik bir kentin yerini işaret eden astronomik ipuçları buldun!",
	        "min_age": 22,
	        "max_age": 60,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {
	            "smart": 62
	          },
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kültür Bakanlığı ve üniversiteden kazı izni alıp araziye çık",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Jeoradar taramalarında toprağın 4 metre altında devasa sütunlar tespit edildi!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 10,
	              "reputation": 16,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_arch_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_arch_2",
	              "origin_note": "Kumların Altındaki Kayıp Uygarlık (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "Teorik bir makale yazmakla yetin",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Makalen ilgi gördü.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 6,
	              "reputation": 6,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_arch_2",
	        "title": "Kumların Altındaki Kayıp Uygarlık (Bölüm II): Fırtına Altında Açılan Mühürlü Tapınak Odası",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Binlerce yıldır insan ayağı değmemiş odanın keşfi.",
	        "text": "Kazının üçüncü ayında taş kapı açıldı! İçeride hiç bozulmamış mozaikler ve bilinmeyen bir yazı sistemiyle yazılmış kil tabletler duruyor.",
	        "min_age": 23,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Tabletleri yerinde koruma altına alıp gece gündüz antik dili çözmeye çalış",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 70
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kayıp alfabeyi çözen ilk insan olarak dünya arkeoloji tarihine geçtin!",
	            "effects": {
	              "health": 0,
	              "happiness": 22,
	              "smart": 14,
	              "reputation": 28,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_arch_3",
	              "origin_note": "Kumların Altındaki Kayıp Uygarlık (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Uluslararası uzman ekiple ortak kataloglama yap",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kazı bulguları tüm dünya medyasında yer aldı.",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 22,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 3000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_arch_3",
	              "origin_note": "Kumların Altındaki Kayıp Uygarlık (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_arch_3",
	        "title": "Kumların Altındaki Kayıp Uygarlık (Bölüm III): Tarihi Eser Kaçakçılarının Gece Baskını",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Kazı alanını hedef alan silahlı şebeke.",
	        "text": "Gece yarısı kazı kampına yaklaşan şüpheli araçlar fark ettin; paha biçilmez altın mühürleri çalmaya geliyorlar!",
	        "min_age": 24,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Asıl eserleri önceden çelik kasaya kilitleyip jandarma/polisle pusu kur",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kaçakçı şebekesi suçüstü yakalandı; tek bir eser bile zarar görmedi!",
	            "effects": {
	              "health": 0,
	              "happiness": 16,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 22,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_arch_4",
	              "origin_note": "Kumların Altındaki Kayıp Uygarlık (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Acil güvenlik hattını arayıp sirenleri çalıştır",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Soyguncular panikle kaçtı.",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 0,
	              "reputation": 14,
	              "sanity": 6,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_arch_4",
	              "origin_note": "Kumların Altındaki Kayıp Uygarlık (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_arch_4",
	        "title": "Kumların Altındaki Kayıp Uygarlık (Final): Dünya Mirası Listesi ve Büyük Müze Açılışı",
	        "category": "egitim",
	        "vignette": "academy",
	        "context_note": "Kayıp kentin insanlığın ortak mirası olarak tescillenmesi.",
	        "text": "UNESCO keşfettiğin antik kenti Dünya Kültür Mirası listesine aldı. Kentin girişindeki müzeye senin adın veriliyor!",
	        "min_age": 25,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Müze kurucu başkanı ol ve teliflerle yeni kazı bursları başlat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Tarihi yeniden yazan efsanevi kaşif olarak ölümsüzleştin!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 10,
	              "reputation": 38,
	              "sanity": 20,
	              "karma": 24,
	              "money_flat": 12000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arkeoloji_efsanesi"
	            ],
	            "remove_tags": [],
	            "add_trait": "Tarih Kaşifi",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Belgesel telifleriyle dünyayı gezmeye devam et",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Macera dolu zengin bir ömür sürdün.",
	            "effects": {
	              "health": 0,
	              "happiness": 26,
	              "smart": 0,
	              "reputation": 30,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 15000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arkeoloji_efsanesi"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  },
	  {
	    "arc_id": "arc_dyn",
	    "arc_title": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya",
	    "stages": [
	      {
	        "id": "arc_dyn_1",
	        "title": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (Bölüm I): Haciz Memurları Kapıda: Son Şans",
	        "category": "ekonomi",
	        "vignette": "work",
	        "context_note": "Ailenin yıllarca emek verdiği zanaat/üretim dükkanının borç krizi.",
	        "text": "Eski usul çalışan aile atölyesi/işletmesi piyasa rekabetine yenik düştü. Haciz memurları gelmeden önce yönetimi devralıp kurtarma planı devreye sokabilirsin.",
	        "min_age": 22,
	        "max_age": 58,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Sorumluluğu üstlen; borçları yapılandırıp üretimi modern tasarımla yenile",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Kepenklerin kapanmasını son anda önledin!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 8,
	              "reputation": 14,
	              "sanity": 0,
	              "karma": 16,
	              "money_flat": -1000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "arc_arc_dyn_active"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dyn_2",
	              "origin_note": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (1. Aşama kararının devamı olarak)"
	            }
	          },
	          {
	            "text": "İşletmeyi tasfiye edip borçsuz kapat",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Acı da olsa zararı durdurdun.",
	            "effects": {
	              "health": 0,
	              "happiness": -6,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 0,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      },
	      {
	        "id": "arc_dyn_2",
	        "title": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (Bölüm II): İlk İhracat Siparişi ve Kalite Sınavı",
	        "category": "ekonomi",
	        "vignette": "work",
	        "context_note": "Yerel atölyenin uluslararası fuarda keşfedilmesi.",
	        "text": "Milano/Paris fuarına gönderdiğin numuneler çok beğenildi ve 10.000 adetlik ilk büyük sipariş geldi! Ancak teslim süresi çok kısa.",
	        "min_age": 23,
	        "max_age": 95,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Mahalledeki diğer ustaları da adil ücretle üretime katarak siparişi sıfır hatayla yetiştir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Avrupalı alıcılar kaliteye hayran kaldı; yıllık sözleşme imzaladılar!",
	            "effects": {
	              "health": 0,
	              "happiness": 20,
	              "smart": 0,
	              "reputation": 24,
	              "sanity": 0,
	              "karma": 16,
	              "money_flat": 7500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dyn_3",
	              "origin_note": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (2. Aşama dönüm noktasının devamı olarak)"
	            }
	          },
	          {
	            "text": "Kapasiten kadar küçük ama butik parti gönder",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Lüks butik segmentte sağlam bir yer edindin.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 18,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4500,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dyn_3",
	              "origin_note": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (2. Aşama krizinin devamı olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_dyn_3",
	        "title": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (Bölüm III): Aile İçi Hissedar Çatışması",
	        "category": "ekonomi",
	        "vignette": "work",
	        "context_note": "Şirket büyüyünce akrabaların yönetim kavgası çıkarması.",
	        "text": "Şirket milyonlar kazanmaya başlayınca, kriz gününde ortada görünmeyen kuzenler ve akrabalar kâr payı ve müdürlük koltuğu için kazan kaldırdı.",
	        "min_age": 24,
	        "max_age": 96,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Kurumsal Aile Anayasası yaz; liyakat şartı getirip bağımsız yönetim kurulu oluştur",
	            "lock_reason": "",
	            "req_stats": {
	              "smart": 64
	            },
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Şirketi akraba kaprislerinden kurtarıp tam kurumsal bir dev haline getirdin!",
	            "effects": {
	              "health": 0,
	              "happiness": 0,
	              "smart": 10,
	              "reputation": 22,
	              "sanity": 12,
	              "karma": 0,
	              "money_flat": 8000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dyn_4",
	              "origin_note": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (3. Aşama doruk noktasının sonucu olarak)"
	            }
	          },
	          {
	            "text": "Akrabaların hisselerini piyasa değerinden satın alıp tek sahibi ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Tartışmaları kökten bitirdin.",
	            "effects": {
	              "health": 0,
	              "happiness": 14,
	              "smart": 0,
	              "reputation": 0,
	              "sanity": 0,
	              "karma": 0,
	              "money_flat": 4000,
	              "money_pct": 0.0
	            },
	            "add_tags": [],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {
	              "delay_years": 2,
	              "event_id": "arc_dyn_4",
	              "origin_note": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (3. Aşama seçiminin sonucu olarak)"
	            }
	          }
	        ]
	      },
	      {
	        "id": "arc_dyn_4",
	        "title": "İflas Eşiğindeki Aile Atölyesinden Küresel Markaya (Final): Asırlık Çınar: Dünya Başkentlerinde Aile Soyadın",
	        "category": "ekonomi",
	        "vignette": "work",
	        "context_note": "Küçük bir atölyeden küresel mirasa.",
	        "text": "Bir zamanlar haciz memurlarının kapısına dayandığı o küçük atölye, bugün Londra, Tokyo ve New York caddelerinde senin soyadını taşıyan saygın bir dünya markası!",
	        "min_age": 25,
	        "max_age": 98,
	        "weight": 50,
	        "repeatable": false,
	        "conditions": {
	          "countries": [],
	          "classes": [],
	          "required_tags": [],
	          "blocked_tags": [],
	          "min_stats": {},
	          "max_stats": {}
	        },
	        "choices": [
	          {
	            "text": "Yönetimi 2. kuşağa (çocuklarına) ve profesyonellere devredip Onursal Başkan ol",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Aile adını altın harflerle yazdıran bir sanayi ve ticaret efsanesi oldun!",
	            "effects": {
	              "health": 0,
	              "happiness": 28,
	              "smart": 0,
	              "reputation": 38,
	              "sanity": 20,
	              "karma": 20,
	              "money_flat": 25000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "hanedan_kurucusu",
	              "milyoner"
	            ],
	            "remove_tags": [],
	            "add_trait": "Aile Reisi",
	            "schedule_consequence": {}
	          },
	          {
	            "text": "Şirketin %30'unu çalışanlara vakfederek üretimi ölümsüzleştir",
	            "lock_reason": "",
	            "req_stats": {},
	            "req_money": 0,
	            "req_tags": [],
	            "outcome_text": "Hem servet hem de eşsiz bir vefa mirası bıraktın.",
	            "effects": {
	              "health": 0,
	              "happiness": 30,
	              "smart": 0,
	              "reputation": 40,
	              "sanity": 0,
	              "karma": 32,
	              "money_flat": 18000,
	              "money_pct": 0.0
	            },
	            "add_tags": [
	              "hanedan_kurucusu"
	            ],
	            "remove_tags": [],
	            "add_trait": "",
	            "schedule_consequence": {}
	          }
	        ]
	      }
	    ]
	  }
	]
