extends RefCounted

# 0-12 Yaş Arası Detaylı Çocukluk Olayları (48 Olay)
static func get_events() -> Array:
	return [
	  {
	    "id": "ch_01_ilk_adim_ve_nesne",
	    "title": "Halının Üzerinde İlk Adım ve Seçim",
	    "category": "aile",
	    "vignette": "birth",
	    "context_note": "Eski bir aile geleneği olarak bebeğin önüne dizilen sembolik eşyalar.",
	    "text": "Yürümeye yeni başladığın günlerde ailen halının üzerine bir dolmakalem, bir bozuk para, bir stetoskop ve küçük bir tahta flüt bıraktı. Emekleyerek hangisine uzanıyorsun?",
	    "min_age": 1,
	    "max_age": 2,
	    "weight": 90,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Mürekkep kokulu dolmakaleme uzan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailen 'Bu çocuk alim ya da yazar olacak!' diyerek alkışladı; merak duygusu zihnine kazındı.",
	        "effects": {
	          "health": 0,
	          "happiness": 5,
	          "smart": 7,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "erken_merak"
	        ],
	        "remove_tags": [],
	        "add_trait": "Meraklı",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parlak madeni parayı avucuna sıkıştır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dedengil gülerek 'Ticaret kafası şimdiden belli!' dedi.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 4,
	          "reputation": 4,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ticaret_sezgisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tahta flütü alıp üflemeye çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Evin içini neşeli sesler doldurdu; ritim ve sanat algın erken filizlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 9,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 5,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sanat_yatkinligi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Stetoskopu boynuna dolamaya çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailen gözleri parlayarak seni kucakladı; insanlara şifa verme içgüdün uyandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hekim_adayi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_02_yuksek_ates_gecesi",
	    "title": "Gece Yarısı Yüksek Ateş ve Havale Tehlikesi",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Erken çocuklukta bağışıklık sisteminin ilk ciddi sınavı.",
	    "text": "Kış ortasında gece yarısı ateşin 40 dereceye çıktı. Annen başucunda sirkeli bezle beklerken nefesin sıklaşıyor.",
	    "min_age": 1,
	    "max_age": 4,
	    "weight": 85,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tam teşekküllü çocuk hastanesinde yoğun tedavi gör",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Doktorların erken müdahalesiyle ateşin düştü, hiçbir kalıcı hasar kalmadı.",
	        "effects": {
	          "health": 10,
	          "happiness": 4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Nöbet sırasında direncini topla ve sabaha karşı terleyerek uyan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zorlu bir gece geçirdin ama bağışıklık sistemin bu savaştan güçlenerek çıktı.",
	        "effects": {
	          "health": 3,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "guclu_bagisiklik"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tedavi geciktiği için haftalarca yatakta halsiz kal",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hastalık ciğerlerini biraz yordu ama annenin şefkatiyle ayağa kalktın.",
	        "effects": {
	          "health": -10,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 2,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_03_dar_gelir_kis_paltosu",
	    "title": "Kış Soğuğunda Yamalı Palto",
	    "category": "aile",
	    "vignette": "home",
	    "context_note": "Dar gelirli ailelerde kış hazırlığı ve kardeş dayanışması.",
	    "text": "Okul yolu buz tutmuş durumda. Üzerindeki palto ablandan/abinden kalma ve dirsekleri yamalı; sınıftaki bazı çocuklar sana bakıp fısıldaşıyor.",
	    "min_age": 6,
	    "max_age": 10,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [
	        "extreme_poor",
	        "low"
	      ],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Başını dik tut; temiz ve düzenli olmanın pahalı kıyafetten önemli olduğunu göster",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Öğretmenin senin tertibini tüm sınıfa örnek gösterdi; özgüvenin sarsılmadı.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "Onurlu",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Alay eden çocuklara ders başarınla cevap verip sınıf birincisi ol",
	        "lock_reason": "Zeka En Az 55 Olmalı",
	        "req_stats": {
	          "smart": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Karne günü herkes susup seni alkışlamak zorunda kaldı!",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 10,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "akademik_hirsi"
	        ],
	        "remove_tags": [],
	        "add_trait": "Hırslı",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Teneffüslerde bahçeye çıkmayıp kalorifer peteğinin yanında tek başına otur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Soğuktan korundun ama kalbinde erken bir kırgınlık birikti.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_04_varlikli_piyano_baskisi",
	    "title": "Gümüş Şamdanlar Altında Özel Piyano ve Dil Dersi",
	    "category": "egitim",
	    "vignette": "music",
	    "context_note": "Varlıklı ailelerin çocuklarına küçük yaşta yüklediği elit eğitim temposu.",
	    "text": "Yaşıtların sokakta top oynarken senin eve özel Fransızca ve piyano hocası geliyor. Annen salon kapısından tek bir yanlış notaya bile tahammül etmeden seni izliyor.",
	    "min_age": 6,
	    "max_age": 11,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [
	        "high",
	        "elite"
	      ],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Disiplini benimse ve konserde kusursuz bir Chopin noktürnü çal",
	        "lock_reason": "Zeka En Az 58 Olmalı",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Elit davetliler seni ayakta alkışladı; hem zarafet hem de yüksek konsantrasyon kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 10,
	          "reputation": 14,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "klasik_muzik_egitimi"
	        ],
	        "remove_tags": [],
	        "add_trait": "Zarif",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Piyanonun kapağını kapatıp bahçeye kaç ve ağaçlara tırman",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ceza alsan da çocukluğunu özgürce yaşamanın tadına vardın.",
	        "effects": {
	          "health": 6,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "ozgur_cocuk"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İsteksizce tuşlara basarak dersin bitmesini bekle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ne tam öğrenebildin ne de oyun oynayabildin; iç sıkıntın arttı.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 3,
	          "reputation": 0,
	          "sanity": -5,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_05_sokaktaki_yarali_kedi",
	    "title": "Yağmurlu Sokakta Titreyen Yaralı Yavru Kedi",
	    "category": "felsefe",
	    "vignette": "nature",
	    "context_note": "Çocuklukta merhamet ve sorumluluk duygusunun ilk gerçek sınavı.",
	    "text": "Okul dönüşü çöp konteynerinin yanında arka patisi incinmiş, yağmurdan sırılsıklam olmuş minik bir kedi yavrusu miyavlıyor. Ailen evde hayvana sıcak bakmayabilir.",
	    "min_age": 5,
	    "max_age": 11,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hırkanın içine sarıp eve götür ve harçlığınla tedavisini üstlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailen ilk başta kızsa da kedinin masumiyeti herkesi yumuşattı; sadık bir dost kazandın!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hayvan_dostu"
	        ],
	        "remove_tags": [],
	        "add_trait": "Merhametli",
	        "schedule_consequence": {
	          "delay_years": 6,
	          "event_id": "yth_48_sadik_dost_vedasi",
	          "origin_note": "Çocukken yağmurdan kurtardığın sadık kedinle geçen yılların ardından"
	        }
	      },
	      {
	        "text": "Karton kutudan sıcak bir barınak yapıp her gün süt ve mama taşı",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sokaktaki canı yaşattın ve sorumluluk bilincin gelişti.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Korkup yanından hızla uzaklaş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Eve kuru vardın ama gece yağmur sesini dinlerken vicdanın sızladı.",
	        "effects": {
	          "health": 0,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": -8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_06_ilkokul_zorbaligi",
	    "title": "Okul Bahçesinde Beslenme Çantası Zorbalığı",
	    "category": "kriz",
	    "vignette": "protest",
	    "context_note": "İlkokul yıllarında akran zorbalığı karşısında verilen tepki.",
	    "text": "Üst sınıflardan iri yarı bir çocuk, teneffüste en yakın arkadaşının beslenme çantasını yere devirip harçlığını almaya çalışıyor. Çevredeki çocuklar korkudan suspus olmuş.",
	    "min_age": 7,
	    "max_age": 11,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Cesaretle araya gir, arkadaşını koru ve zorbanın karşısına dikil",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yüzüne bir darbe alsan da geri adım atmadın; bütün okul senin cesaretini konuştu!",
	        "effects": {
	          "health": -5,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 6,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "zorba_karsiti"
	        ],
	        "remove_tags": [],
	        "add_trait": "Yürekli",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Zekice bir hamleyle nöbetçi öğretmeni tam zamanında olay yerine getir",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 52
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zorba suçüstü yakalanıp disiplin cezası aldı; arkadaşın sana minnettar kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 6,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Korkudan arkanı dönüp sınıfa kaç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dayak yemekten kurtuldun ama arkadaşının gözlerindeki hayal kırıklığını unutamadın.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": -10,
	          "sanity": -8,
	          "karma": -10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "cekigen"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_07_gizli_tavan_arasi_sandigi",
	    "title": "Dededen Kalan Kilitli Tavan Arası Sandığı",
	    "category": "egitim",
	    "vignette": "secret",
	    "context_note": "Çocukluk merakıyla keşfedilen eski aile yadigarları.",
	    "text": "Yağmurlu bir pazar günü evin çatı katını veya kilerini karıştırırken, üzerinde paslı bir asma kilit bulunan eski bir ahşap sandık buldun.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tel tokayla kilidi sabırla açıp içindeki eski haritaları ve günlükleri incele",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sandıktan çıkan 1950'lerden kalma ansiklopediler ve mektuplar okuma tutkunu ateşledi!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 11,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "tarih_meraklisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sandığı büyüklerine götürüp hikayesini birlikte dinlemeyi iste",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aile büyükleri geçmişin sırlarını anlatırken kuşaklar arası bağınız güçlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_08_mahalle_maci_cam_kirilmasi",
	    "title": "Mahalle Maçında Kırılan Huysuz Komşunun Camı",
	    "category": "aile",
	    "vignette": "sports",
	    "context_note": "Sokak oyunlarının kaçınılmaz kazası ve dürüstlük sınavı.",
	    "text": "Sokakta tüm gücünle vurduğun top falso alıp mahallenin en aksi ihtiyarının salon camını tuzla buz etti! Diğer çocuklar bir anda çil yavrusu gibi dağıldı.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kaçma; kapıyı çalıp suçu üstlen ve kumbarandaki harçlığı teklif et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İhtiyar komşu dürüstlüğün karşısında yumuşadı; parayı almadığı gibi sana bahçesinden elma ikram etti!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 8,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "Dürüst",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Diğer çocuklarla birlikte ara sokağa kaçıp saklan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yakalanmadın ama hafta boyu o sokaktan geçerken kalbin küt küt attı.",
	        "effects": {
	          "health": 0,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -6,
	          "karma": -8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_09_matematik_yarismasi_kesfi",
	    "title": "Tahtadaki Çözülemeyen Problem ve Öğretmenin Şaşkınlığı",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Okul sıralarında fark edilen analitik ve sayısal yetenek.",
	    "text": "Matematik öğretmeni dersin sonunda üst sınıflara ait zor bir mantık sorusunu tahtaya yazıp 'Bunu çözen çıkarsa sözlüsüne 100 vereceğim' dedi.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Teneffüse çıkmayıp soruyu kendi geliştirdiğin pratik bir yöntemle çöz",
	        "lock_reason": "Zeka En Az 58 Olmalı",
	        "req_stats": {
	          "smart": 58
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Öğretmen çözümü görünce gözlerine inanamadı ve seni bilim olimpiyatı takımına yazdırdı!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 12,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "sayisal_yetenek"
	        ],
	        "remove_tags": [],
	        "add_trait": "Analitik",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Arkadaşlarınla grup kurup beyin fırtınası yaparak çözmeye çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Tam sonuca ulaşamasanız da ekip çalışmasıyla öğretmenin takdirini kazandınız.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 6,
	          "reputation": 6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_10_babanin_issiz_kalmasi",
	    "title": "Akşam Sofrasında Sessizlik: İşsizlik Haberi",
	    "category": "ekonomi",
	    "vignette": "crisis",
	    "context_note": "Ekonomik dalgalanmaların çocuk gözünden aile sofrasına yansıması.",
	    "text": "Akşam yemeğinde kimse konuşmuyor. Babanın çalıştığı fabrikanın/işyerinin küçülmeye gittiğini ve işten çıkarıldığını duydun. Annen gizlice mutfakta gözyaşlarını siliyor.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [
	        "extreme_poor",
	        "low",
	        "middle"
	      ],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kumbaranı getirip masaya koy ve okul masraflarını azaltacağına söz ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Anne ve baban sana sarılıp ağladı; zor günlerde kenetlenen bir aile oldunuz.",
	        "effects": {
	          "health": 0,
	          "happiness": -4,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 6,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "erken_olgunluk"
	        ],
	        "remove_tags": [],
	        "add_trait": "Fedakar",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Okul çıkışı mahalle fırınında veya markette çıraklık yaparak eve ekmek götür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çocuk yaşta alın terinin değerini öğrendin ama derslerin biraz aksadı.",
	        "effects": {
	          "health": -4,
	          "happiness": 0,
	          "smart": -3,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 300,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "cocuk_cirak"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Durumu kabullenemeyip hırçınlaş ve içine kapan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Evdeki gerginlik senin de çocukluk neşeni gölgeledi.",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_11_resim_atolyeleri_ve_boya",
	    "title": "Duvarlara Çizilen Hayaller: Resim Yeteneği",
	    "category": "egitim",
	    "vignette": "art",
	    "context_note": "Çocuklukta görsel sanatlar ve tasarım yeteneğinin filizlenmesi.",
	    "text": "Eski gazete kağıtlarının kenarlarına ve defter arkalarına çizdiğin karakalem portreler resim öğretmeninin dikkatini çekti. İl çapında bir çocuk resimleri sergisi düzenleniyor.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Haftalarca uğraşıp mahallenin hayatını anlatan suluboya bir tablo yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Tablon sergide birincilik ödülü aldı ve yerel gazetede fotoğrafın çıktı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 6,
	          "reputation": 16,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "gorsel_sanat_yetengi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çizimlerini arkadaşlarına hediye ederek okulda sevilen biri ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yeteneklerini paylaşmak sana sıcak dostluklar kazandırdı.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_12_bisiklet_kazasi_ve_dikis",
	    "title": "Yokuş Aşağı Freni Patlayan Bisiklet",
	    "category": "saglik",
	    "vignette": "sports",
	    "context_note": "Çocukluğun unutulmaz diz yaraları ve tehlikeli oyunları.",
	    "text": "Mahallenin en dik yokuşundan eski bir bisikletle hızla inerken fren teli koptu! Karşıdan bir kamyonet geliyor, sağ tarafta ise çalılık bahçe duvarı var.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Soğukkanlılıkla gidonu çalılıklara kır ve çimenlerin üzerine yuvarlan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kolun sıyrıldı ama büyük bir kazadan zekan sayesinde kurtuldun.",
	        "effects": {
	          "health": -4,
	          "happiness": 0,
	          "smart": 5,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Panikleyip kaldırıma çarp ve acil serviste alnına dikiş attır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Acı verici bir hastane gecesi geçirdin; kaşının kenarında küçük bir iz kaldı.",
	        "effects": {
	          "health": -14,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "tag_yarali"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_13_kopya_kagidi_sinavi",
	    "title": "Sıranın Altındaki Kopya Kağıdı",
	    "category": "egitim",
	    "vignette": "exam",
	    "context_note": "Okulda akademik dürüstlük ile arkadaş baskısı arasındaki ilk sınav.",
	    "text": "Dönemin en zor sınavındasın. Yan sıradaki yakın arkadaşın eteğinin/cebinin altından küçük bir kopya kağıdı uzatıp 'Bana da3. soruyu göster, yoksa sınıfta kalacağım' diye fısıldıyor.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kopyayı reddet ama sınavdan sonra arkadaşına konuyu bizzat çalıştıracağına söz ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sınavı kendi emeğinle geçtin ve arkadaşını da bütünleme sınavına hazırlayarak kurtardın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kağıdı alıp kopya çekerken öğretmene yakalan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Öğretmen kağıdını elinden alıp sıfır verdi; ailen okula çağrıldı.",
	        "effects": {
	          "health": 0,
	          "happiness": -14,
	          "smart": 0,
	          "reputation": -16,
	          "sanity": -8,
	          "karma": -10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "disiplin_uyarisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_14_yaz_tatili_koy_dede",
	    "title": "Yaz Tatilinde Dedenin Bağ Evi ve Doğa Dersleri",
	    "category": "aile",
	    "vignette": "nature",
	    "context_note": "Şehir gürültüsünden uzakta doğayla ve aile kökleriyle kurulan bağ.",
	    "text": "Okullar kapandığında yaz tatilini geçirmek için dedenin kırsaldaki bahçeli evine gittin. Sabah horoz sesleri, kuyu suyu ve yıldızlı geceler seni bekliyor.",
	    "min_age": 5,
	    "max_age": 12,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Dedene tarlada/bahçede yardım et, ağaç aşılamayı ve yıldız yönlerini öğren",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Toprağın sabrını ve doğanın dilini öğrendin; bedenin demir gibi sağlamlaştı.",
	        "effects": {
	          "health": 14,
	          "happiness": 15,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "doga_bilgesi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Köyün çocuklarıyla derede yüzüp ağaç ev inşa et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hayatının en özgür ve neşeli yaz tatilini geçirdin.",
	        "effects": {
	          "health": 10,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_15_okul_tiyatrosu_heyecani",
	    "title": "Yıl Sonu Okul Tiyatrosunda Başrol Krizi",
	    "category": "egitim",
	    "vignette": "art",
	    "context_note": "Sahne korkusu ve topluluk önünde konuşma (hitabet) becerisi.",
	    "text": "Yıl sonu müsameresinde başrolü oynayacak öğrenci hastalandı. Perde açılmasına 20 dakika kala öğretmen sana dönüp 'Ezberin kuvvetli, sahneye sen çıkabilir misin?' diye soruyor.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sahneye çık ve tüm salonun gözlerinin içine bakarak rolünü devleşerek oyna",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 50
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Alkış tufanı koptu! Topluluk önünde konuşma korkunu sonsuza dek yendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 6,
	          "reputation": 18,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hitabet_yetengi"
	        ],
	        "remove_tags": [],
	        "add_trait": "Özgüvenli",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sahne arkası dekor ve suflör yönetimini üstlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gösterinin sorunsuz akmasını sağlayarak perde arkasındaki kahraman oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 5,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_16_bit_salgini_ve_hijyen",
	    "title": "Sınıfta Bit Salgını ve Utanç",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "İlkokul yıllarının toplu sağlık kontrolleri ve sosyal damgalanma.",
	    "text": "Okul hemşiresi sınıfta saç kontrolü yaparken birkaç öğrencide bit çıktığını duyurdu. Herkes birbirinden uzaklaşırken senin de başın kaşınmaya başladı.",
	    "min_age": 6,
	    "max_age": 10,
	    "weight": 70,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Durumu hemen annene söyleyip özel şampuanla temizlen ve okula tertemiz dön",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sorun büyümeden çözüldü, sağlığın ve özgüvenin korundu.",
	        "effects": {
	          "health": 6,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Utandığın için gizle ve saçlarını sıfıra vurdurmak zorunda kal",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Birkaç hafta şapkayla dolaştın ve arkadaşlarının şakalarına katlandın.",
	        "effects": {
	          "health": 0,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": -5,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_17_eski_bilgisayar_ve_kodlama",
	    "title": "Tüplü Monitör Karşısında İlk Kod Satırları",
	    "category": "egitim",
	    "vignette": "tech",
	    "context_note": "Çocuk yaşta algoritma ve bilgisayar dünyasıyla tanışma.",
	    "text": "Eve veya okul laboratuvarına ikinci el, fanı gürültüyle çalışan eski bir bilgisayar geldi. Diğer çocuklar sadece oyun oynarken sen sistem dosyalarını kurcalıyorsun.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Oyunların nasıl çalıştığını çözüp kendi basit 2B oyununu kodla",
	        "lock_reason": "Zeka En Az 56 Olmalı",
	        "req_stats": {
	          "smart": 56
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Algoritma mantığını çocuk yaşta kavradın; gelecekteki teknoloji kariyerinin tohumu atıldı!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 14,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "erken_kodlama"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {
	          "delay_years": 7,
	          "event_id": "yth_49_erken_kodlama_meyvesi",
	          "origin_note": "Çocukken eski bilgisayarda kendi başına öğrendiğin kodlama temelinin devamı olarak"
	        }
	      },
	      {
	        "text": "Sabahlara kadar strateji ve bulmaca oyunları oyna",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Reflekslerin gelişti ama gözlerin biraz yoruldu.",
	        "effects": {
	          "health": -3,
	          "happiness": 10,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_18_kardes_kiskancligi_veya_koruma",
	    "title": "Ailede Kardeş Rekabeti ve Paylaşım",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Ev içindeki sevgi ve kaynakların paylaşımı.",
	    "text": "Ailen bayram/yılbaşı harçlığı ve yeni kıyafet alırken bütçe kısıtlı olduğu için yalnızca birinize istediği oyuncağı/kitabı alabileceklerini söyledi.",
	    "min_age": 5,
	    "max_age": 11,
	    "weight": 75,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hakkını kardeşine/ailene devret ve birlikte oynayacağınız bir şey seçilmesini öner",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailen olgunluğun karşısında duygulandı; evdeki huzur katlandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 8,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ağlayıp tepinerek oyuncağı sadece kendin için aldır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İstediğini aldın ama tek başına oynarken beklediğin keyfi bulamadın.",
	        "effects": {
	          "health": 0,
	          "happiness": 2,
	          "smart": 0,
	          "reputation": -4,
	          "sanity": 0,
	          "karma": -8,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_19_yuzme_havuzu_korkusu",
	    "title": "Derin Su Korkusu ve İlk Kulaç",
	    "category": "saglik",
	    "vignette": "sports",
	    "context_note": "Çocukluk fobilerinin üzerine gitme.",
	    "text": "Yaz kursunda veya deniz kıyısında ayaklarının yere değmediği derin suya girdiğin an panikledin ve su yuttun.",
	    "min_age": 6,
	    "max_age": 11,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Korkuna yenilme; nefes kontrolünü öğrenip tekrar suya gir ve yüzmeyi sök",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Suyla barıştın, ciğer kapasiten ve özgüvenin hızla arttı.",
	        "effects": {
	          "health": 10,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sudan çıkıp bir daha derin yere yaklaşmamaya yemin et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Güvende kaldın ama su korkusu yıllarca zihninde yer etti.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -5,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "su_fobisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_20_kaybolan_pazar_yolu",
	    "title": "Kalabalık Pazarda Annenin Elini Bırakmak",
	    "category": "kriz",
	    "vignette": "crisis",
	    "context_note": "Çocukluğun en büyük korkularından biri olan kalabalıkta kaybolma anı.",
	    "text": "Hafta sonu pazarının uğultusu içinde renkli bir tezgaha dalıp annenin elini bıraktın. Başını kaldırdığında etrafında sadece tanımadığın dev gölgeler var!",
	    "min_age": 4,
	    "max_age": 8,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Ağlamak yerine ezberlediğin ev adresini ve telefon numarasını zabıtaya/güvenliğe söyle",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 48
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Soğukkanlılığın sayesinde 15 dakika içinde ailene kavuştun!",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 6,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Olduğun yerde çığlık çığlığa ağlayarak annenin seni bulmasını bekle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yarım saatlik korku dolu bekleyişin ardından annen seni kucakladı.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_21_kutuphane_karti",
	    "title": "İlk Kütüphane Kartı ve Jules Verne Dünyası",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Okuma alışkanlığının hayal gücünü dönüştürmesi.",
	    "text": "Mahalle halk kütüphanesinin yüksek tavanlı, eski kağıt kokulu salonuna ilk kez girdin. Görevli senin adına düzenlenmiş ilk kütüphane kartını uzatıyor.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her hafta iki macera ve bilim kurgu klasiği bitirme hedefi koy",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kelime hazinen ve hayal gücün yaşıtlarının çok ötesine geçti.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 12,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kitap_kurdu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Resimli atlasları ve dünya ülkeleri ansiklopedilerini incele",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Uzak kıtalara ve kültürlere karşı sönmez bir merak kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 9,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_22_limonata_ve_cikolata_tezgahi",
	    "title": "Mahalle Köşesinde İlk Küçük Tezgah",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Çocuklukta paranın ve emeğin döngüsünü kavrama.",
	    "text": "Yaz sıcaklarında evin önünde soğuk limonata, su veya el yapımı bileklik satarak kendi harçlığını çıkarma fikri aklına düştü.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Maliyet hesabı yap, güler yüzle satış yapıp kazancını kumbarada biriktir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "İlk ticari girişiminden şaşırtıcı bir harçlık biriktirdin ve pazarlık becerin gelişti!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 7,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 250,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "genc_girisimci"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kazandığın parayla bütün mahalle arkadaşlarına dondurma ısmarla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Paran bitti ama mahallenin en sevilen lideri oldun!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_23_disci_koltugu_sinavi",
	    "title": "Dişçi Koltuğunda Metal Aletlerin Sesi",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Çocuklukta sağlık bakımı ve acıyla yüzleşme.",
	    "text": "Çok fazla şekerleme yemekten azı dişin gece boyu zonkladı. Şimdi diş hekiminin parlak ışığı altında ağzını açman bekleniyor.",
	    "min_age": 6,
	    "max_age": 11,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Cesurca koltuğa otur, dolguyu yaptır ve düzenli diş fırçalama alışkanlığı edin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ağrın kesildi ve ömür boyu sürecek sağlıklı bir bakım disiplini kazandın.",
	        "effects": {
	          "health": 8,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 5,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Korkudan koltuktan fırlayıp tedaviyi yarım bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Diş ağrın ve enfeksiyon haftalarca peşini bırakmadı.",
	        "effects": {
	          "health": -8,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_24_aile_ici_kavga_ve_kulaklik",
	    "title": "Yan Odadan Gelen Yüksek Sesler",
	    "category": "aile",
	    "vignette": "heartbreak",
	    "context_note": "Ebeveynler arasındaki geçim veya uyum tartışmalarının çocuk ruhundaki izi.",
	    "text": "Gece yatağında uzanırken salon kapısının ardında anne ve babanın hararetli bir şekilde tartıştığını duyuyorsun.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Defterini açıp duygularını öykülere ve resimlere dökerek kendini koru",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sanatı ve yazıyı ruhsal bir kalkan haline getirmeyi öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": -2,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "duygusal_derinlik"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yanlarına gidip masumca ikisinin de elini tutarak barışmalarını sağla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Seni görünce utandılar ve birbirlerine sarılıp özür dilediler.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_25_bilim_fuari_yanardag",
	    "title": "Okul Bilim Fuarında Patlayan Maket",
	    "category": "egitim",
	    "vignette": "science",
	    "context_note": "Deneysel merak ve el becerisi.",
	    "text": "Okulun bilim şenliği için karbonat, sirke ve basit elektrik devresiyle çalışan bir jeotermal enerji maketi hazırladın.",
	    "min_age": 9,
	    "max_age": 12,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Deneyi hatasız sun ve jüriye enerjinin dönüşümünü anlat",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 52
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Jüri sunumuna hayran kaldı; bilimsel özgüvenin parladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 11,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bilim_meraklisi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Karışımı fazla kaçırıp jüri masasını köpük içinde bırak!",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Herkes kahkahalara boğuldu; ödül alamasan da okulun en unutulmaz deneyi oldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 4,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_26_kardes_veya_arkadas_sirri",
	    "title": "Emanet Edilen Büyük Sır",
	    "category": "felsefe",
	    "vignette": "secret",
	    "context_note": "Çocuklukta güvenilirlik ve sır tutma erdemi.",
	    "text": "En yakın arkadaşın okulda yanlışlıkla kırdığı laboratuvar mikroskobunu sana itiraf etti ve kimseye söylememen için yemin ettirdi.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Arkadaşını ikna edip harçlıklarınızı birleştirerek zararı gizlice onarın",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kimse ceza almadan sorunu çözdünüz; dostluğunuz çelikleşti.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 6,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Arkadaşını ele verip öğretmenin gözüne girmeye çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Öğretmen teşekkür etti ama sınıftaki tüm çocuklar sana 'ispiyoncu' gözüyle bakmaya başladı.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": -14,
	          "sanity": 0,
	          "karma": -10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_27_satranc_kulubu_ustasi",
	    "title": "Parktaki Yaşlı Satranç Ustası",
	    "category": "egitim",
	    "vignette": "philosophy",
	    "context_note": "Sabır ve birkaç hamle sonrasını görme disiplini.",
	    "text": "Mahalle parkındaki taş masada tek başına satranç taşlarını dizen emekli bir öğretmen seni karşısına davet etti.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yenilmekten korkmadan her hafta onunla oyna ve strateji öğren",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aylar sonra ilk kez onu mat ettiğinde şapkasını çıkarıp seni selamladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 13,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "satranc_oyuncusu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sabırsızlanıp taşları devirerek oyundan kalk",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Stratejik bir fırsatı kaçırdın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": -2,
	          "reputation": 0,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_28_yabanci_dil_meraki",
	    "title": "Altyazılı Filmler ve Sözlük Defteri",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Küçük yaşta yabancı dil ve küresel iletişim becerisi.",
	    "text": "Televizyonda veya internette izlediğin yabancı belgesellerdeki kelimeleri küçük bir cep defterine not etmeye başladın.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her gün 10 yeni kelime ezberleyip yabancı dilini akıcı seviyeye taşı",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Erken yaşta edindiğin dil becerisi ileride sana dünyaların kapısını açacak!",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 12,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yabanci_dil_biliyor"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sadece görsellere bakıp geç",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Keyifli vakit geçirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 5,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_29_mahalle_agac_dikimi",
	    "title": "Boş Arsaya Fidan Dikme Kampanyası",
	    "category": "felsefe",
	    "vignette": "nature",
	    "context_note": "Doğa sevgisi ve gelecek kuşaklara iz bırakma.",
	    "text": "Okulunuz mahallenin çorak tepesine çam ve meyve fidanları dikmek için gönüllü öğrenciler arıyor.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi fidanını dik, adını ver ve yaz boyu su taşıyarak kurumasını önle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Diktiğin fidan kök tuttu; doğayla aranda kopmaz bir bağ kuruldu.",
	        "effects": {
	          "health": 8,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Toprakla uğraşmak istemeyip gölgede otur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ellerin kirlenmedi ama o sevinci paylaşamadın.",
	        "effects": {
	          "health": 0,
	          "happiness": -2,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_30_bayram_harcligi_ve_yatirim",
	    "title": "Bayram Harçlıklarının Kaderi",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Erken finansal okuryazarlık vs. anlık haz.",
	    "text": "Bayram/yılbaşı ziyaretlerinden elinde hiç olmadığı kadar toplu bir harçlık birikti.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Paranın yarısıyla kitap/araç-gereç al, kalanını kumbarada biriktir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Erken yaşta bütçe yönetimini ve irade terbiyesini öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 7,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "tasarruf_aliskanligi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Aynı gün lunaparkta ve abur cuburda son kuruşuna kadar harca",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "O gün çok eğlendin ama akşam karnın ağrıdı ve cebin boşaldı.",
	        "effects": {
	          "health": -4,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_31_muzik_enstrumani_kesfi",
	    "title": "Okul Bandosu ve Enstrüman Seçimi",
	    "category": "egitim",
	    "vignette": "music",
	    "context_note": "İşitsel zeka ve ritim disiplini.",
	    "text": "Müzik öğretmeni ritim kulağının çok iyi olduğunu fark etti ve okulun enstrüman dolabından bir çalgı seçip çalışmanı önerdi.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Keman veya gitar seçip parmakların nasır tutana kadar egzersiz yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Müzik hem matematiksel zekanı hem de ruhsal dengeni güçlendirdi.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 10,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "muzisyen_ruhu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Koroda şarkı söylemeyi tercih et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sesini kullanmayı ve toplulukla uyum içinde olmayı öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_32_kis_gribi_ve_anne_corbasi",
	    "title": "Karlı Haftada Yatakta Tavuk Suyu Çorba",
	    "category": "saglik",
	    "vignette": "family",
	    "context_note": "Hastalık günlerinde şefkat ve dinlenme.",
	    "text": "Dışarıda lapa lapa kar yağarken ağır bir grip geçirdin. Okula gidemediğin bu haftada annen başucuna sıcak çorba ve ıhlamur getirdi.",
	    "min_age": 5,
	    "max_age": 11,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İlaçlarını düzenli içip dinlenirken çizgi roman ve öykü kitapları oku",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem sağlığına hızla kavuştun hem de sıcak bir çocukluk anısı biriktirdin.",
	        "effects": {
	          "health": 10,
	          "happiness": 10,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ateşin düşmeden gizlice dışarı çıkıp kartopu oyna",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çok eğlendin ama hastalığın bronşite çevirdi!",
	        "effects": {
	          "health": -14,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_33_sirk_veya_gezi_meraki",
	    "title": "Şehre Gelen Gezici Planetaryum ve Uzay Çadırı",
	    "category": "egitim",
	    "vignette": "science",
	    "context_note": "Evrene ve astronomiye duyulan ilk hayranlık.",
	    "text": "Belediye meydanına dev bir kubbeli uzay çadırı (Planetaryum) kuruldu. İçeride Satürn'ün halkaları ve uzak galaksiler gösteriliyor.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gösteriyi en önden izle ve astronomla uzay fiziği hakkında sohbet et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yıldızlara bakışın sonsuza dek değişti; bilimsel merakın ateşlendi.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 10,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Arkadaşlarınla meydanda pamuk şeker yiyip koşuştur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Neşeli bir hafta sonu geçirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_34_kayip_cuzdan_bulmak",
	    "title": "Kaldırımda Bulunan Emekli Maaşı Cüzdanı",
	    "category": "felsefe",
	    "vignette": "luck",
	    "context_note": "Çocuk yaşta vicdan ve empati testi.",
	    "text": "Okuldan dönerken fırının önünde içi nakit para ve ilaç küpürleriyle dolu eski bir deri cüzdan buldun. Kimse senin aldığını görmedi.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İçindeki kimlikten yaşlı sahibini bulup cüzdanı eksiksiz teslim et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yaşlı adam sevinçten ağlayarak alnından öptü ve sana hayır duası etti; vicdanın kuş gibi hafifledi!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 12,
	          "karma": 20,
	          "money_flat": 50,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "Vicdanlı",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parayı cebine atıp cüzdanı çöp kutusuna bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Harçlığın çoğaldı ama fırının önünden her geçişinde yaşlı adamın çaresiz yüzünü gördün.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -10,
	          "karma": -22,
	          "money_flat": 350,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_35_atletizm_secme_kosusu",
	    "title": "Okullararası Atletizm Seçmeleri",
	    "category": "saglik",
	    "vignette": "sports",
	    "context_note": "Bedensel çeviklik ve son metrelerde pes etmeme iradesi.",
	    "text": "Beden eğitimi öğretmeni seni ilçe koşu seçmelerine yazdırdı. Son 100 metrede bacakların yanıyor ve rakiplerin hemen önünde.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Dişini sıkıp tüm nefesinle son bir depar at",
	        "lock_reason": "",
	        "req_stats": {
	          "health": 55
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bitiş çizgisini göğüsleyip madalya kazandın; sporcu disiplinin oluştu!",
	        "effects": {
	          "health": 12,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "genc_sporcu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yarışı kendi ritminde tamamlayıp arkadaşlarını tebrik et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Centilmenliğinle takdir topladın.",
	        "effects": {
	          "health": 6,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_36_resim_defini_ve_harita",
	    "title": "Mahalle Arkadaşlarıyla 'Hazine Avı' Macerası",
	    "category": "aile",
	    "vignette": "luck",
	    "context_note": "Çocukluk oyunlarında liderlik ve ekip kurma.",
	    "text": "Mahalledeki 5 çocukla birlikte eski korulukta hayali bir hazine avı planladınız. Ancak hava kararmaya başladı ve koruluğun derinliklerinde yönünüzü şaşırdınız.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Panikleyen arkadaşlarını sakinleştir, güneşin battığı yöne göre yolu bul",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Liderliğin sayesinde hava tam kararmadan herkesi güvenle mahalleye çıkardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 15,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "dogal_lider"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ağlamaya başlayıp büyüklerin sizi aramaya gelmesini bekle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aileler ellerinde fenerlerle gelip sizi buldu; bir hafta sokağa çıkma cezası aldınız.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_37_el_sanatlari_ve_tamir",
	    "title": "Bozuk Radyoyu Söküp Takmak",
	    "category": "egitim",
	    "vignette": "work",
	    "context_note": "Mekanik merak ve mühendislik sezgisi.",
	    "text": "Evdeki eski transistörlü radyo bozuldu. Tornavidayı alıp arka kapağını açtığında içindeki bakır bobinler ve lehimler seni büyüledi.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kopuk kabloyu bulup birbirine bağlayarak radyoyu yeniden çalıştır!",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Radyodan müzik sesi yükseldiğinde evdekiler senin el becerine hayran kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 11,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "mekanik_ustasi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parçaları tamamen söküp kendi oyuncak robotunu yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Radyo bir daha çalışmadı ama mekanik tasarım mantığını öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_38_gocmen_veya_yeni_komsu",
	    "title": "Sınıfa Gelen Yeni ve Yabancı Öğrenci",
	    "category": "felsefe",
	    "vignette": "migration",
	    "context_note": "Farklı kültürlere ve ötekileştirilenlere yaklaşım.",
	    "text": "Sınıfınıza başka bir şehirden/ülkeden yeni taşınmış, şivesi farklı ve çekingen bir öğrenci geldi. Teneffüste kimse onu oyununa almıyor.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yanına otur, ekmeğini paylaş ve onu mahalle maçına davet et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hayat boyu sürecek vefalı bir dost kazandın ve önyargıları kırdın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 6,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Diğerlerine uyup sen de mesafeli dur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sürüden ayrılmadın ama yeni öğrencinin yalnız bakışı aklında kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": -6,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_39_ilk_gunluk_defteri",
	    "title": "Kilitli Günlük Defteri ve İç Dünya",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "Öz-farkındalık ve yazınsal ifade.",
	    "text": "Doğum gününde sana hediye edilen kilitli bir hatıra defterine her gece yaşadıklarını ve hayallerini yazmaya başladın.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Duygularını dürüstçe kaleme alıp edebi bir üslup geliştir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yazmak zihnini berraklaştırdı ve kendini ifade etme gücünü artırdı.",
	        "effects": {
	          "health": 0,
	          "happiness": 8,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Defteri çizim ve karikatürlerle doldur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Mizah duygusu güçlü bir görsel hikaye anlatıcısı oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 6,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_40_yangin_tatbikati_ve_kriz",
	    "title": "Mutfakta Unutulan Tava ve Duman",
	    "category": "kriz",
	    "vignette": "crisis",
	    "context_note": "Ev içi kazalarda hızlı ve doğru müdahale.",
	    "text": "Evde büyükler balkondayken mutfaktaki kızgın yağ tavasından bir anda alev ve siyah duman yükseldi!",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Asla su dökme! Islak bezle/kapakla havasını kesip büyükleri çağır",
	        "lock_reason": "Doğru Müdahale İçin Zeka 52+ Gerekli",
	        "req_stats": {
	          "smart": 52
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Fen dersinde öğrendiğin bilgi sayesinde evi büyük bir yangından kurtardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 10,
	          "reputation": 18,
	          "sanity": 8,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Panikle bağırarak dışarı koş ve komşuları yardıma çağır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Mutfak dolapları biraz is olsa da komşular yetişip yangını söndürdü.",
	        "effects": {
	          "health": -2,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_41_okul_kantin_sirasi",
	    "title": "Kantinde Parası Yetmeyen Küçük Öğrenci",
	    "category": "felsefe",
	    "vignette": "family",
	    "context_note": "Günlük hayatta küçük iyiliklerin kelebek etkisi.",
	    "text": "Okul kantininde önünde duran birinci sınıf öğrencisi elindeki bozuklukları saydı ama simit almaya parasının yetmediğini görünce boynunu büküp sıradan çıktı.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi harçlığınla iki simit alıp birini ona ikram et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Küçük çocuğun gözlerindeki ışıltı bütün gününü güzelleştirdi.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kendi tostunu alıp sınıfa çık",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Karnın doydu.",
	        "effects": {
	          "health": 0,
	          "happiness": 3,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_42_ucurtma_senligi",
	    "title": "Tepede Rüzgarla Dans Eden El Yapımı Uçurtma",
	    "category": "aile",
	    "vignette": "art",
	    "context_note": "Sabır, el işçiliği ve aileyle geçirilen bahar günü.",
	    "text": "Bahar rüzgarları başladığında çıtalardan, renkli kağıtlardan ve kuyruk şeritlerinden kendi uçurtmanı tasarladın.",
	    "min_age": 6,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Aerodinamik dengesini kurup tepedeki en yüksek uçurtmayı uçur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Uçurtman bulutlara doğru yükselirken göğsün gururla kabardı!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 6,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İpi kopan uçurtmanın peşinden koşarken yeni mahalleler keşfet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Uçurtmayı bulamadın ama macera dolu bir gün yaşadın.",
	        "effects": {
	          "health": 6,
	          "happiness": 8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_43_ortaokul_giris_ve_vaveyla",
	    "title": "Çocukluktan Ergenliğe İlk Adım: Ortaokul Mezuniyeti",
	    "category": "egitim",
	    "vignette": "exam",
	    "context_note": "12 yaşında çocukluk sayfasının kapanıp gençlik yıllarına geçişi.",
	    "text": "On iki yaşına geldin. Çocukluk oyunlarının yerini yavaş yavaş gelecek planları, kimlik arayışı ve lise hazırlığı alıyor. Kendine nasıl bir söz veriyorsun?",
	    "min_age": 11,
	    "max_age": 12,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "'Bilgi ve çalışkanlıkla kendi kaderimi kendim çizeceğim'",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zihinsel disiplininle gençlik yıllarına güçlü bir başlangıç yaptın.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 9,
	          "reputation": 8,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "planli_genclik"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "'Hayatı cesurca yaşayacak, dostluktan ve adaletten şaşmayacağım'",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yüreğin cesaret ve yaşama sevinciyle dolu olarak gençliğe adım attın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_44_mahalle_kutuphanesi_bagisi",
	    "title": "Okunmuş Kitapları Köy Okuluna Göndermek",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Paylaşım ve toplumsal sorumluluk.",
	    "text": "Okulunuz kitaplığı olmayan uzak bir köy okulu için kitap ve kırtasiye kampanyası başlattı.",
	    "min_age": 7,
	    "max_age": 12,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "En sevdiğin kitapları içine sıcak bir mektup yazarak kolile",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aylar sonra köydeki bir öğrenciden sana teşekkür mektubu geldi!",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 8,
	          "karma": 15,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kullanmadığın eski defterleri ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kampanyaya küçük bir katkıda bulundun.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 5,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_45_gece_gokyuzu_kuyrukluyildiz",
	    "title": "Çatıda Kuyrukluyıldız Geçişini İzlemek",
	    "category": "felsefe",
	    "vignette": "science",
	    "context_note": "Evren karşısında duyulan hayret.",
	    "text": "Yüzyılda bir geçen parlak bir kuyrukluyıldız bu gece çıplak gözle görülebilecek. Babangil seni battaniyeye sarıp çatıya/balkona çıkardı.",
	    "min_age": 5,
	    "max_age": 12,
	    "weight": 75,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kuyrukluyıldızı izlerken bilim insanı veya kaşif olma hayali kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "O gece gördüğün ışık, içindeki öğrenme ateşini yıllarca canlı tuttu.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sevdiklerinin sağlığı ve mutluluğu için içten bir dilek tut",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailenin sıcaklığı içinde huzurla uyudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_46_okul_bahcesinde_ticaret_yasagi",
	    "title": "Koleksiyon Kartları ve Misket Borsası",
	    "category": "ekonomi",
	    "vignette": "luck",
	    "context_note": "Okul bahçesindeki mikro-ekonomi ve takas dengesi.",
	    "text": "Teneffüslerde nadir bulunan spor/oyun kartları ve cam misketler altın değerinde. Elindeki nadir seriyi takas ederek büyük bir koleksiyon kurdun.",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Koleksiyonu en yüksek talebin olduğu gün nakit harçlığa çevir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Arz-talep dengesini çocuk yaşta çözdün; kumbaran doldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 7,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 220,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Müdür yardımcısına yakalanıp kartları dönem sonuna kadar kaptır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kuralların etrafından dolaşmanın riskini öğrendin.",
	        "effects": {
	          "health": 0,
	          "happiness": -6,
	          "smart": 0,
	          "reputation": -4,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_47_ilk_kamp_ve_dogada_gece",
	    "title": "İzcilik Kampında Orman Gecesi",
	    "category": "saglik",
	    "vignette": "nature",
	    "context_note": "Aileden uzakta geçirilen ilk gece ve öz-yeterlilik.",
	    "text": "Okulun düzenlediği doğa kampında çadır kurmayı, ateş yakmayı ve pusula kullanmayı öğreniyorsun. Gece ormanda rüzgar uğulduyor.",
	    "min_age": 9,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Nöbet ateşini canlı tut ve kamp arkadaşlarına liderlik et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Doğada kendi ayakların üzerinde durma özgüveni kazandın.",
	        "effects": {
	          "health": 10,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çadırın içinde uyku tulumuna sarılıp sabaha kadar dinlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Temiz orman havası ciğerlerini yeniledi.",
	        "effects": {
	          "health": 8,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "ch_48_resim_veya_siir_odulu",
	    "title": "Ulusal Çocuk Dergisinde Yayımlanan İlk Yazın",
	    "category": "egitim",
	    "vignette": "art",
	    "context_note": "İlk kez adının basılı bir yayında yer alması.",
	    "text": "Gönderdiğin kısa öykü ve bulmaca çözümü ülkenin en popüler çocuk dergisinde senin adınla yayımlandı!",
	    "min_age": 8,
	    "max_age": 12,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Dergiyi sakla ve yazarlık/üretim disiplinini sürdür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Üretmenin verdiği tatmin tüm eğitim hayatına ışık tuttu.",
	        "effects": {
	          "health": 0,
	          "happiness": 15,
	          "smart": 9,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ödül olarak gönderilen boya ve kitap setini arkadaşlarınla paylaş",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Cömertliğinle herkesin sevgisini kazandın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 8,
	          "sanity": 0,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  }
	]
