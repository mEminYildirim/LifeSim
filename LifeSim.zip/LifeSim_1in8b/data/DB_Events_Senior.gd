extends RefCounted

# 60-100+ Yaş Arası Detaylı Yaşlılık Olayları (36 Olay)
static func get_events() -> Array:
	return [
	  {
	    "id": "sn_01_emeklilik_sabahi_ilk_cay",
	    "title": "Alarmsız İlk Sabah: Emeklilik ve Yeni Ritim",
	    "category": "felsefe",
	    "vignette": "family",
	    "context_note": "60+ yaşta çalışma hayatının bitişi ve zamanla kurulan yeni ilişki.",
	    "text": "Yıllar sonra ilk kez sabah alarm çalmadan uyandın. Pencereden güneş vuruyor, çaydanlıkta su fokurduyor. Önündeki yılları nasıl değerlendireceksin?",
	    "min_age": 60,
	    "max_age": 66,
	    "weight": 92,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kültür turlarına, kitaplara ve bahçe işlerine adanmış aktif bir emeklilik kur",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Emekliliği bir son değil, hayatın en özgür baharı haline getirdin!",
	        "effects": {
	          "health": 10,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "aktif_emekli"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yarı-zamanlı onursal danışman / usta olarak gençlere tecrübe aktarmaya devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem zihnin dinç kaldı hem de ek gelirin ve saygınlığın sürdü.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 8,
	          "reputation": 14,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 2400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Evde televizyon karşısına çöküp hareketsiz bir rutine gir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hareketsizlik eklemlerini ve ruh halini olumsuz etkiledi.",
	        "effects": {
	          "health": -10,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -8,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_02_emekli_maasi_ve_enflasyon",
	    "title": "Emekli Maaşı Kuyruğu ve Geçim Hesabı",
	    "category": "ekonomi",
	    "vignette": "finance",
	    "context_note": "Sabit gelirli yaşlılıkta ekonomik dalgalanmalarla mücadele.",
	    "text": "Artan sağlık ve gıda fiyatları karşısında emekli maaşının alım gücü zorlanıyor. Birikimlerini nasıl yöneteceksin?",
	    "min_age": 61,
	    "max_age": 88,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [
	        "extreme_poor",
	        "low",
	        "middle"
	      ],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Bütçeni sadeleştir, kooperatif ve belediye sosyal tesislerinden yararlan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kimseye muhtaç olmadan onurlu ve dengeli yaşam standardını korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 6,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yılların ustalığını kullanarak evden küçük tamirat/danışmanlık işleri yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem elin işledi hem de mutfak bütçen rahatladı!",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 4,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 1400,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_03_ilk_torun_sevgisi",
	    "title": "Kucağındaki Yeni Hayat: Torun Sevgisi",
	    "category": "aile",
	    "vignette": "birth",
	    "context_note": "Kuşakların devamı ve yaşlılık neşesi.",
	    "text": "Çocuğunun bebeğini ilk kez kucağına aldın. Minik parmaklarıyla senin kırışık elini kavradığında gözlerinden sıcak yaşlar süzüldü.",
	    "min_age": 60,
	    "max_age": 85,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "ebeveyn"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Torununa masallar anlat, birlikte parka git ve ona hayat bilgeliği aşıla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Torununun neşesi ömrüne ömür kattı; aranızda muhteşem bir bağ kuruldu!",
	        "effects": {
	          "health": 8,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 18,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "torun_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Torununun gelecekteki eğitimi için adına vadeli bir eğitim hesabı aç",
	        "lock_reason": "Eğitim Fonu İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 1500,
	        "req_tags": [],
	        "outcome_text": "Gelecek kuşağa kalıcı bir eğitim güvencesi bıraktın.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 16,
	          "money_flat": -1500,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "torun_sahibi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_04_vasiyetname_ve_miras_duzeni",
	    "title": "Noter Masasında Vasiyetname ve Miras Paylaşımı",
	    "category": "ekonomi",
	    "vignette": "court",
	    "context_note": "Arkanda kavga değil, adalet bırakma kararı.",
	    "text": "Yaşın ilerledikçe biriktirdiğin varlıkların ve hatıraların senden sonra nasıl paylaşılacağını resmiyete dökme vakti geldi.",
	    "min_age": 64,
	    "max_age": 95,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Noter huzurunda tüm çocukların/yakınların arasında adil ve şeffaf bir vasiyetname yaz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Senden sonra çıkabilecek tüm miras kavgalarını önledin; herkes kararına saygı duydu.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 16,
	          "sanity": 16,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "adil_vasiyet"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Varlığının bir kısmını eğitim/sağlık vakfına, kalanını ailene bağışla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Adını yaşatacak hayırsever bir miras bıraktın!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 22,
	          "sanity": 0,
	          "karma": 24,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "vakif_kurucusu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "'Benden sonra ne yaparlarsa yapsınlar' diyerek vasiyet yazmayı reddet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aile içinde şimdiden fısıltılar ve huzursuzluk başladı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": -6,
	          "sanity": -6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_05_hatirat_kitabi_yazmak",
	    "title": "Sararmış Fotoğraflar ve Bir Ömrün Hatıratı",
	    "category": "felsefe",
	    "vignette": "art",
	    "context_note": "Yaşanan onca yılın hikayesini gelecek kuşaklara aktarma.",
	    "text": "Eski fotoğraf albümlerini ve günlüklerini masaya yaydın. Doğduğun günden bugüne ülkenin ve kendi hayatının geçirdiği dönüşümü yazmak istiyorsun.",
	    "min_age": 62,
	    "max_age": 96,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her sabah daktilo/bilgisayar başına geçip 'Sekiz Milyarda Bir Ömür' hatıratını tamamla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hatıratın hem ailen hem de genç okurlar için eşsiz bir dönem tanıklığı oldu!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 8,
	          "reputation": 18,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "hatirat_yazari"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Anılarını ses kaydına alıp çocuklarına ve torunlarına arşiv bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sesin ve hikayelerin kuşaklar boyu saklanacak.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_06_kalp_veya_eklem_ameliyati",
	    "title": "Ameliyathane Işıkları ve Yaşlılık Sınavı",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "İleri yaşta karşılaşılan ciddi cerrahi operasyon.",
	    "text": "Doktorlar kalp damarlarında veya kalça ekleminde acil cerrahi müdahale gerektiren bir daralma/aşınma tespit etti.",
	    "min_age": 63,
	    "max_age": 95,
	    "weight": 86,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Deneyimli cerrah ekibine güvenip ameliyat ol ve rehabilitasyona harfiyen uy",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Operasyon başarılı geçti; ağrıların dindi ve yeniden rahatça yürümeye başladın!",
	        "effects": {
	          "health": 18,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": -1200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Ameliyattan korkup sadece ilaç tedavisiyle idare etmeye çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hareket kabiliyetin kısıtlandı ve sağlığın kırılganlaştı.",
	        "effects": {
	          "health": -16,
	          "happiness": -10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_07_eski_dostlarla_cinar_alti",
	    "title": "Asırlık Çınar Altında Kalan Son Dostlar",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Yaşlılıkta dostluğun ve vefanın kıymeti.",
	    "text": "Gençlik yıllarından hayatta kalan birkaç kadim dostunla mahalle kahvesinde/parkta buluştunuz. Masada eski günlerin kahkahaları ve kaybedilenlerin hüznü var.",
	    "min_age": 62,
	    "max_age": 95,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her hafta buluşma geleneği başlatıp birbirinize yalnızlığı unutturun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dost meclisi ruhunu genç tuttu; yalnızlık kapına uğramadı.",
	        "effects": {
	          "health": 6,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 18,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eski bir kırgınlığı masada helalleşerek tamamen bitir",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yılların yükü omuzlarından kalktı.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_08_cocuklarin_miras_tartismasi",
	    "title": "Bayram Yemeğinde Çocukların İmalı Sözleri",
	    "category": "aile",
	    "vignette": "heartbreak",
	    "context_note": "Ebeveyn hayattayken çocukların mal mülk hesabına girmesi.",
	    "text": "Aile yemeğinde çocuklarının/yakınlarının senin evini ve birikimini şimdiden kendi aralarında paylaşmaya çalıştıklarını ve birbirlerine soğuk davrandıklarını duydun.",
	    "min_age": 64,
	    "max_age": 95,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "ebeveyn"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Masaya ağırlığını koy; kardeşliğin maldan üstün olduğunu hatırlatıp sınırı çiz",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sözlerin salonda yankılandı; utanan çocukların özür dileyip barıştı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 10,
	          "karma": 10,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Birikimini kendi sağlığın ve dünya gezin için harcayacağını ilan et!",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Herkes şaşkına döndü; sen ise kendi emeğinin keyfini çıkardın.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_09_dunya_turu_veya_hac_yolculugu",
	    "title": "Ömrün Sonbaharında Büyük Yolculuk",
	    "category": "felsefe",
	    "vignette": "migration",
	    "context_note": "Hayat boyu görülmek istenen kutsal veya tarihi topraklara ziyaret.",
	    "text": "Bacakların hâlâ tutarken gençliğinden beri görmek istediğin o uzak diyarlara/kutsal mekanlara yolculuğa çıkma fırsatı doğdu.",
	    "min_age": 60,
	    "max_age": 86,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Yola çık; ruhunu arındır ve dünyayı son kez hayranlıkla kucakla",
	        "lock_reason": "Yolculuk İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 1800,
	        "req_tags": [],
	        "outcome_text": "Yolculuktan bambaşka bir iç huzuru ve nur yüzlü bir dinginlikle döndün.",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 20,
	          "karma": 18,
	          "money_flat": -1800,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "kutsal_gezi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Yol yorgunluğunu göze alamayıp memleketin yaylalarında dinlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kendi doğanda huzur buldun.",
	        "effects": {
	          "health": 8,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_10_unutkanlik_ve_zihin_egzersizi",
	    "title": "Anahtarları Unutmak: Hafıza ve Zihin Sınavı",
	    "category": "saglik",
	    "vignette": "philosophy",
	    "context_note": "İleri yaşta bilişsel sağlığı koruma mücadelesi.",
	    "text": "Son aylarda isimleri ve eşyaları koyduğun yerleri unutmaya başladığını fark ettin. Demans/Alzheimer korkusu zihnini yokluyor.",
	    "min_age": 65,
	    "max_age": 98,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her gün bulmaca çöz, satranç oyna, yeni şarkılar ezberle ve nöroloji kontrolüne git",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Beyin jimnastiği ve tıbbi takip sayesinde hafızan jilet gibi keskin kaldı!",
	        "effects": {
	          "health": 8,
	          "happiness": 0,
	          "smart": 10,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "keskin_hafiza"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Durumu gizleyip içine kapan",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Unutkanlığın ilerledi ve kaygın arttı.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": -8,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_11_mahallenin_bilge_hakemi",
	    "title": "Sokaktaki Kavgayı Tek Sözle Bitiren İhtiyar",
	    "category": "felsefe",
	    "vignette": "court",
	    "context_note": "Yaşlılığın getirdiği toplumsal saygınlık ve kanaat önderliği.",
	    "text": "Mahallede iki esnaf/komşu alacak verecek meselesinden birbirinin yakasına yapıştı. Herkes senin pencereden/dükkandan çıkıp söyleyeceğin sözü bekliyor.",
	    "min_age": 62,
	    "max_age": 95,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {
	        "reputation": 50
	      },
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "İki tarafı da çay masasına oturtup adil bir ödeme planıyla el sıkıştır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Mahallede 'Bilge Çınar' olarak anılmaya başladın; herkesin saygısı katlandı!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 10,
	          "karma": 18,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "mahalle_bilgesi"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Gençlerin kavgasına karışmayıp polisi ara",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Olay büyümeden resmi yoldan kapandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 4,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_12_es_kaybi_veya_altin_yildonumu",
	    "title": "Yarım Asırlık Yastık: Sadakat ve Vefa",
	    "category": "ask",
	    "vignette": "love",
	    "context_note": "Uzun ömürlü birlikteliklerin yaşlılıktaki derinliği.",
	    "text": "Hayat arkadaşınla/sevdiklerinle geçirdiğin onca yılın ardından, birlikte saçlarınızın bembeyaz olduğu o dingin günlere ulaştınız.",
	    "min_age": 62,
	    "max_age": 95,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "evli"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "40./50. yıl dönümünüzde tüm aileyi toplayıp sevginizi kutlayın",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Torunlarınız ve çocuklarınız sizin sarsılmaz sevginizi örnek aldı!",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 14,
	          "sanity": 18,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Baş başa eski mektupları okuyup şükredin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kalbiniz huzurla doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_13_universiteye_geri_donus_60_arti",
	    "title": "Altmışından Sonra Amfide Öğrenci Olmak",
	    "category": "egitim",
	    "vignette": "academy",
	    "context_note": "Öğrenmenin yaşı olmadığını kanıtlamak.",
	    "text": "Gençliğinde şartlar yüzünden okuyamadığın veya hep merak ettiğin Tarih/Sanat/Felsefe bölümüne 60+ yaş kontenjanından/sınırsız eğitim hakkıyla girme şansı doğdu!",
	    "min_age": 60,
	    "max_age": 88,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Çantanı alıp 20 yaşındaki gençlerle aynı sıraya otur ve diplomayı al",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Üniversite birincisi gençlerle dost oldun; mezuniyetin ulusal haberlere çıktı!",
	        "effects": {
	          "health": 0,
	          "happiness": 22,
	          "smart": 14,
	          "reputation": 22,
	          "sanity": 18,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "yasam_boyu_ogrenci"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Açık öğretim ve halka açık seminerlerle yetin",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Zihnini canlı tuttun.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 8,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_14_kis_firtinasi_ve_komsu_yardimi",
	    "title": "Buz Tutan Kaldırımlar ve Genç Komşunun Kapıyı Çalması",
	    "category": "aile",
	    "vignette": "home",
	    "context_note": "Yaşlılıkta komşuluk dayanışması.",
	    "text": "Dışarıda dondurucu bir kış fırtınası var ve belin ağrıdığı için pazara/eczaneye çıkamıyorsun. Yan daireye yeni taşınan genç öğrenci/çift kapını çaldı.",
	    "min_age": 65,
	    "max_age": 98,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gençlerle dostluk kur; onlara ev yemeği ve hayat tecrübesi ver, onlar da alışverişine koşsun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kan bağı olmadan da aile olunabileceğini gördün; evin şenlendi!",
	        "effects": {
	          "health": 8,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kimseye yük olmak istemeyip teşekkür et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Onurlu duruşunu korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 6,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_15_eski_ciragin_vefa_ziyareti",
	    "title": "Yıllar Önce Yetiştirdiğin Gencin Vefa Ziyareti",
	    "category": "kariyer",
	    "vignette": "trophy",
	    "context_note": "Toprağa atılan iyilik tohumunun yaşlılıkta çiçek açması.",
	    "text": "Kariyer yıllarında elinden tutup meslek öğrettiğin o genç, bugün ülkenin en başarılı isimlerinden biri olarak elinde çiçekle kapını çaldı!",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Onu gururla kucakla ve senin adına kurduğu onur bursuna başdanışman ol",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ömrünün boşa geçmediğini, arkanda yaşayan bir eser bıraktığını gözlerinle gördün!",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 22,
	          "sanity": 18,
	          "karma": 0,
	          "money_flat": 2500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Birlikte eski günleri yad edip çay için",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gözlerin mutluluktan doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_16_bahcede_budama_ve_doga",
	    "title": "İlkBaharda Ağaç Aşılama ve Kuş Yuvaları",
	    "category": "saglik",
	    "vignette": "nature",
	    "context_note": "Yaşlılıkta doğayla bütünleşme.",
	    "text": "Bahar güneşi yüzünü ısıtırken bahçedeki/parktaki ağaçların budanması ve göçmen kuşlar için ahşap yuvalar yapılması gerekiyor.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi ellerinle ahşap kuş evleri yapıp ağaçlara as ve fidanları aşıla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sabahları kuş cıvıltılarıyla uyanmak ömrüne bereket kattı.",
	        "effects": {
	          "health": 10,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Bankta oturup baharın gelişini seyret",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Huzurlu bir gün geçirdin.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_17_telefonda_sahte_hediye_dolandiriciligi",
	    "title": "Yaşlıları Hedef Alan 'Ücretsiz Sağlık Cihazı' Tuzağı",
	    "category": "kriz",
	    "vignette": "crime",
	    "context_note": "İleri yaştaki vatandaşları hedef alan senet imzalatma dolandırıcılığı.",
	    "text": "Kapıya gelen takım elbiseli iki kişi, belediye/sağlık kampanyası adı altında sana ücretsiz masaj ve tansiyon cihazı verdiklerini söyleyip 'teslim alındı' belgesi diye bir senet uzatıyor!",
	    "min_age": 62,
	    "max_age": 98,
	    "weight": 80,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gözlüğünü takıp kağıdın aslında açık senet olduğunu fark et ve polisi ara!",
	        "lock_reason": "",
	        "req_stats": {
	          "smart": 48
	        },
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dolandırıcılar arkalarına bakmadan kaçtı; mahalledeki diğer yaşlıları da kurtardın!",
	        "effects": {
	          "health": 0,
	          "happiness": 0,
	          "smart": 8,
	          "reputation": 16,
	          "sanity": 10,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "İyi niyetle kağıdı imzala",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Bir ay sonra icra takibi geldi; emekli birikiminin bir kısmı yandı!",
	        "effects": {
	          "health": 0,
	          "happiness": -18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": -14,
	          "karma": 0,
	          "money_flat": -2200,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_18_asirlik_cinar_80_yas_kutlamasi",
	    "title": "Sekseninci Yaş Günü: Koca Bir Çınar",
	    "category": "aile",
	    "vignette": "trophy",
	    "context_note": "Seksen yaşına ulaşmanın nadirliği ve kuşakların bir araya gelişi.",
	    "text": "Seksen yaşına bastın! Çocuklar, torunlar, komşular ve eski dostlar etrafında toplandı. Pastanın üzerindeki mumlar koca bir asrın tanığı gibi parlıyor.",
	    "min_age": 79,
	    "max_age": 81,
	    "weight": 90,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Herkese sarılarak 'Sevgi ve dürüstlükten şaşmayın' vasiyetinde bulun",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Salondaki herkes ayakta alkışladı; bilge bir çınar olarak gönüllerde taht kurdun!",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 18,
	          "karma": 15,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "asirlik_cinar"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sessizce şükredip torunlarının neşesini izle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Derin bir iç huzuru yaşadın.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "asirlik_cinar"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_19_gecmis_mektuplari_yakmak_veya_saklamak",
	    "title": "Tavan Arasındaki Eski Mektuplar ve Sırlar",
	    "category": "felsefe",
	    "vignette": "secret",
	    "context_note": "İnsan ömrünün gizli kalmış sayfaları.",
	    "text": "Eski sandığını düzenlerken gençliğinden kalan mektupları, kırgınlıkları ve kimsenin bilmediği sırları içeren kutuyu açtın.",
	    "min_age": 65,
	    "max_age": 98,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kırgınlık mektuplarını şöminede/sobada yakarak geçmişin tüm yüklerini affet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Küller uçuşurken kalbindeki son kırgınlık da silindi; kuş gibi hafifledin.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 20,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Tarihsel ve ailesel değeri olanları zarflayıp torunlarına bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aile hafızasını geleceğe taşıdın.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 10,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_20_yerel_el_sanatlari_kurs_hocasi",
	    "title": "Halk Eğitim Merkezinde Gençlere Ustalık Öğretmek",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Unutulmaya yüz tutmuş becerileri aktarma.",
	    "text": "Belediye kültür merkezi, senin yıllar içinde edindiğin mesleki ve sanatsal tecrübeyi haftada iki gün ücretsiz kursta gençlere aktarmanı rica ediyor.",
	    "min_age": 60,
	    "max_age": 92,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kürsüye/atölyeye geç ve onlarca gence zanaat/meslek ahlakı öğret",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sabahları uyanmak için harika bir amacın oldu; herkes sana 'Hocam' diye hitap ediyor!",
	        "effects": {
	          "health": 6,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 16,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Evde kendi eserlerini üretmeye devam et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dinginliğini korudun.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_21_kis_solunum_ve_zaturre_sinavi",
	    "title": "Ağır Kış Soğuğu ve Zatürre Tehlikesi",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "İleri yaşta bağışıklık sisteminin zorlu sınavı.",
	    "text": "Sert geçen kış aylarında üşüttün ve öksürüğün ciğerlerine indi. Doktor hastanede yataklı tedavi öneriyor.",
	    "min_age": 68,
	    "max_age": 99,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Hastanede doktor gözetiminde tam tedavi gör ve nefes egzersizleri yap",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Özenli bakımla ciğerlerin temizlendi ve tehlikeyi atlattın.",
	        "effects": {
	          "health": 12,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": -600,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Hastaneye gitmeyi reddedip evde bitki çayıyla geçiştirmeye çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hastalığın ağırlaştı ve bünyen ciddi güç kaybetti.",
	        "effects": {
	          "health": -24,
	          "happiness": -12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_22_mahalle_kutuphanesine_kitap_bagisi",
	    "title": "Kişisel Kütüphaneni Okula Bağışlamak",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Bilginin ölümsüzlüğü.",
	    "text": "Yıllar boyunca tek tek topladığın yüzlerce ciltlik kütüphanenin senden sonra dağılmasını istemiyorsun.",
	    "min_age": 64,
	    "max_age": 98,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Tüm kitaplarını kendi adına açılan bir okuma köşesiyle gençlik kütüphanesine bağışla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Her kitabın kapağında senin mührün var; gençler okudukça adın yaşayacak!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 14,
	          "karma": 20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "En nadide eserleri çocuklarına ve torunlarına paylaştır",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Aile içinde anlamlı bir kültür mirası bıraktın.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_23_uzun_omur_sirri_roportaji",
	    "title": "Genç Gazetecinin Sorusu: 'Bu Hayattan Ne Öğrendiniz?'",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "Bir ömrün tek cümlelik özeti.",
	    "text": "Yerel bir gazeteci ve belgeselci kapını çaldı. 'Sekiz milyar insanın arasında koca bir ömür sürdünüz; gençlere tek bir öğüdünüz olsa ne söylerdiniz?' diye soruyor.",
	    "min_age": 70,
	    "max_age": 100,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "'İnsanlara merhamet edin, kimsenin hakkını yemeyin ve merakınızı hiç kaybetmeyin'",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sözlerin gazetede manşet oldu ve binlerce insanın kalbine dokundu.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 16,
	          "karma": 16,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "'Zaman su gibi akıyor; sevdiklerinize sarılmayı yarınlara ertelemeyin'",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Gözlerin dolarak verdiğin cevap herkesi duygulandırdı.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_24_doksan_yas_bilgelik_zirvesi",
	    "title": "Doksan Yaşın Sessiz Zirvesi",
	    "category": "felsefe",
	    "vignette": "trophy",
	    "context_note": "Asra yaklaşan ömür.",
	    "text": "Doksan yaşına ulaştın! Pencereden mevsimlerin geçişini izlerken hayatın tüm gürültüsü yerini derin ve berrak bir sessizliğe bıraktı.",
	    "min_age": 88,
	    "max_age": 105,
	    "weight": 88,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her nefesi şükranla karşıla ve huzur içinde gülümse",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ruhun tam bir bütünlük ve barış içinde.",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 22,
	          "karma": 15,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "bilge_cinar"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Torunlarının çocuklarına (4. kuşak) ilk harçlıklarını ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Dört kuşağı bir arada görmenin mucizesini yaşadın!",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 20,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "dort_kusak_gordu"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_25_emekli_kooperatif_veya_hobi_sergisi",
	    "title": "Yaşlılar Kültür Merkezinde Karma Sergi",
	    "category": "kariyer",
	    "vignette": "art",
	    "context_note": "Yaşlılıkta üretkenlik.",
	    "text": "Emeklilik yıllarında yaptığın ahşap oymalar, tablolar veya el işleri belediye sergi salonunda halkla buluşuyor.",
	    "min_age": 61,
	    "max_age": 95,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Sergiden elde edilen geliri çocuk hastanesine bağışla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hem sanatın takdir topladı hem de çocuklara şifa oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 12,
	          "karma": 20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eserlerini dostlarına hatıra olarak armağan et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sevdiklerinin evinde senden birer iz kaldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_26_evcil_dostla_park_yuruyusu",
	    "title": "Sabah Çiğinde Sadık Dostla Yürüyüş",
	    "category": "saglik",
	    "vignette": "nature",
	    "context_note": "İleri yaşta hareket ve yalnızlık ilacı.",
	    "text": "Sabah erken saatlerde parkın çimenleri henüz çiğ ile kaplıyken sadık kedinle/köpeğinle veya bastonunla yürüyüşe çıktın.",
	    "min_age": 60,
	    "max_age": 96,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Her sabah 4.000 adım hedefini koru ve parktaki kuşları besle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kalp ve damar sağlığın yaşıtlarına göre çok daha dinç kaldı.",
	        "effects": {
	          "health": 12,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 12,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Parktaki diğer emeklilerle gazete okuyup memleket meselelerini tartış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sosyal bağların zihnini zinde tuttu.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 5,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_27_torunun_ilk_is_veya_okul_heyecani",
	    "title": "Torununun Senden Hayat Tavsiyesi İstemesi",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Kuşaklar arası rehberlik.",
	    "text": "Büyüyen torunun hayatının ilk büyük sınavı/kararı öncesinde senin yanına oturup 'Sen olsaydın ne yapardın?' diye sordu.",
	    "min_age": 64,
	    "max_age": 98,
	    "weight": 78,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "torun_sahibi"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Kendi hayatındaki doğru ve yanlışları dürüstçe anlatıp ona cesaret ver",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Torunun senin bilgeliğinle doğru yolu seçti ve sana hayranlıkla sarıldı.",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 16,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Cebine gizlice harçlık koyup sırtını sıvazla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Şefkatin ona güç verdi.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": -300,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_28_eski_is_yerinden_vefa_plaketi",
	    "title": "Yıllar Sonra Eski İş Yerinden Gelen Davet",
	    "category": "kariyer",
	    "vignette": "work",
	    "context_note": "Emek verilen kurumda unutulmamak.",
	    "text": "Yıllar önce emekli olduğun kurum/atölye, kuruluş yıl dönümünde yaşayan en kıdemli emektar olarak seni onur konuğu ilan etti.",
	    "min_age": 62,
	    "max_age": 95,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Törene katıl ve yeni nesil çalışanlara iş ahlakını anlat",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Salondaki gençler seni ayakta alkışladı; emeğinin unutulmadığını görmek ruhunu doyurdu.",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sağlığını yormamak için teşekkür mesajı gönder",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Plaketini evine kadar getirip takdim ettiler.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 12,
	          "sanity": 0,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_29_iklim_ve_su_tasarrufu_mirasi",
	    "title": "Kuruyan Çeşmeyi Yeniden Akıtmak",
	    "category": "felsefe",
	    "vignette": "nature",
	    "context_note": "Suyu ve toprağı koruyan kalıcı hayır (Sadaka-i Cariye).",
	    "text": "Memleketindeki veya mahallendeki eski taş çeşmenin su boruları çürümüş ve kurumuş durumda.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Masrafını karşılayıp çeşmeyi onart ve yanına iki ıhlamur ağacı diktir",
	        "lock_reason": "Onarım İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 900,
	        "req_tags": [],
	        "outcome_text": "Gelip geçen herkesin su içtiği, kuşların konduğu kalıcı bir hayır eseri bıraktın!",
	        "effects": {
	          "health": 0,
	          "happiness": 18,
	          "smart": 0,
	          "reputation": 20,
	          "sanity": 14,
	          "karma": 24,
	          "money_flat": -900,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Belediye su idaresine başvurup onarılmasını takip et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Çaba göstererek çeşmenin yeniden akmasını sağladın.",
	        "effects": {
	          "health": 0,
	          "happiness": 10,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 12,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_30_gece_radyosu_ve_klasik_muzik",
	    "title": "Gece Yarısı Radyoda Çalan Gençlik Şarkısı",
	    "category": "felsefe",
	    "vignette": "music",
	    "context_note": "Müzikle canlanan hatıralar.",
	    "text": "Uykunun tutmadığı bir gece eski radyonun frekansını çevirirken, 20'li yaşlarında en çok dinlediğin o unutulmaz şarkı çalmaya başladı.",
	    "min_age": 60,
	    "max_age": 98,
	    "weight": 74,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Gözlerini kapatıp gençliğinin tüm güzel anılarını tebessümle film şeridi gibi izle",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kalbin şükran ve tatlı bir huzurla doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Eşini/aileni uyandırıp salonda yavaşça dans et",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Yaşın sadece bir sayı olduğunu kanıtlayan büyülü bir an yaşadınız!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_31_vucut_direnc_ve_kaplica",
	    "title": "Termal Kaplıca ve Fizik Tedavi Haftası",
	    "category": "saglik",
	    "vignette": "hospital",
	    "context_note": "Yaşlılık ağrılarına doğal ve tıbbi şifa.",
	    "text": "Kış aylarında diz ve bel eklemlerindeki romatizma ağrıları arttı.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Şifalı termal kaplıca ve fizyoterapi kürünü uygula",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sıcak mineralli sular ağrılarını dindirdi, yürüyüşün hafifledi.",
	        "effects": {
	          "health": 14,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": -500,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Evde sıcak su torbası ve hafif egzersizle dinlen",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ağrılarını kontrol altında tuttun.",
	        "effects": {
	          "health": 6,
	          "happiness": 0,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 6,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_32_komsunun_yetim_cocuguna_burs",
	    "title": "Apartmandaki Yetim Gence Gizli Eğitim Desteği",
	    "category": "felsefe",
	    "vignette": "academy",
	    "context_note": "Sessiz iyilik.",
	    "text": "Mahallede babasını/annesini yeni kaybetmiş çalışkan bir lise öğrencisinin okul masrafları yüzünden okulu bırakma noktasında olduğunu öğrendin.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 76,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Okul müdürü üzerinden kimliğini gizleyerek mezun olana kadar tüm masraflarını üstlen",
	        "lock_reason": "Burs İçin Birikim Gerekli",
	        "req_stats": {},
	        "req_money": 1000,
	        "req_tags": [],
	        "outcome_text": "Bir gencin hayatını kurtardın; içindeki huzur tarif edilemez!",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 18,
	          "karma": 28,
	          "money_flat": -1000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Kitap ve kırtasiye ihtiyaçlarını karşıla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Güzel bir destek sundun.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 0,
	          "karma": 14,
	          "money_flat": -250,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_33_aile_fotograf_albumu_dijitallestirme",
	    "title": "Yüz Yıllık Aile Arşivini Kurtarmak",
	    "category": "aile",
	    "vignette": "tech",
	    "context_note": "Geçmişi geleceğe bağlamak.",
	    "text": "Sandıktaki siyah-beyaz aile fotoğraflarının sararıp silinmeye başladığını fark ettin.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 72,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Torununla birlikte fotoğrafları taratıp arkalarındaki hikayeleri tek tek kaydet",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Ailenin yüz yıllık soy ağacı ve hikayeleri ölümsüzleşti!",
	        "effects": {
	          "health": 0,
	          "happiness": 16,
	          "smart": 6,
	          "reputation": 10,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Çerçeveletip salonun en güzel duvarına as",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Evin duvarları tarih ve vefayla doldu.",
	        "effects": {
	          "health": 0,
	          "happiness": 12,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 10,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_34_balkonda_begonya_ve_cay",
	    "title": "Akşamüstü Balkonunda Gün Batımı ve İç Hesaplaşma",
	    "category": "felsefe",
	    "vignette": "philosophy",
	    "context_note": "Ömrün son demlerinde tam kabulleniş (Amor Fati).",
	    "text": "Balkondaki çiçekleri suladıktan sonra batan güneşin kızıllığını izliyorsun. Doğduğun günden beri yaşadığın sevinçler, kayıplar ve kararlar gözünün önünden geçiyor.",
	    "min_age": 65,
	    "max_age": 102,
	    "weight": 82,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "'İyi ki yaşadım, iyi ki sevdim ve direndim' diyerek kaderini sevgiyle kucakla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Tam bir bilgelik ve iç barış noktasına ulaştın.",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 22,
	          "karma": 14,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Sevdiklerine telefon açıp seslerini duy ve hal hatır sor",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sıcak sohbetler akşamını aydınlattı.",
	        "effects": {
	          "health": 0,
	          "happiness": 14,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 14,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_35_son_bahar_ve_helallesme",
	    "title": "Büyük Helalleşme Sofrası",
	    "category": "aile",
	    "vignette": "family",
	    "context_note": "Sevdiklerinle bir araya gelip gönül alma.",
	    "text": "Bütün aileni, çocuklarını, torunlarını ve dostlarını büyük bir hafta sonu sofrasında topladın.",
	    "min_age": 72,
	    "max_age": 102,
	    "weight": 84,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Herkesle tek tek kucaklaşıp helalleş ve sevgi dolu öğütler bırak",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Sofradaki herkes senin varlığına şükretti; arkanda sevgiyle kenetlenmiş bir aile bıraktığından emin oldun.",
	        "effects": {
	          "health": 0,
	          "happiness": 24,
	          "smart": 0,
	          "reputation": 18,
	          "sanity": 22,
	          "karma": 20,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "helallesmis"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Neşeli anıları anlatıp herkesi güldür",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Kahkahalarla dolu unutulmaz bir gün yaşandı.",
	        "effects": {
	          "health": 0,
	          "happiness": 20,
	          "smart": 0,
	          "reputation": 0,
	          "sanity": 16,
	          "karma": 0,
	          "money_flat": 0,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  },
	  {
	    "id": "sn_36_gecmisin_karanlik_dosyasi",
	    "title": "Yıllar Önce Gizlenen Çevre Yolsuzluğunun Ortaya Çıkması!",
	    "category": "kriz",
	    "vignette": "court",
	    "context_note": "Gençliğinde/yetişkinliğinde aldığın sus payının yaşlılıkta patlak vermesi.",
	    "text": "Yıllar önce çalıştığın şirkette sus payı alarak görmezden geldiğin zehirli atık skandalı, araştırmacı gazeteciler ve savcılık tarafından arşivlerden çıkarıldı! Belgede senin de eski imzan var.",
	    "min_age": 60,
	    "max_age": 95,
	    "weight": 5,
	    "repeatable": false,
	    "conditions": {
	      "countries": [],
	      "classes": [],
	      "required_tags": [
	        "kirli_para"
	      ],
	      "blocked_tags": [],
	      "min_stats": {},
	      "max_stats": {}
	    },
	    "choices": [
	      {
	        "text": "Mahkemede tüm gerçeği itiraf et, aldığın parayı faiziyle tazminat fonuna bağışla",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Servetinin önemli kısmı eridi ama ömrünün sonbaharında vicdanındaki o ağır yükten kurtuldun.",
	        "effects": {
	          "health": 0,
	          "happiness": -8,
	          "smart": 0,
	          "reputation": -15,
	          "sanity": 12,
	          "karma": 18,
	          "money_flat": -8000,
	          "money_pct": 0.0
	        },
	        "add_tags": [],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      },
	      {
	        "text": "Suçlamaları reddet ve pahalı avukatlarla dosyayı zamanaşımına sokmaya çalış",
	        "lock_reason": "",
	        "req_stats": {},
	        "req_money": 0,
	        "req_tags": [],
	        "outcome_text": "Hapis yatmadın ama toplum içinde itibarın yerle bir oldu.",
	        "effects": {
	          "health": 0,
	          "happiness": -20,
	          "smart": 0,
	          "reputation": -35,
	          "sanity": -20,
	          "karma": -20,
	          "money_flat": -4000,
	          "money_pct": 0.0
	        },
	        "add_tags": [
	          "itibarsiz_yaslilik"
	        ],
	        "remove_tags": [],
	        "add_trait": "",
	        "schedule_consequence": {}
	      }
	    ]
	  }
	]
